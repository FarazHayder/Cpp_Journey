/* Name : Faraz Hayder
   Roll No. : I22-2687 */
#include <iostream>
#include <windows.h>
using namespace std;

int main (){
	
	char grid[20][20];
	const int length=5;
	//Displaying Grid:
	for (int i=0; i<20; i++){
		for (int j=0; j<20; j++){
			grid[i][j]='.';
		}
	}
	for (int i=0; i<20; i++){
		for (int j=0; j<20; j++){
			cout<<grid[i][j];
		}
		cout<<endl;
	}
	cout<<endl;
	//Number of Battleships
	cout<<"Enter the number of battleships (1 to 5) you want to place : ";
	int noofbattleships=0;
	cin>>noofbattleships;
	cout<<endl;
	if (noofbattleships<1 || noofbattleships>5){
		cout<<"The number of battleships must be between in the range of 1 to 5. Thank You!";
		exit(0);
	}
	//Orientation:
	for (int i=1; i<=noofbattleships; i++){
		cout<<"Enter the orientation of battleship "<<i<<": \nPress 'h' for 'horizontal' and 'v' for 'vertical' : ";
		char orientation;
		cin>>orientation;
		int coordinates[2]={0,0};
		//For horizontal orientation:
		if (orientation=='h'){
			cout<<"Enter coordinates of battleship : \n";
			for (int i=0; i<2; i++){
				cin>>coordinates[i];
				if (coordinates[i]<0 || coordinates[i]>=20 || coordinates[1]>15){
					cout<<"Enter valid coordinates. Thank You!";
					exit (0);
				}
			}
			for (int i=coordinates[0]; i==coordinates[0]; i++){
				for (int j=coordinates[1]; j<length+coordinates[1]; j++){
					if (grid[i][j]=='A'){
						cout<<"There is alread a battleship on these coordinates. Please enter different coordinates. Thank You!";
						exit(0);	
					}
					else if (grid[i][j]=='.'){
						grid[i][j]='A';	
					}
				}
			}
			for (int i=0; i<20; i++){
				for (int j=0; j<20; j++){
					cout<<grid[i][j];
				}
				cout<<endl;
			}
			cout<<endl;
		}
		//For vertical orientation:
		else if (orientation=='v'){
			cout<<"Enter coordinates of battleship : \n";
			for (int i=0; i<2; i++){
				cin>>coordinates[i];
				if (coordinates[i]<0 || coordinates[i]>15){
					cout<<"Enter valid coordinates. Thank You!";
					exit (0);
				}
			}
			for (int i=coordinates[0]; i<length+coordinates[0]; i++){
				for (int j=coordinates[1]; j==coordinates[1]; j++){
					if (grid[i][j]=='A'){
						cout<<"There is alread a battleship on these coordinates. Please enter different coordinates. Thank You!";
						exit(0);	
					}
					else if (grid[i][j]=='.'){
						grid[i][j]='A';	
					}
				}
			}
			for (int i=0; i<20; i++){
				for (int j=0; j<20; j++){
					cout<<grid[i][j];
				}
				cout<<endl;
			}
			cout<<endl;
		}
		else {
			cout<<"Enter a valid orientation. Thank You!";
			exit (0);
		}
	}
	sleep(3);
	system("cls");
	
	cout<<"Battle round"<<endl<<endl;
	
	//Displaying Playable Grid:
	char play_grid[20][20];
	for (int i=0; i<20; i++){
		for (int j=0; j<20; j++){
			play_grid[i][j]='.';
		}
	}
	for (int i=0; i<20; i++){
		for (int j=0; j<20; j++){
			cout<<play_grid[i][j];
		}
		cout<<endl;
	}
	cout<<endl;
	
	int score=0;
	int remainingMissiles=5;
	for (int k=remainingMissiles; k>0; k--){
		int user_coordinates[2]={0,0};
		cout<<"Remaining Missiles : "<<remainingMissiles<<endl;
		cout<<"Enter coordinates to fire the missile : \n";
		for (int i=0; i<2; i++){
			cin>>user_coordinates[i];
		}
		if (user_coordinates[0]<0 || user_coordinates[0]>=20 || user_coordinates[1]<0 || user_coordinates[1]>=20){
			cout<<"Enter valid coordinates. Thank You!"<<endl;
		}
		for (int i=user_coordinates[0]; i==user_coordinates[0]; i++){
			for (int j=user_coordinates[1]; j==user_coordinates[1]; j++){
				if (i>=20 || i<0 || j>=20 || j<0){
					k++;
					remainingMissiles++;
				}
				else if (grid[i][j]=='A'){
					score++;
					play_grid[i][j]='H';
					grid[i][j]='H';	
				}
				else {
					play_grid[i][j]='M';
					grid[i][j]='M';
				}
			}
		}
		for (int i=0; i<20; i++){
			for (int j=0; j<20; j++){
				cout<<play_grid[i][j];
			}
			cout<<endl;
		}
		cout<<endl;
		remainingMissiles--;	
	}
	sleep(3);
	system("cls");
	//Displaying Score:
	cout<<"\nYour total score is : "<<score<<endl;
	//Displaying grid with remaining battleships and hits:
	for (int i=0; i<20; i++){
		for (int j=0; j<20; j++){
			cout<<grid[i][j];
		}
		cout<<endl;
	}
	
	return 0;
}