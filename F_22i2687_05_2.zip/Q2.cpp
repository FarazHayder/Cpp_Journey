/* Name : Faraz Hayder
   Roll No. : I22-2687 */
#include <iostream>
#include <string.h>
using namespace std;

string subString (int, int, string);
int find (string, string);
string replace (string, string, int, int);
string invert (string);

int main (){
	
	cout<<"Enter a sentence : "<<endl;
	string text="";
	getline(cin, text);
	
	int x=0;
	cout<<"Menu :- \n";
	cout<<"1-To get substring"<<endl;
	cout<<"2-To find index of a word"<<endl;
	cout<<"3-To replace string"<<endl;
	cout<<"4-To invert string"<<endl;
	cin>>x;
	switch (x) {
		case 1:
			{
				int start=0, end=0;
				string substring;
				cout<<"Enter starting index : ";
				cin>>start;
				if (start<0){
					cout<<"Enter valid input."<<endl;
					exit(0);
				}
				cout<<"Enter ending index : ";
				cin>>end;
				if (end<0){
					cout<<"Enter valid input."<<endl;
					exit(0);
				}
				substring = subString (start, end, text);
				cout<<substring;
				break;
			}
		case 2:
			{
				int index=0;
				string pattern;
				cout<<"Enter the word to find index : ";
				cin>>pattern;
				if (pattern==""){
					cout<<"Enter valid input."<<endl;
					exit(0);
				}
				index = find (pattern, text);
				cout<<index;
				break;
			}
		case 3:
			{
				int start, end;
				string pattern;
				cout<<"Enter starting index : ";
				cin>>start;
				if (start<0){
					cout<<"Enter valid input."<<endl;
					exit(0);
				}
				cout<<"Enter ending index : ";
				cin>>end;
				if (end<0){
					cout<<"Enter valid input."<<endl;
					exit(0);
				}
				cout<<"Enter pattern you want to replace with : ";
				cin>>pattern;
				if (pattern==""){
					cout<<"Enter valid input."<<endl;
					exit(0);
				}
				int length=pattern.length();
				int diff=end-start+1;
				if (diff<0){
					cout<<"Invalid indexes input.";
					exit(0);
				}
				if (length>diff){
					cout<<"Sorry! length of string to be replaced is greater.";
					exit(0);
				}
				string replaced = replace (pattern, text, start, end);
				cout<<replaced;
				break;
			}
		case 4:
			{
				string inverted = invert (text);
				cout<<inverted;
			}	
	}
	
	return 0;
}

string subString (int start, int end, string text){
	
	int length=text.length();
	string substring="";
	for (int i=0; i<length; i++){
		if (text[i]==text[start]){
			while (start<=end){
			substring=substring+text[i];
			start++;
			i++;
			}
		}
	}
	return substring;
}

int find (string pattern, string text){
	
	string temptext, tempPattern;
	const char spacestring[]=" ";
	int index=0;
	string spaceString=" ";
	tempPattern=spaceString+pattern;
	int lengthpattern=tempPattern.length();
	text=spaceString+text;
	int lengthtext=text.length();
	for (int i=0; i<lengthtext; i++){
		if (text[i]==spacestring[0]){
			temptext="";
		}
		temptext=temptext+text[i];
		if (temptext==tempPattern){
			index=i-lengthpattern+2;
			return index;
		}
	}
	return index;
}

string replace (string pattern, string text, int start, int end){
	
	int j=0;
	for (int i=start; i<=end; i++){
		text[i]=pattern[j];
		j++;
	}
	string replaced=text;
	return replaced;
}

string invert (string text){
	
	string inverted="";
	int length=text.length();
	for (int i=length-1; i>=0; i--){
		inverted=inverted+text[i];
	}
	return inverted;
}





