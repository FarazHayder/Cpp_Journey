/* Name : Faraz Hayder
   Roll No. : I22-2687 */
#include <iostream>
using namespace std;

bool verify_order (int, int);

int main(){
	
	int row1,column1,row2,column2;
	
	cout<<"Enter number of rows of 1st Matrix : ";
	cin>>row1;
	cout<<"Enter number of columns of 1st Matrix : ";
	cin>>column1;
	cout<<"Enter number of rows of 2nd Matrix : ";
	cin>>row2;
	cout<<"Enter number of columns of 2nd Matrix : ";
	cin>>column2;
	
	int multiplicatonCheck=verify_order (column1, row2);
	if (multiplicatonCheck==false){
		cout<<"\nSorry! Matrices cannot be multiplied.";
		exit (0);
	}
	
	int a[row1][column1];
	int b[row2][column2];
	int product[row1][column2];
	
	cout<<"\nEnter the elements of first matrix : \n";
	for (int i=0; i<row1; i++){
		for (int j=0; j<column1; j++){
			cin>>a[i][j];
		}
	}
	
	cout<<"Enter the elements of second matrix : \n";
	for (int i=0; i<row2; i++){
		for (int j=0; j<column2; j++){
			cin>>b[i][j];
		}
	}
		
	for (int k=0; k<row1; k++){
		for (int i=0; i<column2; i++){
			int sum=0;
			for (int j=0; j<row2; j++){ //or j<column1. Since, column1=row2 
				sum=sum+a[k][j]*b[j][i];
			}
			product[k][i]=sum;
		}
	}
	
	cout<<"\nThe product of the given two matrices is : \n";
	for (int i=0; i<row1; i++){
		for (int j=0; j<column2; j++){
			cout<<product[i][j]<<"\t";
		}
		cout<<endl;
	}
	
	return 0;
}

bool verify_order (int column1, int row2){
	
	if (column1==row2){
		return 1;
	}
	else if (column1!=row2){
		return 0;
	}
	return 0;
}