//Faraz_Hayder_22I-2687_Assignment#1

#include<iostream>
using namespace std;

//Function to print spaces in the pattern:
void print_characters(int n, int characters, int counter) {
	if (characters == 0) { //Base case
		return;
	}
	cout << char('*');
	print_characters(n, characters - 1, counter); //Calling function recursively
}

//Function to print characters in the pattern:
void print_spaces(int i, int spaces, int counter) {
	if (counter == 0){ //Base case -> Specifically for the very first line (as well as the last line -> which will be accessed during backtracking automatically)
		cout << char('*') << char('*');
		return;
	}
	if (i > spaces) { //Base case
		return;
	}
	if (i == 1){ //For first iteration print two spaces 
		cout << "  ";
	}
	else { //After the first iteration print space as many times as the function is called recursively
		cout << " ";
	}
	print_spaces(i + 1, spaces, counter); //Calling function recursively
}

void printDiamond(int n, int i = 1)
{
    if (i > n) { //Base case
		return;
	}
	int j = 1;
	static int characters = (n / 2) * 2; //Number of characters to print in the half of the row
	static int spaces = 1; //Number of spaces to print in the half of the row
    static int counter = 0; //Counts iteration (Used to keep track of iterations so that during backtracking we know which iteration do we have to skip to avoid printing the middle layer again)
    static int original_value_of_n = n; //Simply to store the original value of n, because it will be changed during recursive calling of the function
	print_characters(n, characters, counter); //Prints characters in the first half of the row
	print_spaces(j, spaces, counter); //Prints spaces between the characters
	print_characters(n, characters, counter); //Prints characters in the second half of the row
	cout << endl; //Moves to the next row
	if (counter == 0){ //For the very first iteration bcuz the numbers of cahracters and spaces are already set
		counter++; 
	}
	else { //After first iteration for every iteration to update the numbers of characters and spaces to print in the next row
		spaces = spaces + 2;
		characters = characters - 1;
		counter++;
	}
	printDiamond(n - 1); //Calling function recursively
	//Backtracking: (Simply put -> Reverse printing of the above printed pattern to form a complete shape)
    spaces = spaces - 2;
    characters = characters + 1;
    if (counter==original_value_of_n){ //If condition to skip the 1st iteration in the backtracking i.e. to avoid printing the middle layer again.
        counter--;
    }
    else {
        print_characters(n, characters, counter);
        print_spaces(j, spaces, counter);
        print_characters(n, characters, counter);
        cout << endl;
    }
}

//Function to check if the input is valid:
int validation (int n){
	while (n<3 || n%2==0){
		cout << "The number must be; greater than 2 and odd."<<endl;
		cout << "Re-enter number of Diamond: ";
		cin >> n;
	}
	return n;
}

main () {

	int n = 0;
	cout << "Enter number of Diamond: ";
	cin >> n;
	n = validation(n); //To first validate the input before passing into the function
	printDiamond(n);

}






/*//Faraz_Hayder_22I-2687_Assignment#1

#include<iostream>
using namespace std;

void print_spaces(int n, int spacecount, int counter) {
	if (spacecount == 0) {
		return;
	}
	cout << char('*');
	print_spaces(n, spacecount - 1, counter);
}

void print_char(int i, int charcount, int counter) {
	if (counter == 0){
		cout << char('*') << char('*');
		return;
	}
	if (i > charcount) {
		return;
	}
	if (i == 1){
		cout << "  ";
	}
	else {
		cout << " ";
	}
	print_char(i + 1, charcount, counter);
}

void printDiamond(int n, int i = 1)
{
    if (i > n) {
		return;
	}
	int j = 1;
	static int spacecount = (n / 2) * 2;
	static int charcount = 1;
    static int counter = 0;
    static int n_check = n;
	print_spaces(n, spacecount, counter);
	print_char(j, charcount, counter);
	print_spaces(n, spacecount, counter);
	cout << endl;
	if (counter == 0){
		counter++;
	}
	else {
		charcount = charcount + 2;
		spacecount = spacecount - 1;
		counter++;
	}
	printDiamond(n - 1);
    charcount = charcount - 2;
    spacecount = spacecount + 1;
    if (counter==n_check){
        counter--;
    }
    else {
        print_spaces(n, spacecount, counter);
        print_char(j, charcount, counter);
        print_spaces(n, spacecount, counter);
        cout << endl;
    }
}

int validation (int n){ //To check if the input is valid
	while (n<3 || n%2==0){
		cout << "The number must be; greater than 2 and odd."<<endl;
		cout << "Re-enter number of Diamond: ";
		cin >> n;
	}
	return n;
}

main () {

	int n = 0;
	cout << "Enter number of Diamond: ";
	cin >> n;
	n = validation(n); //To first validate the input before passing into the function
	printDiamond(n);

}*/