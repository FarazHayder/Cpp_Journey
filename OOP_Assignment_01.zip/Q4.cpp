//Faraz_Hayder_22I-2687_Assignment#1

#include <iostream>
using namespace std;

struct arrayUnion {
	int arr1[10] = {0}; //keep this size
	int arr2[5] = {0}; // keep this size
	int *TemporaryUnionArr = new int [15]{0}; //Temporary Array to store all the elements of both the arrays
    int* ResultUnionArr; //Array which will store Union of the two arrays
    int new_size; //Will use to allocate the size of Array with Union (i.e. ResultUnionArr)
        
void input()
	{   
		//Taking input of the arr1 and arr2:
        cout << "Enter values for first array:\n";
        for (int i = 0; i < 10; i++) {
            cin >> arr1[i];
        }
        TemporaryUnionArr = arr1; //Assigning all the values of arr1 to TemporaryUnionArr
        cout << "Enter values for second array:\n";
        for (int i = 0; i < 5; i++) {
            cin >> arr2[i];
        }
	}

void find_union()
	{
		//Storing all the elements of both the arrays in TemporaryUnionArr:
        int t=10; //Temporary variable to iterate through the TemporaryUnionArr (Starts from ten because it already contains 10 members of arr1)
        for (int i=0; i<5; i++){
            int counter = 0;
            for (int j=0; j<10; j++){
                if (arr2[i]==arr1[j]){
                    break;
                }
                else if (arr2[i]!=arr1[j]){
                    counter++;
                }
                else if (counter == 10){
                    TemporaryUnionArr[t]=arr2[i];
                    t++;
                }
            }
        }
        //Arranging in ascending order: (It is necessary because it will sort all the elements and all the same elements will be placed adjacently)
        for (int i = 0; i < 15; i++) {
            int temp = *(TemporaryUnionArr+i);
            for (int j = i+1; j < 15; j++) {
                if (*(TemporaryUnionArr + j) < temp) {
                    temp = *(TemporaryUnionArr + j);
                    int t1 = *(TemporaryUnionArr + i);
                    *(TemporaryUnionArr + i) = temp;
                    *(TemporaryUnionArr + j) = t1;
                }
            }
        }
        //Setting same members to ≈-inf (So that the negative elements in the array are not disregarded):
        int count = 0;
        for (int i = 0; i < 15; i++) {
            if (TemporaryUnionArr[i] == TemporaryUnionArr[i+1]){
                count++;
                TemporaryUnionArr[i] = -(1e+300 * 1e+300);
            }
        }
        //Arrange in descending order: (It is necessary so that all the unnecessary elements move to the end)
        for (int i = 0; i < 15; i++) {
            int temp = *(TemporaryUnionArr+i);
            for (int j = i+1; j < 15; j++) {
                if (*(TemporaryUnionArr + j) > temp) {
                    temp = *(TemporaryUnionArr + j);
                    int t1 = *(TemporaryUnionArr + i);
                    *(TemporaryUnionArr + i) = temp;
                    *(TemporaryUnionArr + j) = t1;
                }
            }
        }
        //Resizing the array:
        new_size = 15 - count;//To find the new_size 
        ResultUnionArr = new int [new_size]; //Initializing the size of the union array
        //Copying elements from the temporary arr to union array:
        for (int i=0; i<new_size; i++){
            ResultUnionArr[i]=TemporaryUnionArr[i];
        }
        //Deleting the temporary array to free memory:
        delete[] TemporaryUnionArr;
        TemporaryUnionArr = NULL; //Nullifying to avoid dangling
        //Arranging in ascending order:
        for (int i = 0; i < new_size; i++) {
            int temp = *(ResultUnionArr+i);
            for (int j = i+1; j < new_size; j++) {
                if (*(ResultUnionArr + j) < temp) {
                    temp = *(ResultUnionArr + j);
                    int t1 = *(ResultUnionArr + i);
                    *(ResultUnionArr + i) = temp;
                    *(ResultUnionArr + j) = t1;
                }
            }
        }
	}

void printresult()
	{
		//Printing array with union:
        cout << "\nThe union of the two arrays is:\n";
        for (int i = 0; i < new_size; i++) {
            cout << ResultUnionArr[i] << endl;
        }
	}

};

int main() {

	arrayUnion u;
	u.input();
	u.find_union();
	u.printresult();

}