//Faraz_Hayder_22I-2687_Assignment#1

#include<iostream>
#include<ctime>
using namespace std;

bool start_hangman (string str, char answer[], int size){
    static int lives = 4;
    static int tries = 1;
    static bool status = false;
    if (lives == 0){ //Base Case
        return false;
    }
    if (tries != 1){ 
        int temp = 0;
        for (int i = 0; i < size; i++){
            if (answer[i] == '_'){
                break;
            }
            else {
                temp++;
            }
        }
        if (temp == size){ //Base Case
            return true;
        }
    }
    if (tries == 1){ //For the first time when program runs, to display dashes
        for (int i = 0; i < size; i++){
            answer[i]='_';
            cout << char(answer [i]);
        }
    }
    else {
        for (int i = 0; i < size; i++){ //Displaying the answer string
            cout << char(answer [i]);
        }
    }
    cout << endl;
    cout << "Remaining Lives: " << lives << endl;
    char letter;
    cout << " Try " << tries << ": ";
    cin >> letter;
    int count = 0;
    for (int i = 0; i < size; i++){
        if (letter == str[i] || letter == char((str[i]+32)) || letter == char((str[i]-32))){ //The +- 32 in the str[i] is done, to be irrespective of upper and lower case alphabets
            answer[i] = letter;
        }
        else {
            count++;
        }
    }
    if (count == (size)){ //If the letter input is wrong, reducing life by one
        lives--;
    }
    tries++;
    status = start_hangman(str, answer, size); //recursive function calling
    if (status){
        return true;
    }
    else {
        return false;
    }
}

int main (){

    string arr[] = {"Apple", "Banana", "Apricot", "Blueberry", "Cranberry", "Cherry", "Dragonfruit", "Dates", "Orange", "Coconut"};
    srand(time(NULL)); //Seeding srand() function
    int temp = 0;
    temp = rand () % 10; 
    int size = arr[temp].length();
    char answer[12];
    bool status = false;
    status = start_hangman(arr[temp], answer, size);
    if (status){
        cout << "Congratulations! You guessed it right." << endl;
    }
    else {
        cout << "Oh No! Hanged *_*" << endl;
        cout << "The correct answer was: " << arr[temp] << endl;
    }

    return 0;
}