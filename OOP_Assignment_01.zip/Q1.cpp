//Faraz_Hayder_22I-2687_Assignment#1

#include<iostream>
using namespace std;

//Recursive function to find the length of a string
int find_Length(string s, int counter) //Counter will start from zero initially
{
	if (s[counter] == '\0'){ //Base case, i.e. when the end of the string is reached
		return counter;
	}
	return find_Length (s, counter+1); //Calling function recursively
}

struct String_Manipulation {

	int Calculate_length (string s)
	{
		int length;
		length = find_Length (s, 0);
		return length;
	}

	bool substring (string main, string str)
	{
		bool status = false;
		int main_length = 0; 
		int str_length = 0;
		main_length = find_Length (main, 0);
		str_length = find_Length (str, 0);

		for (int i=0; i<main_length; i++){ //This loop will run till the end of the main
			if (main[i]==str[0] || main[i]==(str[0]-32) || main[i]==(str[0]+32)){ //If the letter of the main is equal to first letter of the str. Here +- 32 is used to compare the letters insensitive to the case
				if (i==0){ //If the first letter of str is same as the first letter of the main
					for (int j=0; j<str_length; j++){ //This loop will run till the end of the str
							if (main[i] == str[j] || main[i]==(str[j]-32) || main[i]==(str[j]+32)){ //Compares main and str parallel
								status = true;
								i++;
							}
							else {
								status = false;
							}
						}
						if (main[i] == ' '){ //Check if the word ends here or is it infact a part of a word. E.g "Thesis", in this case, for "The", it will return "false" as "the" is not present as a separate word 
							status = true;
						}
						else {
							status = false;
						}
						if (status){
							break;
						}
				}
				if (main[i-1] == ' '){ //If the first letter of str is same as the first letter of the main, in that case, -> To differentiate between a complete word. E.g. "This" & "is", without this condition, there would be no differentiation between the two and the function would return "true" for "is".
					for (int j=0; j<str_length; j++){ //This loop will run till the end of the str
						if (main[i] == str[j] || main[i]==(str[j]-32) || main[i]==(str[j]+32)){ //Compares main and str parallel
							status = true;
							i++;
						}
						else {
							status = false;
						}
					}
					if (status){
						break;
					}
				}
			}
		}
		return status;
	}

	int substring_position (string main, string str)
	{
		int index = -1;
		bool status = false;
		int main_length = 0, str_length = 0;
		main_length = find_Length (main, 0);
		str_length = find_Length (str, 0);

		//First finding substring: 
		for (int i=0; i<main_length; i++){
			if (main[i]==str[0] || main[i]==(str[0]-32) || main[i]==(str[0]+32)){
				if (i==0){
					for (int j=0; j<str_length; j++){
							if (main[i] == str[j] || main[i]==(str[j]-32) || main[i]==(str[j]+32)){
								status = true;
								i++;
								index = i; //This is the additional line of code to find the starting index of the string
							}
							else {
								status = false;
							}
						}
						if (main[i] == ' '){
							status = true;
						}
						else {
							status = false;
						}
						if (status){
							break;
						}
				}
				if (main[i-1] == ' '){
					for (int j=0; j<str_length; j++){
						if (main[i] == str[j] || main[i]==(str[j]-32) || main[i]==(str[j]+32)){
							status = true;
							i++;
							index = i;
						}
						else {
							status = false;
						}
					}
					if (status){
						break;
					}
				}
			}
		}
		if (status){ //If substring is present
			index = index - str_length; //finding the starting index
			return index;
		}
		else { //Otherwise returning negative 1
			index = -1;
			return index;
		}
		return index;
	}
};

main()
{

	String_Manipulation str;

	//Calculating length of the string
	int length = 0;
	length = str.Calculate_length("This is a test");
	cout << "The length of the string is: " << length << endl;

	//Checking for substring:
	bool check_substring;
	check_substring = str.substring("This is a test", "This"); //0
	if (check_substring){
		cout << "The substring is present." << endl;
	}
	else {
		cout << "The substring is absent." << endl;
	}
	check_substring = str.substring("This is a test", "this"); //1
	if (check_substring){
		cout << "The substring is present." << endl;
	}
	else {
		cout << "The substring is absent." << endl;
	}
	check_substring = str.substring("I am taking the OOP Class", "OOP"); //2
	if (check_substring){
		cout << "The substring is present." << endl;
	}
	else {
		cout << "The substring is absent." << endl;
	}
	check_substring = str.substring("I am taking the OOP Class", "taking"); //3
	if (check_substring){
		cout << "The substring is present." << endl;
	}
	else {
		cout << "The substring is absent." << endl;
	}
	check_substring = str.substring("I am taking the OOP Class", "that OOP"); //4
	if (check_substring){
		cout << "The substring is present." << endl;
	}
	else {
		cout << "The substring is absent." << endl;
	}
	check_substring = str.substring("I am taking the OOP Class", "Taking the oop class and doing the assignment"); //5
	if (check_substring){
		cout << "The substring is present." << endl;
	}
	else {
		cout << "The substring is absent." << endl;
	}
	check_substring = str.substring("I am taking the OOP Class", "the OOP"); //6
	if (check_substring){
		cout << "The substring is present." << endl;
	}
	else {
		cout << "The substring is absent." << endl;
	}

	//Finding the starting index of the substring:
	int index = 0;
	index = str.substring_position("This is a test", "is");
	cout << "The starting index of the substring is: " << index << endl;
	index = 0;
	index = str.substring_position("This is a test", "This");
	cout << "The starting index of the substring is: " << index << endl;

}