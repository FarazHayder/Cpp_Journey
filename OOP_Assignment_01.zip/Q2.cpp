//Faraz_Hayder_22I-2687_Assignment#1

#include<iostream>
using namespace std;

int liftup(int current_floor,int requested_floor );
int liftdown(int current_floor,int requested_floor );

int lift_operating_system(int requested_floor, int current_floor, char lift_status)
{
	if (requested_floor<-1 || requested_floor>4){
		while (requested_floor<-1 || requested_floor>4){
			cout<<"\nInvalid choice of floor. Please! select a valid floor. THANK YOU!"<<endl;
			cout << endl << "Enter Floor of choice (-1 - 0 - 1 - 2 - 3 - 4): ";
			cin >> requested_floor;
		}
	}
	if (lift_status=='W'){
		if (requested_floor>current_floor){
			//lift goes up
			return liftup(current_floor, requested_floor);
		}
		if (requested_floor<current_floor){
			//lift goes down
			return liftdown(current_floor, requested_floor);
		}
		if (requested_floor==current_floor){
			//lift doesn't move
			cout<<"\nYou are already on this floor."<<endl;;
			return current_floor;
		}
	}
}
int liftup(int current_floor,int requested_floor )
{
	//recurrsive funcation to take lift up
	if (requested_floor==current_floor){
		return current_floor;
	}
	return liftup(current_floor+1, requested_floor);
}
int liftdown(int current_floor,int requested_floor )
{
	//recurrsive funcation to bring the lift down
	if (requested_floor==current_floor){
		return current_floor;
	}
	return liftup(current_floor-1, requested_floor);
}
char halt_lift(char status)
{
	//halts the lift, no up and down operation can be performed. Stored H for halting
	status = 'H';
	return status;
}
char un_halt_lift(char status)
{
	//Unhatls the lift. Store W which represents that the lift is working
	status = 'W';
	return status;
}

int main()
{
	int total_floors = 6; // total number of floors
	int current_floor = -1; // starts with basement
	int requested_service; //choice of user
	int requested_floor; //floor the lift goes on
	char status= 'W'; //W for working , H for halted
	while(1)
	{
		cout<<"\nPlease select a function (1 - 2 - 3 - 4) of your choice: ";
		cout<< endl << "1 -> Go to a specific floor";
		cout<< endl << "2 -> Halt Lift";
		cout<< endl << "3 -> Unhalt Lift";
		cout<< endl << "4 -> Exit" << endl;
		cout<<"You are currently on floor: "<<current_floor<<endl<<endl;
		cout<<"You want to: ";
		cin >> requested_service;
		switch(requested_service){
			case 1:
				{
					if (status == 'W'){
						cout << endl << "Enter Floor of choice (-1 - 0 - 1 - 2 - 3 - 4): ";
						cin >> requested_floor;
						current_floor = lift_operating_system(requested_floor, current_floor, status); 
					}
					else if (status == 'H'){
						cout<<"\nSorry! The lift is under maintenance."<<endl;
					}
					break;
				}
			case 2:
				{
					status = halt_lift(status);
					cout<<"\nThe lift is now under maintenance."<<endl;
					break;
				}
			case 3:
				{
					status = un_halt_lift(status);
					cout<<"\nThe lift is now operational again."<<endl;
					break;
				}
			case 4:
				{
					exit(0);
					break;
				}
			default:
				{
					cout<<"\nInvalid function."<<endl<<"Please choose a valid function. THANK YOU!"<<endl;
				}
		}
	}
	return 0;
}
