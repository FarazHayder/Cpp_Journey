/*FarazHayder_I222687_A1*/
#include "FictionalCompany.h"

int main()
{
    // For clearing console screen
    system("cls");
    // Creating an object of the class
    Company<Employee<string>> company;
    // For initializing the company with the data from the file
    company.Initialize();
    // For printing the main menu
    company.MainMenu();

    return 0;
}