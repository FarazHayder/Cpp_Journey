// Faraz_Hayder_22I-2687_Assignment#2

#include <iostream>
#include <string.h>
using namespace std;

void deepcopyCharArr(char *&datamember, const char *argument)
{
    if (argument == nullptr)
    {
        datamember = nullptr;
        return;
    }
    int length = strlen(argument);
    datamember = new char[length + 1];
    for (int i = 0; i <= length; i++)
    {
        datamember[i] = argument[i];
        if (i == length)
        {
            datamember[length] = '\0';
        }
    }
}

class Pizza
{
    double price;
    bool is_ready;
    char *size;
    char *topping;
    char *name;

public:
    // Default constructor
    Pizza()
    {
        price = 0;
        is_ready = false;
        size = nullptr;
        topping = nullptr;
        name = nullptr;
    }
    // Parametrized constructor
    Pizza(char *toppingVal, double priceVal)
    {
        is_ready = false;
        size = nullptr;
        name = nullptr;
        price = priceVal;
        deepcopyCharArr(topping, toppingVal);
    }
    // Parametrized constructor
    Pizza(char *toppingVal, double priceVal, char *nameVal, char *sizeVal, bool ready_status)
    {
        price = priceVal;
        is_ready = ready_status;
        deepcopyCharArr(size, sizeVal);
        deepcopyCharArr(topping, toppingVal);
        deepcopyCharArr(name, nameVal);
    }
    // Copy constructor
    Pizza(const Pizza &pizza)
    {
        price = pizza.price;
        is_ready = pizza.is_ready;
        deepcopyCharArr(size, pizza.size);
        deepcopyCharArr(topping, pizza.topping);
        deepcopyCharArr(name, pizza.name);
    }
    // Setters and Getters
    void setTopping(char *toppingVal)
    {
        deepcopyCharArr(topping, toppingVal);
    }
    char *getTopping()
    {
        return topping;
    }
    void setPrice(double priceVal)
    {
        price = priceVal;
    }
    double getPrice()
    {
        return price;
    }
    void setName(char *nameVal)
    {
        deepcopyCharArr(name, nameVal);
    }
    char *getName()
    {
        return name;
    }
    void setSize(char *sizeVal)
    {
        deepcopyCharArr(size, sizeVal);
    }
    char *getSize()
    {
        return size;
    }
    // Functions
    void makePizza()
    {
        if (topping != NULL)
        {
            is_ready = true;
        }
        else
        {
            is_ready = false;
        }
    }
    bool check_status()
    {
        if (is_ready)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
};