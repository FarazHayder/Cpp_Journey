// Faraz_Hayder_22I-2687_Assignment#2

#include <iostream>
#include <string>
#include <bitset>
using namespace std;

// Note: All the functions, involving bits, are solved assuming 8-bit system.

class Integer
{
    int num;
    string str;

public:
    // Default constructor
    Integer()
    {
        num = 0;
        str = "0";
    }
    // Parametrized constructor
    Integer(int n)
    {
        num = n;
        str = to_string(n);
    }
    // Parametrized constructor
    Integer(string str)
    {
        num = stoi(str);
        this->str = str;
    }
    // Setter
    void set(int n)
    {
        num = n;
        str = to_string(n);
    }
    // Funtions
    int get() const
    {
        return num;
    }
    int bitCount()
    {
        string eightBitStr = bitset<8>(num).to_string(); // Converting to 2's complement binary. (8-bit System)
        int oneBitCounter = 0;
        for (int i = 0; i < 8; i++)
        {
            if (eightBitStr[i] == '1')
            {
                oneBitCounter++;
            }
        }
        return oneBitCounter;
    }
    int compareTo(Integer obj)
    {
        if (num == obj.num)
        {
            return 0;
        }
        if (num > obj.num)
        {
            return 1;
        }
        if (num < obj.num)
        {
            return -1;
        }
    }
    double doubleValue()
    {
        return (double)num;
    }
    float floatValue()
    {
        return (float)num;
    }
    Integer plus(const Integer obj)
    {
        Integer temp;
        temp.set(num + obj.get());
        return temp;
    }
    Integer minus(const Integer obj)
    {
        Integer temp;
        temp.set(num - obj.get());
        return temp;
    }
    Integer multiple(const Integer obj)
    {
        Integer temp;
        temp.set(num * obj.get());
        return temp;
    }
    Integer divide(const Integer obj)
    {
        Integer temp;
        temp.set(num / obj.get());
        return temp;
    }
    static int numberOfLeadingZeros(int i)
    {
        string eightBitStr = bitset<8>(i).to_string(); // Converting to 2's complement binary. (8-bit System)
        int leadingZeroesCounter = 0;
        for (int i = 0; i < 8; i++)
        {
            if (eightBitStr[i] == '1')
            {
                leadingZeroesCounter = i;
                break;
            }
        }
        return leadingZeroesCounter;
    }
    static int numberOfTrailingZeros(int i)
    {
        string eightBitStr = bitset<8>(i).to_string(); // Converting to 2's complement binary. (8-bit System)
        int trailingZeroesCounter = 0;
        for (int i = 0; i < 8; i++)
        {
            if (eightBitStr[i] == '1')
            {
                int temp = i;
                for (int j = temp; j < 8; j++)
                {
                    if (eightBitStr[j] == '0')
                    {
                        trailingZeroesCounter++;
                    }
                }
                break;
            }
        }
        return trailingZeroesCounter;
    }

    static string toBinaryString(int i)
    {
        string binaryStr = "";
        if (i == 0)
        {
            return "0";
        }
        if (i > 0)
        {
            while (i > 0)
            {
                binaryStr = to_string(i % 2) + binaryStr;
                i = i / 2;
            }
            return binaryStr;
        }
        if (i < 0)
        {
            i = abs(i);
            while (i > 0)
            {
                binaryStr = to_string(i % 2) + binaryStr;
                i = i / 2;
            }
            binaryStr = "1" + binaryStr;
            return binaryStr;
        }
    }

    static string toHexString(int i)
    {
        string hexStr = "";
        if (i == 0)
        {
            return "0";
        }
        if (i > 0)
        {
            while (i > 0)
            {
                if ((i % 16) < 10)
                {
                    hexStr = to_string(i % 16) + hexStr;
                }
                else if ((i % 16) >= 10)
                {
                    int hexChar = i % 16;
                    switch (hexChar)
                    {
                    case 10:
                        hexStr = "A" + hexStr;
                        break;
                    case 11:
                        hexStr = "B" + hexStr;
                        break;
                    case 12:
                        hexStr = "C" + hexStr;
                        break;
                    case 13:
                        hexStr = "D" + hexStr;
                        break;
                    case 14:
                        hexStr = "E" + hexStr;
                        break;
                    case 15:
                        hexStr = "F" + hexStr;
                        break;
                    }
                }
                i = i / 16;
            }
            return hexStr;
        }
        if (i < 0)
        {
            i = abs(i);
            while (i > 0)
            {
                if ((i % 16) < 10)
                {
                    hexStr = to_string(i % 16) + hexStr;
                }
                else if ((i % 16) >= 10)
                {
                    int hexChar = i % 16;
                    switch (hexChar)
                    {
                    case 10:
                        hexStr = "A" + hexStr;
                        break;
                    case 11:
                        hexStr = "B" + hexStr;
                        break;
                    case 12:
                        hexStr = "C" + hexStr;
                        break;
                    case 13:
                        hexStr = "D" + hexStr;
                        break;
                    case 14:
                        hexStr = "E" + hexStr;
                        break;
                    case 15:
                        hexStr = "F" + hexStr;
                        break;
                    }
                }
                i = i / 16;
            }
            hexStr = "0x-" + hexStr;
            return hexStr;
        }
    }

    static string toOctString(int i)
    {
        string octStr = "";
        if (i == 0)
        {
            return "0";
        }
        if (i > 0)
        {
            while (i > 0)
            {
                octStr = to_string(i % 8) + octStr;
                i = i / 8;
            }
            return octStr;
        }
        if (i < 0)
        {
            i = abs(i);
            while (i > 0)
            {
                octStr = to_string(i % 8) + octStr;
                i = i / 8;
            }
            octStr = "-" + octStr;
            return octStr;
        }
    }
};