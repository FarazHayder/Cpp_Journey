/*FarazHayder_I222687_A1*/
#if !defined(Header)
#define Header

#include <iostream>
#include <fstream>
#include <conio.h> //For getch()
#include <ctime>
using namespace std;

template <typename T>
struct Employee
{
    T name;
    T ID;
    T salary;
    T joiningDate;
    T designation;

    // Printing information of employees
    void PrintEmployeeInfo()
    {
        cout << "Employee Name: " << name << endl;
        cout << "Employee ID: " << ID << endl;
        cout << "Salary: " << salary << endl;
        cout << "Date of Joining: " << joiningDate << endl;
        cout << "Designation: " << designation << endl
             << endl;
    }
    void PrintEmployeeInfo(const string skip)
    {
        if (skip != "name")
        {
            cout << "Employee Name: " << name << endl;
        }
        if (skip != "ID")
        {
            cout << "Employee ID: " << ID << endl;
        }
        if (skip != "salary")
        {
            cout << "Salary: " << salary << endl;
        }
        if (skip != "joiningDate")
        {
            cout << "Date of Joining: " << joiningDate << endl;
        }
        if (skip != "designation")
        {
            cout << "Designation: " << designation << endl;
        }
        cout << endl;
    }
};
int comparisonsAndSwaps[] = {0, 0};
// BubbleSorting the array of employees
template <typename T, typename U>
int *BubbleSortEmployees(T &arr, int totalNumberOfEmployees, U basis)
{
    comparisonsAndSwaps[0] = 0;
    comparisonsAndSwaps[1] = 0;
    for (int i = 0; i < totalNumberOfEmployees - 1; i++)
    {
        int swaps = 0; // This checks whether swapping occurs or not
        for (int j = 0; j < totalNumberOfEmployees - i - 1; j++)
        {
            comparisonsAndSwaps[0]++;
            if (basis == "name")
            {
                if (arr[j].name > arr[j + 1].name)
                {
                    Employee<string> temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                    comparisonsAndSwaps[1]++;
                    swaps = 1;
                }
            }
            else if (basis == "ID")
            {
                if (arr[j].ID > arr[j + 1].ID)
                {
                    Employee<string> temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                    comparisonsAndSwaps[1]++;
                    swaps = 1;
                }
            }
            else if (basis == "salary")
            {
                if (arr[j].salary > arr[j + 1].salary)
                {
                    Employee<string> temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                    comparisonsAndSwaps[1]++;
                    swaps = 1;
                }
            }
            else if (basis == "joiningDate")
            {
                if (arr[j].joiningDate > arr[j + 1].joiningDate)
                {
                    Employee<string> temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                    comparisonsAndSwaps[1]++;
                    swaps = 1;
                }
            }
            else if (basis == "designation")
            {
                if (arr[j].designation > arr[j + 1].designation)
                {
                    Employee<string> temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                    comparisonsAndSwaps[1]++;
                    swaps = 1;
                }
            }
        }
        if (swaps == 0) // This shows that no swapping happened, hence array is sorted.
        {
            break;
        }
    }
    return comparisonsAndSwaps;
}
// Selection Sorting the array of employees
template <typename T, typename U>
int *SelectionSortEmployees(T &arr, int totalNumberOfEmployees, U basis)
{
    comparisonsAndSwaps[0] = 0;
    comparisonsAndSwaps[1] = 0;
    for (int i = 0; i < totalNumberOfEmployees - 1; i++)
    {
        int minIndex = i;
        for (int j = i + 1; j < totalNumberOfEmployees; j++)
        {
            comparisonsAndSwaps[0]++;
            if (basis == "name")
            {
                if (arr[j].name < arr[minIndex].name)
                {
                    minIndex = j;
                }
            }
            else if (basis == "ID")
            {
                if (arr[j].ID < arr[minIndex].ID)
                {
                    minIndex = j;
                }
            }
            else if (basis == "salary")
            {
                if (arr[j].salary < arr[minIndex].salary)
                {
                    minIndex = j;
                }
            }
            else if (basis == "joiningDate")
            {
                if (arr[j].joiningDate < arr[minIndex].joiningDate)
                {
                    minIndex = j;
                }
            }
            else if (basis == "designation")
            {
                if (arr[j].designation < arr[minIndex].designation)
                {
                    minIndex = j;
                }
            }
        }
        if (minIndex != i)
        {
            Employee<string> temp = arr[i];
            arr[i] = arr[minIndex];
            arr[minIndex] = temp;
            comparisonsAndSwaps[1]++;
        }
    }
    return comparisonsAndSwaps;
}
// Insertion Sorting the array of employees
template <typename T, typename U>
int *InsertionSortEmployees(T &arr, int totalNumberOfEmployees, U basis)
{
    comparisonsAndSwaps[0] = 0;
    comparisonsAndSwaps[1] = 0;
    for (int i = 1; i < totalNumberOfEmployees; i++)
    {
        Employee<string> key = arr[i];
        int j = i - 1;
        while (j >= 0)
        {
            comparisonsAndSwaps[0]++;
            if (basis == "name" && arr[j].name > key.name)
            {
                arr[j + 1] = arr[j];
                j--;
                comparisonsAndSwaps[1]++;
            }
            else if (basis == "ID" && arr[j].ID > key.ID)
            {
                arr[j + 1] = arr[j];
                j--;
                comparisonsAndSwaps[1]++;
            }
            else if (basis == "salary" && arr[j].salary > key.salary)
            {
                arr[j + 1] = arr[j];
                j--;
                comparisonsAndSwaps[1]++;
            }
            else if (basis == "joiningDate" && arr[j].joiningDate > key.joiningDate)
            {
                arr[j + 1] = arr[j];
                j--;
                comparisonsAndSwaps[1]++;
            }
            else if (basis == "designation" && arr[j].designation > key.designation)
            {
                arr[j + 1] = arr[j];
                j--;
                comparisonsAndSwaps[1]++;
            }
            else
            {
                break;
            }
        }
        arr[j + 1] = key;
    }
    return comparisonsAndSwaps;
}

// Finds the size of the string
template <typename T>
int Size(T text)
{
    int size = 0;
    while (text[size] != '\0')
    {
        size++;
    }
    return size;
}

// Finds the starting index of the substring within string
template <typename T, typename U>
int FindStartingIndex(T text, U subText)
{
    int sizeOfSubText = Size(subText);
    int sizeOfText = Size(text);
    if (sizeOfSubText == 1)
    {
        for (int i = 0; i < sizeOfText; i++)
        {
            if (text[i] == subText[0])
            {
                return i;
            }
        }
    }
    else
    {
        for (int i = 0; i < sizeOfText; i++)
        {
            if (text[i] == subText[0])
            {
                int temp = 0;
                int store = i;
                for (int j = 0; j < sizeOfSubText; j++)
                {
                    if (text[i] != subText[j])
                    {
                        break;
                    }
                    temp++;
                    i++;
                }
                i = store;
                if (temp == sizeOfSubText)
                {
                    return i;
                }
            }
        }
    }
    return -1;
}

// Finds the ending index of the substring within string
template <typename T, typename U>
int FindEndingIndex(T text, U subText)
{
    int sizeOfSubText = Size(subText);
    int sizeOfText = Size(text);
    if (sizeOfSubText == 1)
    {
        for (int i = 0; i < sizeOfText; i++)
        {
            if (text[i] == subText[0])
            {
                return i;
            }
        }
    }
    else
    {
        for (int i = 0; i < sizeOfText; i++)
        {
            if (text[i] == subText[0])
            {
                int temp = 0;
                int store = i;
                for (int j = 0; j < sizeOfSubText; j++)
                {
                    if (text[i] != subText[j])
                    {
                        break;
                    }
                    temp++;
                    i++;
                }
                i = store;
                if (temp == sizeOfSubText)
                {
                    return i + sizeOfSubText - 1;
                }
            }
        }
    }
    return -1;
}

// Ignores the part of the text before subtext
template <typename T, typename U>
void PreIgnore(T &text, U subtext)
{
    int index = FindStartingIndex(text, subtext);
    if (index == -1)
    {
        return;
    }
    int size = Size(text);
    T text1 = text;
    text = "";
    for (int j = index; j < size; j++)
    {
        text += text1[j];
    }
}

// Ignores the part of the text before subtext and the subtext itself
template <typename T, typename U>
void PreIgnoreIt(T &text, U subtext)
{
    int index = FindEndingIndex(text, subtext);
    if (index == -1)
    {
        return;
    }
    int size = Size(text);
    T text1 = text;
    text = "";
    for (int j = index + 1; j < size; j++)
    {
        text += text1[j];
    }
}
// Ignores the part of the text before subtext and the subtext itself and also ignores the subtext1
template <typename T, typename U, typename V>
T PreIgnoreIt(T text, U subtext, V subtext1)
{
    int index = FindEndingIndex(text, subtext);
    if (index != -1)
    {
        int size = Size(text);
        int sizeOfSubText1 = Size(subtext1);
        T text1 = text;
        text = "";
        for (int j = index + 1; j < size; j++)
        {
            text += text1[j];
        }
    }
    int index1 = FindStartingIndex(text, subtext1);
    if (index1 != -1)
    {
        int size = Size(text);
        int sizeOfSubText1 = Size(subtext1);
        T text1 = text;
        text = "";
        for (int j = 0; j < size; j++)
        {
            if (j == index1)
            {
                j += sizeOfSubText1 - 1;
            }
            else
            {
                text += text1[j];
            }
        }
    }
    return text;
}

// Ignores the part of the text before subtext and the subtext itself and also the part of the text after subtext1 and subtext1 itself
template <typename T, typename U, typename V>
T PreIgnoreItAndPostIgnoreIt(T text, U subtext, V subtext1)
{
    int index = FindEndingIndex(text, subtext);
    if (index != -1)
    {
        int size = Size(text);
        int sizeOfSubText1 = Size(subtext1);
        T text1 = text;
        text = "";
        for (int j = index + 1; j < size; j++)
        {
            text += text1[j];
        }
    }
    int index1 = FindStartingIndex(text, subtext1);
    if (index1 != -1)
    {
        int size = Size(text);
        int sizeOfSubText1 = Size(subtext1);
        T text1 = text;
        text = "";
        for (int j = 0; j < index1; j++)
        {
            text += text1[j];
        }
    }
    return text;
}

// Ignores the part of the text after subtext and subtext itself
template <typename T, typename U>
T PostIgnoreIt(T text, U subtext)
{
    int index = FindStartingIndex(text, subtext);
    if (index != -1)
    {
        int size = Size(text);
        int sizeOfSubText = Size(subtext);
        T text1 = text;
        text = "";
        for (int j = 0; j < index; j++)
        {
            text += text1[j];
        }
    }
    return text;
}

// To convert the string to numerics
template <typename T, typename U>
U StringToNumeric(T text)
{
    char numbers[10] = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9'};
    int size = Size(text);
    U numeric = 0;
    for (int i = 0; i < size; i++)
    {
        for (int j = 0; j < 10; j++)
        {
            if (text[i] == numbers[j])
            {
                numeric = numeric * 10 + j;
            }
        }
    }
    return numeric;
}

// To convert the numeric to string
template <typename T>
string NumericToString(T numeric)
{
    char numbers[10] = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9'};
    string text = "";
    int count = 0;
    while (numeric != 0)
    {
        int remainder = numeric % 10;
        numeric /= 10;
        text = numbers[remainder] + text;
        count++;
        if (count == 3 && numeric != 0)
        {
            text = "," + text;
            count = 0;
        }
    }
    return text;
}

#endif // Header