// Faraz_Hayder_22I-2687_Assignment#2

#include <iostream>
using namespace std;

void deepcopyCharArr(char *&datamember, const char *argument)
{
    if (argument == nullptr)
    {
        datamember = nullptr;
        return;
    }
    int length = strlen(argument);
    datamember = new char[length + 1];
    for (int i = 0; i <= length; i++)
    {
        datamember[i] = argument[i];
        if (i == length)
        {
            datamember[length] = '\0';
        }
    }
}

class Library
{
    char *bookTitle;
    char *author;
    int bookID;
    int quantity;
    float price;
    static int totalBooks;

public:
    Library()
    {
        char *bookTitle = nullptr;
        char *author = nullptr;
        int bookID = 0;
        int quantity = 0;
        float price = 0;
        totalBooks++;
    }
    char *getBookTitle()
    {
        return bookTitle;
    }
    char *getAuthor()
    {
        return author;
    }
    int getBookID()
    {
        return bookID;
    }
    int getQuantity()
    {
        return quantity;
    }
    float getPrice()
    {
        return price;
    }
    void setBookTitle(char *title)
    {
        deepcopyCharArr(bookTitle, title);
    }
    void setAuthor(char *authorName)
    {
        deepcopyCharArr(author, authorName);
    }
    void setBookID(int bookID)
    {
        this->bookID = bookID;
    }
    void setQuantity(int quantity)
    {
        if (quantity < 0)
        {
            cout << "Invalid quantity.";
            return;
        }
        this->quantity = quantity;
    }
    void setPrice(float price)
    {
        if (price < 0)
        {
            cout << "Invalid price.";
            return;
        }
        this->price = price;
    }
    static void setTotalBooks(int total)
    {
        totalBooks = total;
    }
    static int getTotalBooks()
    {
        return totalBooks;
    }
    void calcTotalPrice()
    {
        float totalPrice = price * quantity;
        cout << "Total price: " << totalPrice;
    }
    static int getTotalBooks()
    {
        return totalBooks;
    }
};

Library getBook_at(Library books[100], int index)
{
    return books[index];
}

void addBook(Library books[100], Library newBook)
{
    for (int i = 0; i < 100; i++)
    {
        if (books[i].getBookID() == 0)
        {
            books[i] = newBook;
            return;
        }
    }
}

void removeBook(Library books[100], int bookID)
{
    for (int i = 0; i < 100; i++)
    {
        if (books[i].getBookID() == bookID)
        {
            for (int j = i; j < 99; j++)
            {
                books[j] = books[j + 1];
            }
            return;
        }
    }
}

void SortByTitle(Library books[100])
{
    for (int i = 0; i < 100; i++)
    {
        for (int j = i + 1; j < 100; j++)
        {
            if (strcmp(books[i].getBookTitle(), books[j].getBookTitle()) > 0)
            {
                Library temp = books[i];
                books[i] = books[j];
                books[j] = temp;
            }
        }
    }
}

void SortByAuthor(Library books[100])
{
    for (int i = 0; i < 100; i++)
    {
        for (int j = i + 1; j < 100; j++)
        {
            if (strcmp(books[i].getAuthor(), books[j].getAuthor()) > 0)
            {
                Library temp = books[i];
                books[i] = books[j];
                books[j] = temp;
            }
        }
    }
}

void SortByPrice(Library books[100])
{
    for (int i = 0; i < 100; i++)
    {
        for (int j = i + 1; j < 100; j++)
        {
            if (books[i].getPrice() > books[j].getPrice())
            {
                Library temp = books[i];
                books[i] = books[j];
                books[j] = temp;
            }
        }
    }
}

bool searchByTittle(Library books[10], char *titlename)
{
    for (int i = 0; i < 10; i++)
    {
        if (strcmp(books[i].getBookTitle(), titlename) == 0)
        {
            return true;
        }
    }
    return false;
}

Library mostExpensiveBook(Library books[10])
{
    Library max = books[0];
    for (int i = 0; i < 10; i++)
    {
        if (books[i].getPrice() > max.getPrice())
        {
            max = books[i];
        }
    }
    return max;
}