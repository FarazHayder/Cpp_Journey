// Faraz_Hayder_22I-2687_Assignment#2

#include <iostream>
#include <string>
#include <string.h>
using namespace std;

void deepcopyCharArr(char *&datamember, const char *argument)
{
    if (argument == nullptr)
    {
        datamember = nullptr;
        return;
    }
    int length = strlen(argument);
    datamember = new char[length + 1];
    for (int i = 0; i <= length; i++)
    {
        datamember[i] = argument[i];
        if (i == length)
        {
            datamember[length] = '\0';
        }
    }
}

class SavingAccount
{
    char *name;
    float annualInterestRate;
    double savingBalance;
    char *accountNum;

    friend float calculateMonthlyInterest(SavingAccount *saver);
    friend void modifyInterestRate(SavingAccount *saver, float newValue);

public:
    SavingAccount()
    {
        name = nullptr;
        annualInterestRate = 0;
        savingBalance = 0;
        accountNum = nullptr;
    }
    SavingAccount(char *nameVal, float interest, double balance, char *accNum)
    {
        deepcopyCharArr(name, nameVal);
        annualInterestRate = interest;
        savingBalance = balance;
        deepcopyCharArr(accountNum, accNum);
    }
    ~SavingAccount()
    {
        delete[] name;
        name = nullptr;
        delete[] accountNum;
        accountNum = nullptr;
    }
    char *getName()
    {
        return name;
    }
    void setName(char *newName)
    {
        deepcopyCharArr(name, newName);
    }
    float getAnnualInterestRate()
    {
        return annualInterestRate;
    }
    void setAnnualInterestRate(float interestVal)
    {
        annualInterestRate = interestVal;
    }
    double getSavingBalance()
    {
        return savingBalance;
    }
    void setSavingBalance(double balanceVal)
    {
        savingBalance = balanceVal;
    }
    char *getAccountNum()
    {
        return accountNum;
    }
    void setAccountNum(char *newAccountNum)
    {
        deepcopyCharArr(accountNum, newAccountNum);
    }
};

void OpenCustomerAcccount(SavingAccount *savers[], int accountsOpen, char *NameVal, double balance)
{
    if (accountsOpen >= 100)
    {
        cout << "Maximum accounts' limit reached." << endl
             << "More accounts cannot be opened." << endl;
        return;
    }

    char *accNum = new char[5];
    string accNumTemp = "";
    if (accountsOpen < 10)
    {
        accNumTemp = "SA0" + to_string(accountsOpen);
    }
    else
    {
        accNumTemp = "SA" + to_string(accountsOpen);
    }
    strcpy(accNum, accNumTemp.c_str());
    savers[accountsOpen] = new SavingAccount(NameVal, 0, balance, accNum);
    accountsOpen++;
}

float calculateMonthlyInterest(SavingAccount *saver)
{
    return (saver->savingBalance * saver->annualInterestRate) / 12;
}

void modifyInterestRate(SavingAccount *&saver, float newValue)
{
    saver->setAnnualInterestRate(newValue);
}

int SearchCustomer(SavingAccount *savers[], int accountsOpen, char *accountNum)
{
    for (int i = 0; i < accountsOpen; i++)
    {
        if (strcmp(savers[i]->getAccountNum(), accountNum))
        {
            return i;
        }
    }
    return -1;
}

bool UpdateAccountBalance(SavingAccount *savers[], int accountsOpen, char *accountNumVal, double balanceVal)
{
    for (int i = 0; i < accountsOpen; i++)
    {
        if (strcmp(savers[i]->getAccountNum(), accountNumVal) == 0)
        {
            savers[i]->setSavingBalance(balanceVal);
            return true;
        }
    }
    return false;
}
