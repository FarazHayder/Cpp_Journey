// Faraz_Hayder_22I-2687_Assignment#2

#include <iostream>
using namespace std;

bool equal(char *a, char *b)
{
    int i = 0;
    while (a[i] != '\0' && b[i] != '\0')
    {
        if (a[i] != b[i])
        {
            return false;
        }
        i++;
    }
    return true;
}

void deepcopyCharArr(char *&datamember, const char *argument)
{
    if (argument == nullptr)
    {
        datamember = nullptr;
        return;
    }
    // Finding length of str:
    int length = 0;
    for (int i = 0; argument[i] != '\0'; i++)
    {
        length = i;
    }
    length++;
    datamember = new char[length + 1];
    for (int i = 0; i <= length; i++)
    {
        datamember[i] = argument[i];
        if (i == length)
        {
            datamember[length] = '\0';
        }
    }
}

class String
{
    char *data;
    int size;

public:
    // Default constructor:
    String()
    {
        data = nullptr;
        size = 0;
    }
    // Parametrized constructor:
    String(int length)
    {
        size = length;
        data = new char[size];
    }
    // Parametrized constructor:
    String(char *str)
    {
        deepcopyCharArr(data, str);
        // Finding length of str:
        int length = 0;
        for (int i = 0; data[i] != '\0'; i++)
        {
            length = i;
        }
        length++;
        size = length;
    }
    // Copy constructor:
    String(const String &str)
    {
        deepcopyCharArr(data, str.data);
        size = str.size;
    }
    // Destructor
    ~String()
    {
        delete[] data;
        data = nullptr;
    }
    // Functions:
    int stringLength()
    {
        // Finding length of string:
        int length = 0;
        for (int i = 0; data[i] != '\0'; i++)
        {
            length = i;
        }
        length++;
        return length;
    }
    void clear()
    {
        data = nullptr;
        size = 0;
    }
    bool isEmpty()
    {
        if (data == nullptr && size == 0)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    int charAt(char c)
    {
        for (int i = 0; i < size; i++)
        {
            if (data[i] == c)
            {
                return i;
            }
        }
        return -1;
    }
    char *getdata()
    {
        return data;
    }
    bool equalsIgnoreCase(char *str)
    {
        // Finding length of str:
        int length = 0;
        for (int i = 0; str[i] != '\0'; i++)
        {
            length = i;
        }
        length++;
        if (length == size)
        {
            for (int i = 0; i < size; i++)
            {
                if (data[i] == str[i] || data[i] == str[i] + 32 || data[i] == str[i] - 32)
                {
                }
                else
                {
                    return false;
                }
            }
            return true;
        }
        else
        {
            return false;
        }
    }
    bool isEqual(char *str)
    {
        // Finding length of str:
        int length = 0;
        for (int i = 0; data[i] != '\0'; i++)
        {
            length = i;
        }
        length++;
        if (length == size)
        {
            for (int i = 0; i < size; i++)
            {
                if (data[i] == str[i])
                {
                }
                else
                {
                    return false;
                }
            }
            return true;
        }
        else
        {
            return false;
        }
    }
    void print()
    {
        if (size == 0)
        {
            cout << "NULL" << endl;
        }
        else
        {
            for (int i = 0; i < size; i++)
            {
                cout << data[i];
            }
            cout << endl;
        }
    }
    char *substring(char *&substr, int startIndex)
    {
        // Finding length of str:
        int length = 0;
        for (int i = 0; data[i] != '\0'; i++)
        {
            length = i;
        }
        length++;
        int lengthSubStr = 0;
        for (int i = 0; substr[i] != '\0'; i++)
        {
            lengthSubStr = i;
        }
        lengthSubStr++;
        char *tempSubStr = new char[lengthSubStr + 1];
        tempSubStr[lengthSubStr] = '\0';
        int temp = 0;
        for (int i = startIndex; i < length; i++)
        {
            if (data[i] == substr[temp])
            {
                tempSubStr[temp] = substr[temp];
                temp++;
                bool check = equal(tempSubStr, substr);
                if (check)
                {
                    int count = (i - lengthSubStr) + 1;
                    int sizeofTempStr = (length - 1 - count) + 1;
                    char *tempStr = new char[sizeofTempStr + 1];
                    int j = 0;
                    for (int k = count; k < sizeofTempStr + count; k++)
                    {
                        tempStr[j] = data[k];
                        j++;
                    }
                    tempStr[sizeofTempStr] = '\0';
                    return tempStr;
                }
            }
            else
            {
                temp = 0;
            }
        }
        return NULL;
    }
    char *substring(char *&substr, int startIndex, int endIndex)
    {
        // Finding length of str:
        int length = 0;
        for (int i = 0; data[i] != '\0'; i++)
        {
            length = i;
        }
        length++;
        int lengthSubStr = 0;
        for (int i = 0; substr[i] != '\0'; i++)
        {
            lengthSubStr = i;
        }
        lengthSubStr++;
        char *tempSubStr = new char[lengthSubStr + 1];
        tempSubStr[lengthSubStr] = '\0';
        int temp = 0;
        for (int i = startIndex; i < length; i++)
        {
            if (data[i] == substr[temp])
            {
                tempSubStr[temp] = substr[temp];
                temp++;
                bool check = equal(tempSubStr, substr);
                if (check)
                {
                    int count = (i - lengthSubStr) + 1;
                    int sizeofTempStr = (endIndex - count) + 1;
                    char *tempStr = new char[sizeofTempStr + 1];
                    int j = 0;
                    for (int k = count; k < sizeofTempStr + count; k++)
                    {
                        tempStr[j] = data[k];
                        j++;
                    }
                    tempStr[sizeofTempStr] = '\0';
                    return tempStr;
                }
            }
            else
            {
                temp = 0;
            }
        }
        return NULL;
    }
};