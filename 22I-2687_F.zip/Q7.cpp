// Faraz_Hayder_22I-2687_Assignment#2

#include <iostream>
using namespace std;

class Student
{
    int stdID;
    string Name;
    int numCourses;
    string *courseCodes = new string[numCourses];
    int *courseGrades = new int[numCourses];
    float gpa;

public:
    Student()
    {
        stdID = 0;
        Name = "";
        numCourses = 0;
        courseCodes = nullptr;
        courseGrades = nullptr;
        gpa = 0;
    }
    int getStdID()
    {
        return stdID;
    }
    string getName()
    {
        return Name;
    }
    int getNumCourses()
    {
        return numCourses;
    }
    string getCourseCode(int i)
    {
        return courseCodes[i];
    }
    int getCourseGrade(int i)
    {
        return courseGrades[i];
    }
    float getGPA()
    {
        return gpa;
    }
    void setStdID(int id)
    {
        stdID = id;
    }
    void setName(string firstName)
    {
        Name = firstName;
    }
    void setCourseGrade(string courseCode, int grade)
    {
        int temp = 0;
        for (int i = 0; i < numCourses; i++)
        {
            if (courseCodes[i] == courseCode)
            {
                temp = i;
                break;
            }
        }
        courseGrades[temp] = grade;
    }
    void addCourse(string courseCode, int grade)
    {
        numCourses++;
        int temp = 0;
        for (int i = 0; i < numCourses; i++)
        {
            if (i == numCourses - 1)
            {
                courseCodes[i] = courseCode;
                temp = i;
                break;
            }
        }
        courseGrades[temp] = grade;
    }
    void calcGPA()
    {
        float sum = 0;
        for (int i = 0; i < numCourses; i++)
        {
            sum = sum + courseGrades[i];
        }
        gpa = sum / numCourses;
    }
};

Student getStudentAt(Student students[], int index)
{
    return students[index];
}

float calcClassGPA(Student students[], int numStudents)
{
    float sum = 0;
    for (int i = 0; i < numStudents; i++)
    {
        sum = sum + students[i].getGPA();
    }
    return sum / numStudents;
}

float getMaxGPA(Student students[], int numStudents)
{
    float max = students[0].getGPA();
    for (int i = 0; i < numStudents; i++)
    {
        if (students[i].getGPA() > max)
        {
            max = students[i].getGPA();
        }
    }
    return max;
}

float getMinGPA(Student students[], int numStudents)
{
    float min = students[0].getGPA();
    for (int i = 0; i < numStudents; i++)
    {
        if (students[i].getGPA() < min)
        {
            min = students[i].getGPA();
        }
    }
    return min;
}

void printStudentRecord(Student student)
{
    cout << "Student ID: " << student.getStdID() << endl;
    cout << "Name: " << student.getName() << endl;
    cout << "GPA: " << student.getGPA() << endl;

    for (int i = 0; i < student.getNumCourses(); i++)
    {
        cout << "Course Code: " << student.getCourseCode(i) << " Grade: " << student.getCourseGrade(i) << endl;
    }
}

void printAllStudentRecords(Student students[], int numStudents)
{
    for (int i = 0; i < numStudents; i++)
    {
        cout << "Student record for student number " << i + 1 << ":-" << endl;
        printStudentRecord(students[i]);
        cout << endl;
    }
}