/*FarazHayder_I222687_A1*/
#if !defined(FictionalCompany)
#define FictionalCompany

#include "MyVectorImplementation.h"

template <typename T>
struct Company
{
    MyVector<T> employees;
    int totalNumberOfEmployees = 0;
    int *arr;
    clock_t startTime, endTime;
    double executionTime;

    // Methods:-
    void Initialize()
    {
        ifstream inputFile("Employeedata.txt");

        if (!inputFile)
        {
            throw ios_base::failure("Error: File not found!");
            exit(0);
        }

        // Storing data in our data structure from file
        int i = 0;
        while (true)
        {
            string emptyLine;
            if (inputFile.eof())
            {
                break;
            }
            Employee<string> tempEmployee;
            getline(inputFile, tempEmployee.name);
            getline(inputFile, tempEmployee.ID);
            getline(inputFile, tempEmployee.salary);
            getline(inputFile, tempEmployee.joiningDate);
            getline(inputFile, tempEmployee.designation);
            getline(inputFile, emptyLine); // Skips the empty line in the datasheet

            PreIgnoreIt(tempEmployee.name, ": ");
            PreIgnoreIt(tempEmployee.ID, ": ");
            PreIgnoreIt(tempEmployee.salary, ": ");
            PreIgnoreIt(tempEmployee.joiningDate, ": ");
            PreIgnoreIt(tempEmployee.designation, ": ");

            employees.addElement(tempEmployee);
            i++;
        }

        totalNumberOfEmployees = i;
        inputFile.close();
    }
    void MainMenu()
    {
        // For clearing console screen
        system("cls");
        char option;
        cout << "\n<===================== Main Menu =====================>" << endl
             << "\nPress '1' to continue to 'Employee Performance Metrics'" << endl
             << "Press '2' to continue to 'Salary Comparisons'" << endl
             << "Press '3' to continue to 'Employee Tenure Analysis'" << endl
             << "Press '4' to continue to 'Employee Ranking by Salary'" << endl
             << "Press '5' to continue to 'Employee Ranking by Tenure'" << endl
             << "Press '6' to 'Exit'" << endl;
        option = getch();

        while (!(option == '1' || option == '2' || option == '3' || option == '4' || option == '5' || option == '6'))
        {
            option = getch();
        }

        switch (option)
        {
        case '1':
            // For clearing console screen
            system("cls");
            EmployeePerformanceMetrics();
            break;

        case '2':
            // For clearing console screen
            system("cls");
            SalaryComparisons();
            break;

        case '3':
            // For clearing console screen
            system("cls");
            EmployeeTenureAnalysis();
            break;

        case '4':
            // For clearing console screen
            system("cls");
            EmployeeRankingBySalary();
            break;

        case '5':
            // For clearing console screen
            system("cls");
            EmployeeRankingByTenure();
            break;

        case '6':
            // For clearing console screen
            system("cls");
            exit(0);
            break;
        }
        MainMenu();
    }
    // Provides a link to the Main Menu
    void MainMenuLink()
    {
        char ch;
        cout << "\nPress 'Esc' to 'Go Back' or press 'Enter' to continue to 'Main Menu'" << endl;
        ch = getch();
        while (ch != '\x1B' && ch != '\r')
        {
            ch = getch();
        }
        if (ch == '\r')
        {
            // For clearing console screen
            system("cls");
            MainMenu();
        }
        // For clearing console screen
        system("cls");
    }

    // Scenario 1:
    void EmployeePerformanceMetrics()
    {
        char option;
        cout << "\n<==================== Employee Performance Metrics ====================>" << endl
             << "\nPress '1' to compute the 'Average Salary in the Company'" << endl
             << "Press '2' to compute the 'Total Number of Employees in the Company'" << endl
             << "Press '3' to compute the 'Average Tenure of Employees in the Company'" << endl
             << "Press '4' to report the 'Distribution of Employees Based on Designation'" << endl
             << "Press '5' to report the 'Employee with the Longest Tenure'" << endl
             << "Press '6' to 'go back'" << endl;
        option = getch();

        while (!(option == '1' || option == '2' || option == '3' || option == '4' || option == '5' || option == '6'))
        {
            option = getch();
        }

        switch (option)
        {
        case '1':
            // For clearing console screen
            system("cls");
            AverageSalary();
            break;

        case '2':
            // For clearing console screen
            system("cls");
            TotalNumberOfEmployees();
            break;

        case '3':
            // For clearing console screen
            system("cls");
            AverageTenure();
            break;

        case '4':
            // For clearing console screen
            system("cls");
            DistributionOfEmployees();
            break;

        case '5':
            // For clearing console screen
            system("cls");
            EmployeeWithLongestTenure();
            break;

        case '6':
            MainMenu();
            break;
        }
        EmployeePerformanceMetrics();
    }
    void AverageSalary()
    {
        double totalSalary = 0;
        for (int i = 0; i < totalNumberOfEmployees; i++)
        {
            string salary = PreIgnoreIt(employees[i].salary, "$", ",");
            totalSalary += StringToNumeric<string, double>(salary);
        }
        double averageSalary = totalSalary / totalNumberOfEmployees;
        string averageSalaryString = NumericToString<int>(averageSalary);
        cout << "Average Salary: $" << averageSalaryString << endl;
        MainMenuLink();
    }
    void TotalNumberOfEmployees()
    {
        cout << "Total Number of Employees: " << totalNumberOfEmployees << " employees" << endl;
        MainMenuLink();
    }
    void AverageTenure()
    {
        double totalTenure = 0;
        for (int i = 0; i < totalNumberOfEmployees; i++)
        {
            string tenure = PostIgnoreIt(employees[i].joiningDate, "-");
            totalTenure += 2023 - StringToNumeric<string, double>(tenure);
        }
        cout << "Average Tenure: " << totalTenure / totalNumberOfEmployees << " years" << endl;
        MainMenuLink();
    }
    void DistributionOfEmployees()
    {
        arr = BubbleSortEmployees(employees, totalNumberOfEmployees, "designation");
        for (int i = 0; i < totalNumberOfEmployees; i++)
        {
            if (i == 0)
            {
                cout << employees[i].designation << "s:-" << endl
                     << endl;
                string skip = "designation";
                employees[i].PrintEmployeeInfo(skip);
            }
            else if (employees[i].designation == employees[i - 1].designation)
            {
                string skip = "designation";
                employees[i].PrintEmployeeInfo(skip);
            }
            else
            {
                cout << employees[i].designation << "s:-" << endl
                     << endl;
                string skip = "designation";
                employees[i].PrintEmployeeInfo(skip);
            }
        }
        MainMenuLink();
    }
    void EmployeeWithLongestTenure()
    {
        Employee<string> longestTenure = employees[0];
        for (int i = 0; i < totalNumberOfEmployees; i++)
        {
            if (employees[i].joiningDate < longestTenure.joiningDate)
            {
                longestTenure = employees[i];
            }
        }
        cout << "Employee with Longest Tenure:- " << endl
             << endl;
        longestTenure.PrintEmployeeInfo();
        MainMenuLink();
    }

    // Scenario 2:
    void SalaryComparisons()
    {
        char option;
        cout << "\n<========================= Salary Comparisons =========================>" << endl
             << "\nPress '1' to compute the 'Highest Salary among all Employees'" << endl
             << "Press '2' to compute the 'Lowest Salary among all Employees'" << endl
             << "Press '3' to compute the 'Salary Range'" << endl
             << "Press '4' to compute the 'Median Salary'" << endl
             << "Press '5' to compute the 'Average Salary for each Designation Category'" << endl
             << "Press '6' to search the 'Employee with Highest Salary'" << endl
             << "Press '7' to 'go back'" << endl;
        option = getch();

        while (!(option == '1' || option == '2' || option == '3' || option == '4' || option == '5' || option == '6' || option == '7'))
        {
            option = getch();
        }

        switch (option)
        {
        case '1':
            // For clearing console screen
            system("cls");
            HighestSalary();
            break;

        case '2':
            // For clearing console screen
            system("cls");
            LowestSalary();
            break;

        case '3':
            // For clearing console screen
            system("cls");
            SalaryRange();
            break;

        case '4':
            // For clearing console screen
            system("cls");
            MedianSalary();
            break;

        case '5':
            // For clearing console screen
            system("cls");
            AverageSalaryPerDesignation();
            break;

        case '6':
            // For clearing console screen
            system("cls");
            EmployeeWithHighestSalary();
            break;

        case '7':
            MainMenu();
            break;
        }
        SalaryComparisons();
    }
    void HighestSalary()
    {
        Employee<string> highestSalary = employees[0];
        for (int i = 0; i < totalNumberOfEmployees; i++)
        {
            if (employees[i].salary > highestSalary.salary)
            {
                highestSalary = employees[i];
            }
        }
        cout << "Highest Salary: " << highestSalary.salary << endl;
        MainMenuLink();
    }
    void LowestSalary()
    {
        Employee<string> lowestSalary = employees[0];
        for (int i = 0; i < totalNumberOfEmployees; i++)
        {
            if (employees[i].salary < lowestSalary.salary)
            {
                lowestSalary = employees[i];
            }
        }
        cout << "Lowest Salary: " << lowestSalary.salary << endl;
        MainMenuLink();
    }
    void SalaryRange()
    {
        Employee<string> highestSalary = employees[0];
        Employee<string> lowestSalary = employees[0];
        for (int i = 0; i < totalNumberOfEmployees; i++)
        {
            if (employees[i].salary > highestSalary.salary)
            {
                highestSalary = employees[i];
            }
            if (employees[i].salary < lowestSalary.salary)
            {
                lowestSalary = employees[i];
            }
        }
        cout << "Salary Range: " << lowestSalary.salary << " - " << highestSalary.salary << endl;
        MainMenuLink();
    }
    void MedianSalary()
    {
        arr = BubbleSortEmployees(employees, totalNumberOfEmployees, "salary");
        double medianSalary = 0;
        int medianValue = (totalNumberOfEmployees / 2) - 1;
        cout << "Median Salary: " << employees[medianValue].salary << endl;
        MainMenuLink();
    }
    void AverageSalaryPerDesignation()
    {
        arr = BubbleSortEmployees(employees, totalNumberOfEmployees, "designation");
        double totalSalary = 0;
        int count = 0;
        for (int i = 0; i < totalNumberOfEmployees; i++)
        {
            if (i == 0)
            {
                cout << employees[i].designation << "s: $";
                string salary = PreIgnoreIt(employees[i].salary, "$", ",");
                totalSalary += StringToNumeric<string, double>(salary);
                count++;
            }
            else if (employees[i].designation == employees[i - 1].designation)
            {
                string salary = PreIgnoreIt(employees[i].salary, "$", ",");
                totalSalary += StringToNumeric<string, double>(salary);
                count++;
            }
            else
            {
                cout << NumericToString<int>(totalSalary / count) << endl
                     << endl;
                count = 0;
                totalSalary = 0;
                cout << employees[i].designation << "s: $";
                string salary = PreIgnoreIt(employees[i].salary, "$", ",");
                totalSalary += StringToNumeric<string, double>(salary);
                count++;
            }
        }
        cout << NumericToString<int>(totalSalary / count) << endl
             << endl;
        MainMenuLink();
    }
    void EmployeeWithHighestSalary()
    {
        Employee<string> highestSalary = employees[0];
        for (int i = 0; i < totalNumberOfEmployees; i++)
        {
            if (employees[i].salary > highestSalary.salary)
            {
                highestSalary = employees[i];
            }
        }
        cout << "Employee with Highest Salary:- " << endl
             << endl;
        highestSalary.PrintEmployeeInfo();
        MainMenuLink();
    }

    // Scenario 3:
    void EmployeeTenureAnalysis()
    {
        char option;
        cout << "\n<====================== Employee Tenure Analysis ======================>" << endl
             << "\nPress '1' to compute the 'Employee with the Longest Tenure'" << endl
             << "Press '2' to compute the 'Employee with the Shortest Tenure'" << endl
             << "Press '3' to compute the 'Average Tenure for each Designation Category'" << endl
             << "Press '4' to compute the 'Highest Paying Designation'" << endl
             << "Press '5' to 'go back'" << endl;
        option = getch();

        while (!(option == '1' || option == '2' || option == '3' || option == '4' || option == '5'))
        {
            option = getch();
        }

        switch (option)
        {
        case '1':
            // For clearing console screen
            system("cls");
            EmployeeWithLongestTenure();
            break;

        case '2':
            // For clearing console screen
            system("cls");
            EmployeeWithShortestTenure();
            break;

        case '3':
            // For clearing console screen
            system("cls");
            AverageTenurePerDesignation();
            break;

        case '4':
            // For clearing console screen
            system("cls");
            HighestPayingDesignation();
            break;

        case '5':
            MainMenu();
            break;
        }
        EmployeeTenureAnalysis();
    }
    void EmployeeWithShortestTenure()
    {
        Employee<string> shortestTenure = employees[0];
        for (int i = 0; i < totalNumberOfEmployees; i++)
        {
            if (employees[i].joiningDate > shortestTenure.joiningDate)
            {
                shortestTenure = employees[i];
            }
        }
        cout << "Employee with Shortest Tenure:- " << endl
             << endl;
        shortestTenure.PrintEmployeeInfo();
        MainMenuLink();
    }
    void AverageTenurePerDesignation()
    {
        arr = BubbleSortEmployees(employees, totalNumberOfEmployees, "designation");
        double averageTenure = 0;
        int count = 0;
        for (int i = 0; i < totalNumberOfEmployees; i++)
        {
            if (i == 0)
            {
                cout << employees[i].designation << "s: ";
                string tenure = PostIgnoreIt(employees[i].joiningDate, "-");
                averageTenure += 2023 - StringToNumeric<string, int>(tenure);
                count++;
            }
            else if (employees[i].designation == employees[i - 1].designation)
            {
                string tenure = PostIgnoreIt(employees[i].joiningDate, "-");
                averageTenure += 2023 - StringToNumeric<string, int>(tenure);
                count++;
            }
            else
            {
                cout << averageTenure / count << " years" << endl
                     << endl;
                count = 0;
                averageTenure = 0;
                cout << employees[i].designation << "s: ";
                string tenure = PostIgnoreIt(employees[i].joiningDate, "-");
                averageTenure += 2023 - StringToNumeric<string, int>(tenure);
                count++;
            }
        }
        cout << averageTenure / count << " years" << endl
             << endl;
        MainMenuLink();
    }
    void HighestPayingDesignation()
    {
        Employee<string> highestPayingDesignation = employees[0];
        for (int i = 0; i < totalNumberOfEmployees; i++)
        {
            if (employees[i].salary > highestPayingDesignation.salary)
            {
                highestPayingDesignation = employees[i];
            }
        }
        cout << "Highest Paying Designation: " << highestPayingDesignation.designation << endl;
        MainMenuLink();
    }

    // Scenario 4:
    void EmployeeRankingBySalary()
    {
        char option;
        cout << "\n<========== Employee Ranking By Salary ==========>" << endl
             << "\nPress '1' to use the 'Bubble Sorting Algorithm'" << endl
             << "Press '2' to use the 'Selection Sorting Algorithm'" << endl
             << "Press '3' to use the 'Insertion Sorting Algorithm'" << endl
             << "Press '4' to 'go back'" << endl;
        option = getch();

        while (!(option == '1' || option == '2' || option == '3' || option == '4'))
        {
            option = getch();
        }

        switch (option)
        {
        case '1':
            // For clearing console screen
            system("cls");
            startTime = clock();
            arr = BubbleSortEmployees(employees, totalNumberOfEmployees, "salary");
            endTime = clock();
            executionTime = static_cast<double>(endTime - startTime) / CLOCKS_PER_SEC;
            for (int i = 0; i < totalNumberOfEmployees; i++)
            {
                employees[i].PrintEmployeeInfo();
            }
            cout << endl
                 << "Number of Comparisons made: " << arr[0] << endl;
            cout << "Number of Swaps made: " << arr[1] << endl;
            cout << "Execution Time: " << executionTime << endl;
            MainMenuLink();
            break;

        case '2':
            // For clearing console screen
            system("cls");
            startTime = clock();
            arr = SelectionSortEmployees(employees, totalNumberOfEmployees, "salary");
            endTime = clock();
            executionTime = static_cast<double>(endTime - startTime) / CLOCKS_PER_SEC;
            for (int i = 0; i < totalNumberOfEmployees; i++)
            {
                employees[i].PrintEmployeeInfo();
            }
            cout << endl
                 << "Number of Comparisons made: " << arr[0] << endl;
            cout << "Number of Swaps made: " << arr[1] << endl;
            cout << "Execution Time: " << executionTime << endl;
            MainMenuLink();
            break;

        case '3':
            // For clearing console screen
            system("cls");
            startTime = clock();
            arr = InsertionSortEmployees(employees, totalNumberOfEmployees, "salary");
            endTime = clock();
            executionTime = static_cast<double>(endTime - startTime) / CLOCKS_PER_SEC;
            for (int i = 0; i < totalNumberOfEmployees; i++)
            {
                employees[i].PrintEmployeeInfo();
            }
            cout << endl
                 << "Number of Comparisons made: " << arr[0] << endl;
            cout << "Number of Swaps made: " << arr[1] << endl;
            cout << "Execution Time: " << executionTime << endl;
            MainMenuLink();
            break;

        case '4':
            MainMenu();
            break;
        }
        EmployeeRankingBySalary();
    }

    // Scenario 5:
    void EmployeeRankingByTenure()
    {
        char option;
        cout << "\n<========== Employee Ranking By Tenure ==========>" << endl
             << "\nPress '1' to use the 'Bubble Sorting Algorithm'" << endl
             << "Press '2' to use the 'Selection Sorting Algorithm'" << endl
             << "Press '3' to use the 'Insertion Sorting Algorithm'" << endl
             << "Press '4' to 'go back'" << endl;
        option = getch();

        while (!(option == '1' || option == '2' || option == '3' || option == '4'))
        {
            option = getch();
        }

        switch (option)
        {
        case '1':
            // For clearing console screen
            system("cls");
            startTime = clock();
            arr = BubbleSortEmployees(employees, totalNumberOfEmployees, "joiningDate");
            endTime = clock();
            executionTime = static_cast<double>(endTime - startTime) / CLOCKS_PER_SEC;
            for (int i = 0; i < totalNumberOfEmployees; i++)
            {
                employees[i].PrintEmployeeInfo();
            }
            cout << endl
                 << "Number of Comparisons made: " << arr[0] << endl;
            cout << "Number of Swaps made: " << arr[1] << endl;
            cout << "Execution Time: " << executionTime << endl;
            MainMenuLink();
            break;

        case '2':
            // For clearing console screen
            system("cls");
            startTime = clock();
            arr = SelectionSortEmployees(employees, totalNumberOfEmployees, "joiningDate");
            endTime = clock();
            executionTime = static_cast<double>(endTime - startTime) / CLOCKS_PER_SEC;
            for (int i = 0; i < totalNumberOfEmployees; i++)
            {
                employees[i].PrintEmployeeInfo();
            }
            cout << endl
                 << "Number of Comparisons made: " << arr[0] << endl;
            cout << "Number of Swaps made: " << arr[1] << endl;
            cout << "Execution Time: " << executionTime << endl;
            MainMenuLink();
            break;

        case '3':
            // For clearing console screen
            system("cls");
            startTime = clock();
            arr = InsertionSortEmployees(employees, totalNumberOfEmployees, "joiningDate");
            endTime = clock();
            executionTime = static_cast<double>(endTime - startTime) / CLOCKS_PER_SEC;
            for (int i = 0; i < totalNumberOfEmployees; i++)
            {
                employees[i].PrintEmployeeInfo();
            }
            cout << endl
                 << "Number of Comparisons made: " << arr[0] << endl;
            cout << "Number of Swaps made: " << arr[1] << endl;
            cout << "Execution Time: " << executionTime << endl;
            MainMenuLink();
            break;

        case '4':
            MainMenu();
            break;
        }
        EmployeeRankingByTenure();
    }
};

#endif // FictionalCompany