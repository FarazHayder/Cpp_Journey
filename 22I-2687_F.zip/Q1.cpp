// Faraz_Hayder_22I-2687_Assignment#2

#include <iostream>
using namespace std;

struct Pixel
{
    int red, green, blue;
    Pixel()
    {
        red = 0;
        green = 0;
        blue = 0;
    }
    Pixel(int red, int green, int blue)
    {
        this->red = red;
        this->green = green;
        this->blue = blue;
    }
    Pixel &operator=(int c)
    {
        red = c;
        green = c;
        blue = c;
        return *this;
    }
};

class Image
{

    int row, col, depth;
    Pixel ***image;

public:
    Image(int d = 1, int r = 1, int c = 1)
    {
        row = r;
        col = c;
        depth = d;
        // Allocating memory
        image = new Pixel **[row];
        for (int i = 0; i < row; i++)
        {
            image[i] = new Pixel *[col];
            for (int j = 0; j < col; j++)
            {
                image[i][j] = new Pixel[depth];
            }
        }
        // Copying data
        for (int i = 0; i < row; i++)
        {
            for (int j = 0; j < col; j++)
            {
                for (int k = 0; k < depth; k++)
                {
                    image[i][j][k] = 0;
                }
            }
        }
    }
    Image(const Image &img)
    {
        row = img.row;
        col = img.col;
        depth = img.depth;
        // Allocating memory
        image = new Pixel **[row];
        for (int i = 0; i < row; i++)
        {
            image[i] = new Pixel *[col];
            for (int j = 0; j < col; j++)
            {
                image[i][j] = new Pixel[depth];
            }
        }
        // Copying data
        for (int i = 0; i < row; i++)
        {
            for (int j = 0; j < col; j++)
            {
                for (int k = 0; k < depth; k++)
                {
                    image[i][j][k] = img.image[i][j][k];
                }
            }
        }
    }
    ~Image()
    {
        for (int i = 0; i < row; i++)
        {
            for (int j = 0; j < col; j++)
            {
                delete[] image[i][j];
            }
            delete[] image[i];
        }
        delete[] image;
        image = nullptr;
    }
    int getRow()
    {
        return row;
    }
    int getCol()
    {
        return col;
    }
    int getDepth()
    {
        return depth;
    }
    Pixel getPixel(int x, int y, int z)
    {
        return image[x][y][z];
    }
    void setPixel(int x, int y, int z, Pixel p)
    {
        image[x][y][z] = p;
    }
    void fill(Pixel p)
    {
        for (int i = 0; i < row; i++)
        {
            for (int j = 0; j < col; j++)
            {
                for (int k = 0; k < depth; k++)
                {
                    image[i][j][k] = p;
                }
            }
        }
    }
    void clear()
    {
        for (int i = 0; i < row; i++)
        {
            for (int j = 0; j < col; j++)
            {
                for (int k = 0; k < depth; k++)
                {
                    image[i][j][k] = 0;
                }
            }
        }
    }
    double getAverageBrightness()
    {
        double sum = 0;
        for (int i = 0; i < row; i++)
        {
            for (int j = 0; j < col; j++)
            {
                for (int k = 0; k < depth; k++)
                {
                    sum = sum + ((image[i][j][k].red + image[i][j][k].green + image[i][j][k].blue) / 3.0);
                }
            }
        }
        return sum / (row * col * depth);
    }
    int getMaximumBrightness(int depth)
    {
        int maxBrightness = 0;
        for (int i = 0; i < row; i++)
        {
            for (int j = 0; j < col; j++)
            {
                int brightness;
                if (depth == 0)
                {
                    brightness = image[i][j][depth].red;
                }
                else if (depth == 1)
                {
                    brightness = image[i][j][depth].green;
                }
                else if (depth == 2)
                {
                    brightness = image[i][j][depth].blue;
                }
                if (brightness > maxBrightness)
                {
                    maxBrightness = brightness;
                }
            }
        }
        return maxBrightness;
    }
    int countBrightPixel()
    {
        int count = 0;
        for (int i = 0; i < row; i++)
        {
            for (int j = 0; j < col; j++)
            {
                for (int k = 0; k < depth; k++)
                {
                    if (image[i][j][k].red == 255 || image[i][j][k].green == 255 || image[i][j][k].blue == 255)
                    {
                        count++;
                    }
                }
            }
        }
        return count;
    }
    void transposePixel(int depth)
    {
        Pixel ***transposed = new Pixel **[col];
        for (int i = 0; i < col; i++)
        {
            transposed[i] = new Pixel *[row];
            for (int j = 0; j < row; j++)
            {
                transposed[i][j] = new Pixel[this->depth];
                for (int k = 0; k < depth; k++)
                {
                    transposed[i][j][k] = image[j][i][k];
                }
            }
        }
        for (int i = 0; i < col; i++)
        {
            for (int j = 0; j < row; j++)
            {
                delete[] image[i][j];
            }
            delete[] image[i];
        }
        delete[] image;
        image = nullptr;
        image = transposed;
        swap(row, col);
    }
};