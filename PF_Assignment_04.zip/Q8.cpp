#include <iostream>
#include <cmath>
using namespace std;

int main (){
	
	int n=0;
	cout<<"Enter a range for all sides : ";
	cin>>n;
	cout<<"Side a :"<<"  "<<"Side b :"<<"  "<<"Hypotenuse :"<<endl;
	for (int a=1; a<=n; a++){
		for (int b=1; b<=n; b++){
			for (int c=1; c<=n; c++){
				if (pow(a,2)+pow(b,2)==pow(c,2)){
					cout<<"   "<<a<<"         "<<b<<"          "<<c<<endl;
				}
			}
		}
	}
	
	return 0;
}