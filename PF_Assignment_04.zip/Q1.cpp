#include <iostream>
#include <windows.h>
using namespace std;

int main (){
	
	int X=0,Y=0,Z=0;
	cout<<"Starting clock : ";
	while (true){
		cout<<X<<" Hours: "<<Y<<" Minutes: "<<Z<<" Seconds"<<endl;
		Z=Z+10; //addition of 10 seconds
		if (Z==60){
			Z=0;
			Y=Y+1; //converting 60 seconds to a minute
		}
		if (Y==60){
			Y=0;
			X=X+1; //converting 60 minutes to an hour
		}
		if (X==24){ //resetting time after 24 hours / starting again
			X=0;
			Y=0;
			Z=0;
		}
		sleep(10); //waiting for 10 seconds
		system("cls"); //refreshing screen
	}
	return 0;
}