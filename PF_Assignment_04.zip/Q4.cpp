#include <iostream>
#include <string>
#include <string.h>
using namespace std;

int science (string, int);
int history (string, int);
int sports (string, int);
int popCulture (string, int);
int WinSum (int, int, int, int);

int main (){
	
	int qno,i=0,WinningAmount;
	string sq="Q#",sno,sqno;
	int sumscience=0,sumhistory=0,sumsports=0,sumpopCulture=0;
	
	for (int qno=1; qno<=15; qno++){
		
		i=rand()%4+1;
		sno=to_string(qno);
		sqno=sq+sno;
		if (i==1){
			int sum;
			sum=science(sqno, qno);
			sumscience=sumscience+sum;
			cout<<sqno<<" : Science"<<endl;
		}
		if (i==2){
			int sum;
			sum=history(sqno, qno);
			sumhistory=sumhistory+sum;
		}
		if (i==3){
			int sum;
			sum=sports(sqno, qno);
			sumsports=sumsports+sum;
		}
		if (i==4){
			int sum;
			sum=popCulture(sqno, qno);
			sumpopCulture=sumpopCulture+sum;
		}
	}
	WinningAmount=WinSum (sumscience, sumhistory, sumsports, sumpopCulture);
	cout<<"\nPrize Money : "<<WinningAmount;
	
	return 0;
}

int science (string sqno, int qno){
	
	int check=rand()%10+1;
	if (check>5){
		cout<<sqno<<" : Science"<<endl;
		if (qno<=3){
			int ans=100;
			return ans;
		}
		if (qno>3 && qno<=6){
			int ans=1000;
			return ans;
		}
		if (qno>6 && qno<=10){
			int ans=10000;
			return ans;
		}
		if (qno>10 && qno<=15){
			int ans=15000;
			return ans;
		}
	}
	else {
		int ans=0;
		return ans;
	}
	return 0;
}

int history (string sqno, int qno){
	
	int check=rand()%10+1;
	if (check>5){
		cout<<sqno<<" : History"<<endl;
		if (qno<=3){
			int ans=100;
			return ans;
		}
		if (qno>3 && qno<=6){
			int ans=1000;
			return ans;
		}
		if (qno>6 && qno<=10){
			int ans=10000;
			return ans;
		}
		if (qno>10 && qno<=15){
			int ans=15000;
			return ans;
		}
	}
	else {
		int ans=0;
		return ans;
	}
	return 0;
}

int sports (string sqno, int qno){
	
	int check=rand()%10+1;
	if (check>5){
		cout<<sqno<<" : Sports"<<endl;
		if (qno<=3){
			int ans=100;
			return ans;
		}
		if (qno>3 && qno<=6){
			int ans=1000;
			return ans;
		}
		if (qno>6 && qno<=10){
			int ans=10000;
			return ans;
		}
		if (qno>10 && qno<=15){
			int ans=15000;
			return ans;
		}
	}
	else {
		int ans=0;
		return ans;
	}
	return 0;
}

int popCulture (string sqno, int qno){
	
	int check=rand()%10+1;
	if (check>5){
		cout<<sqno<<" : Pop Culture"<<endl;
		if (qno<=3){
			int ans=100;
			return ans;
		}
		if (qno>3 && qno<=6){
			int ans=1000;
			return ans;
		}
		if (qno>6 && qno<=10){
			int ans=10000;
			return ans;
		}
		if (qno>10 && qno<=15){
			int ans=15000;
			return ans;
		}
	}
	else {
		int ans=0;
		return ans;
	}
	return 0;
}

int WinSum (int sumscience, int sumhistory, int sumsports, int sumpopCulture){
	
	int WinningAmount=sumscience+sumhistory+sumsports+sumpopCulture;
	return WinningAmount;
}