#include <iostream>
#include <iomanip>
#include <cmath>
#include <windows.h>
#include <stdio.h>
#include <unistd.h>
using namespace std;

int main (){
	
	int n,h,w;
	cout<<"Enter the number of steps : ";
	cin>>n;
	cout<<"Enter the height of steps : ";
	cin>>h;
	cout<<"Enter the width of steps : ";
	cin>>w;
	
	char a='!';
	int count=0;
	
	while (true) {
		
		int rows=(n*(h+1));
		int columns=(w*n)+6;
		
		int t=1; //temporary variables/helping variables
		int t1=0;
		int t2=0;
		int t3=0;
		int ic=0; //itteration counter
		
		char b=a;
	
		for (int i=1; i<=rows; i++){
			if (i<=(t*h)+t){
				for (int j=1; j<columns-(t*w); j++){
					cout<<" ";
				}
				if (i==1+t1){
					for (int j=columns-(t*w); j<columns-(t2*w); j++){
						cout<<b;
					}
					for (int j=columns; j==columns; j++){
						cout<<setw(1+(t2*w))<<b;
					}
				}
				if (i>1+t1){
					for (int j=columns-(t*w); j==columns-(t*w); j++){
						cout<<b;
					}
				}
				if (i>1+t1){
					for (int j=columns; j==columns; j++){
						cout<<setw(5+(t2*w))<<b;
					}
				}
			}	
			cout<<endl;
			if ((i>=(t*h)+t)){
				t++;
				t1=t1+(h+1);
				t2++;
				t3++;
				ic++;
				if (ic==n-count){
					a='!';
					t3=0;
				}
				b=a+t3;
			}
		}
		for (int i=rows+1; i==rows+1; i++){
			for (int j=1; j<=columns; j++){
				cout<<b;
			}
		}
		count++;
		a=a+count;
		if (count==n){
			count=0;
			a='!';
		}
		sleep(2);cout<<endl<<endl;
		//system("cls");
	}
	
	return 0;
}