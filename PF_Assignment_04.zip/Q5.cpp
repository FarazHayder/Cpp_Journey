#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;

void validate (int check){
	if (check<0){
		cout<<"Please enter postive values only. Thank You!";
		exit(0);
	}
}

int main (){
	
	int x=0,n=0;
	cout<<"Plotting graph for the function f(x)=(x^n)-(x^(n-1)):"<<endl;
	cout<<"Enter |x| = ";
	cin>>x;
	validate (x);
	cout<<"Enter n = ";
	cin>>n;
	validate (n);
	int fxplus=pow(x,n)-pow(x,(n-1));
	int fxminus=pow(-x,n)-pow(-x,(n-1));
	int fx; //used if conditions because sometimes fx is greater for -ve value of x
	if (fxplus>=fxminus){
		fx=fxplus;
	}
	else if (fxminus>fxplus){
		fx=fxminus;
	}
	int rows=fx+2;
	int columns=(2*x)+2;
	int yaxis=fx;
	int xaxis=-x;
	int temp=0;
	
	cout<<"\nGraph : \n\n";
	for (int i=1; i<=rows; i++){
		int a=-x;
		for (int j=1; j<=columns; j++){
			if (i<rows && j==1){
				cout<<setw(2)<<setfill('0')<<yaxis;
			}
			if (i==rows && j==1){
				cout<<"   ";
			}
			if (i==rows && j<=columns-1){
				cout<<xaxis<<" ";
				xaxis++;
			}
			int fox=pow(a,n)-pow(a,(n-1));
			if (j>1){ //used this condition to skip the last row i.e. of x-axis
				if(a<0){ //for negative x-values (because in x-axis the distance was not equal due to -ve signs therefore added an additional space)
					if (yaxis==fox){
						cout<<"  .";
					}
					else if (i==rows){
						cout<<"";
					}
					else {
						cout<<"   ";
					}
				}
				if(a>=0){ //for non-negative x-values (because in x-axis these values did not have -ve sign so occupied less space therefore used one space lesser)
					if (yaxis==fox){
						cout<<" .";
					}
					else if (i==rows){
						cout<<"";
					}
					else {
						cout<<"  ";
					}
				}
				a++;
			}
		}
		yaxis--;
		cout<<endl;
	}
	
	return 0;
}