#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;

/* Name: Faraz Hayder | Roll Number: 2687 */

int main() {
	
	float P, r, t, A;
	const int n=12;
	cout<<"Enter the principal amount you want to be deposited: ";
	cin>>P;
	cout<<"Enter the annual interest rate in percentage: ";
	cin>>r;
	r=r/100; //converting to decimal form from percentage
	cout<<"Enter your investment tenure in years: ";
	cin>>t;
	A=P*pow(1+(r/n),n*t); //calculating compounded interest
	cout<<"Compounded interest= "<<A;
	
	return 0;
}
