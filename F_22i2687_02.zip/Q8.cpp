#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;

/* Name: Faraz Hayder | Roll Number: 2687 */

int main() {
	
	int A, B;
	cout<<"Enter the values of: "<<endl;
	cout<<"A= ";
	cin>>A;
	cout<<"B= ";
	cin>>B;
	cout<<endl;
	A=A+B;
	B=A-B;
	A=A-B;
	cout<<"A= "<<A<<endl;
	cout<<"B= "<<B<<endl;
	
	return 0;
}
