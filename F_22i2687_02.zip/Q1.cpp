#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;

/* Name: Faraz Hayder | Roll Number: 2687 */

int main() {
	
	float n1, n2, n3, n4, n5, n6, n7, n8, n9, n10, median, mean;
	cout<<"Enter 10 numbers in sorted order: "<<endl;
	cin>>n1>>n2>>n3>>n4>>n5>>n6>>n7>>n8>>n9>>n10;
	median = (n5+n6)/2;
	mean = (n1+n2+n3+n4+n5+n6+n7+n8+n9+n10)/10;
	cout<<"Median= "<<median<<endl<<"Mean= "<<mean;
	
	return 0;
}
