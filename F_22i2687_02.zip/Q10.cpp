#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;

/* Name: Faraz Hayder | Roll Number: 2687 */

int main() {
	
	float x, sinx, cosx;
	const float pi=3.1415926535897932384626433832795;
	cout<<"Enter the value of x in degrees: ";
	cin>>x;
	x=(x)*pi/180; //converting x from degrees to radians
	
	int i, n, f;
	
	f=1; //to calculate factorial of 3
	n=3;
	for (i=1; n>=i; i++){
		f=f*i;
	}
	sinx=x-(pow(x,n)/f); //updating value of sinx
	
	f=1; //to calculate factorial of 5
	n=5;
	for (i=1; n>=i; i++){
		f=f*i;
	}
	sinx=sinx+(pow(x,n)/f); //updating value of sinx
	
	f=1; //to calculate factorial of 7
	n=7;
	for (i=1; n>=i; i++){
		f=f*i;
	}
	sinx=sinx-(pow(x,n)/f); //updating value of sinx
	
	f=1; //to calculate factorial of 9
	n=9;
	for (i=1; n>=i; i++){
		f=f*i;
	}
	sinx=sinx+(pow(x,n)/f); //updating value of sinx
	
	f=1; //to calculate factorial of 2
	n=2;
	for (i=1; n>=i; i++){
		f=f*i;
	}
	cosx=1-(pow(x,n)/f); //updating value of cosx
	
	f=1; //to calculate factorial of 4
	n=4;
	for (i=1; n>=i; i++){
		f=f*i;
	}
	cosx=cosx+(pow(x,n)/f); //updating value of cosx
	
	f=1; //to calculate factorial of 6
	n=6;
	for (i=1; n>=i; i++){
		f=f*i;
	}
	cosx=cosx-(pow(x,n)/f); //updating value of cosx
	
	f=1; //to calculate factorial of 8
	n=8;
	for (i=1; n>=i; i++){
		f=f*i;
	}
	cosx=cosx+(pow(x,n)/f); //updating value of cosx
	
	cout<<"sin(x)= "<<sinx<<endl;
	cout<<"cos(x)= "<<cosx<<endl;
	
	return 0;
}
