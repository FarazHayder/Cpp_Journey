#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;

/* Name: Faraz Hayder | Roll Number: 2687 */

int main() {
    
	int n, hrs, mins, secs;
    n=0, hrs=0, mins=0, secs=0;
    cout<<"Enter the time in seconds: ";
    cin>>n;
    if (n>=0 and n<60) //for when time is to be displayed in seconds only
    {hrs=0; mins=0; secs=n;
	cout<<hrs<<" hrs "<<mins<<" mins "<<secs<<" secs";
	}
    else if (n>=60 and n<3600) //for when time is to be displayed in minutes and seconds
    {hrs=0; mins=n/60; secs=n-(60*mins);
	cout<<hrs<<" hrs "<<mins<<" mins "<<secs<<" secs";
	}
    else if (n>=3600) //for when time is to be displayed in hours, minutes and seconds
    {hrs=n/3600; mins=(n-(3600*hrs))/60; secs=(n-((hrs*3600)+(mins*60)));
	cout<<hrs<<" hrs "<<mins<<" mins "<<secs<<" secs";
	}
	else if (n<0)
	{cout<<"Please enter positive value.";
	}

    return 0;
}
