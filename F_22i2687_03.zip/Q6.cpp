/* Name: Faraz Hayder | Roll Number: 2687 */
#include <iostream>
#include <cmath>
#include <string>
using namespace std;

void strict ();
void lenient ();

int main(){

char type;
cout<<"Enter 's' for 'strict' and 'l' for 'lenient': "<<endl<<"Enter type : ";
cin>>type;
if (type == 's'){
	strict();
}
if (type == 'l'){
	lenient();
}
if (type != 's' || type != 'l'){
	cout<<"Choose a valid type. Please!";
}

return 0;
}

void strict (){
	
	int n1, n2, n3;
	cout<<"Enter first number = ";
	cin>>n1;
	cout<<"Enter second number = ";
	cin>>n2;
	cout<<"Enter third number = ";
	cin>>n3;
	string x;
	if (n1<n2 && n2<n3 && n1<n3 || n1>n2 && n2>n3 && n1>n3){
		x = n1<n2 && n2<n3 && n1<n3 ? "It is increasing." : "It is decreasing.";
		cout<<x;
	}
	else {
		cout<<"Neither.";
	}
}

void lenient (){
	
	int n1, n2, n3;
	cout<<"Enter first number = ";
	cin>>n1;
	cout<<"Enter second number = ";
	cin>>n2;
	cout<<"Enter third number = ";
	cin>>n3;
	string x;
	if (n1<n2 && n2<=n3 && n1<n3 || n1>n2 && n2>=n3 && n1>n3 || n1<=n2 && n2<n3 && n1<n3 || n1>=n2 && n2>n3 && n1>n3){
		x = n1<n2 && n2<=n3 && n1<n3 || n1<=n2 && n2<n3 && n1<n3 ? "It is increasing." : "It is decreasing.";
		cout<<x;
	}
	else if (n1==n2 && n2==n3 && n1==n3){
	cout<<"It is both increasing and decreasing.";
	}
	else {
		cout<<"Neither.";
	}
}
