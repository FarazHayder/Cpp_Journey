/* Name: Faraz Hayder | Roll Number: 2687 */
#include <iostream>
#include <string.h>
using namespace std;
int AgeInYears (int,int,int);

int main (){
	
	string name="",PostalCode="";
	char city,workCity;
	int dob=0,mob=0,yob=0,cityCode=0,income=0,age=0,discount=0;
	
	//Name
	cout<<"Enter your name : ";
	cin>>name;
	//Date of Birth - to find age
	cout<<"Enter your day of birth : ";
	cin>>dob;
	for (;dob<1 || dob>31;){ //Validation
		cout<<"Please! enter valid day."<<endl;
		cin>>dob;
	}
	cout<<"Enter your month of birth : ";
	cin>>mob;
	for (;mob<1 || mob>12;){ //Validation
		cout<<"Please! enter valid month."<<endl;
		cin>>mob;
	}
	cout<<"Enter your year of birth : ";
	cin>>yob;
	for (;yob<1 || yob>2022;){ //Validation
		cout<<"Please! enter valid year."<<endl;
		cin>>yob;
	}
	age=AgeInYears(dob,mob,yob);
	//City person lives in
	cout<<"Enter the city you live in : ";
	cin>>city;
	cout<<"Enter your Postal Code : ";
	cin>>PostalCode;
	cityCode=PostalCode.length();
	for (;!(city=='A' && cityCode==4) && !(city=='B' && cityCode==5);){
		cout<<"Please! Enter valid postal code."<<endl;
		cin>>PostalCode;
		cityCode=PostalCode.length();
	}
	if (cityCode==4){ //for City A
		while (cityCode!=4 || PostalCode[0]!='4' || PostalCode[2]!='3'){
			cout<<"Please! Enter valid postal code.CityA"<<endl;
			cin>>PostalCode;
			cityCode=PostalCode.length();
		}
	}
	if (cityCode==5){ //for City B
		while ((cityCode!=5 || PostalCode[0]!='5' || PostalCode[2]!='5') && (cityCode!=5 || PostalCode[0]!='5' || PostalCode[2]!='3')){
			cout<<"Please! Enter valid postal code.CityB"<<endl;
			cin>>PostalCode;
			cityCode=PostalCode.length();
		}
	}
	//City person works in
	cout<<"Enter the city you work in : ";
	cin>>workCity;
	//Income
	cout<<"Enter your income : ";
	cin>>income;
	
	//To calculate discounts
	if ((city=='A' || city=='B') && (workCity!='A' && workCity!='B')){
		discount=20;
	}
	if (age<22){
		discount=50;
	}
	if (income<10000){
		discount=90;
	}
	if (discount==0){
		cout<<"\nSorry "<<name<<"!\nYou are not eligible for a discount."<<endl;	
	}
	if (discount!=0){
		cout<<"\nCongratulations "<<name<<"!\nYou are eligible for discount of "<<discount<<"%."<<endl;	
	}
	
	return 0;
}

int AgeInYears (int dob,int mob,int yob){
	int year=2022,month=12,day=25;
	int age=year-yob;
	if (month<mob || (month==mob && day<dob)) {
	    age--;
	}
	return age;
}