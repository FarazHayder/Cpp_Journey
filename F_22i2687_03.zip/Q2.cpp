/* Name: Faraz Hayder | Roll Number: 2687 */
#include <iostream>
using namespace std;

int validate (int);
int getGearshiftStatus (void);
int getSwitchStatus (void);
int getHandleStatus (void);

int main (){
	
	//For switchstatus
	cout<<"\nChoose '0' for 'off' or '1' for 'activated'"<<endl;
	cout<<"Enter master unlock status : ";
	int mus=getSwitchStatus ();
	cout<<"Enter child lock status : ";
	int cls=getSwitchStatus ();
	cout<<"Enter dashboard switch status for left sliding door : ";
	int dssld=getSwitchStatus ();
	cout<<"Enter dashboard switch status for right sliding door : ";
	int dssrd=getSwitchStatus ();
	
	//For handlestatus
	cout<<"\nChoose '0' for 'close' or '1' for 'open'"<<endl;
	cout<<"Enter inside handle status of left sliding door : ";
	int ihsld=getHandleStatus ();
	cout<<"Enter inside handle status of right sliding door : ";
	int ihsrd=getHandleStatus ();
	cout<<"Enter outside handle status of left sliding door : ";
	int ohsld=getHandleStatus ();
	cout<<"Enter outside handle status of right sliding door : ";
	int ohsrd=getHandleStatus ();
	
	//For gearshiftstatus
	cout<<"Enter gear shift setting (P N D 1 2 3 R): ";
	int gss=getGearshiftStatus ();
	
	//Checking which door(s) open(s)
	bool rightdoor=false, leftdoor=false;
	if (gss=='P' && mus==1){
		if (cls==1){
			ihsld=0;
			ihsrd=0;
		}
		//for left door
		if (dssld==1 || ohsld==1 || ihsld==1){
			leftdoor=true;
		}
		else if (dssld==0 && ohsld==0 && ihsld==0){
			leftdoor=false;
		}
		//for right door
		if (dssrd==1 || ohsrd==1 || ihsrd==1){
			rightdoor=true;
		}
		else if (dssrd==0 && ohsrd==0 && ihsrd==0){
			rightdoor=false;
		}
	}
	else if (gss!='P' && mus==0){
		leftdoor=false;
		rightdoor=false;
	}
	if (leftdoor==true && rightdoor==true){
		cout<<"\nBoth doors open.";
	}
	else if (leftdoor==false && rightdoor==false){
		cout<<"\nBoth doors stay closed.";
	}
	else if (leftdoor==true && rightdoor==false){
		cout<<"\nLeft door opens";
	}
	else if (leftdoor==false && rightdoor==true){
		cout<<"\nRight door opens";
	}
	
	return 0;
}

int validate (int check){
	while (check!=0 && check!=1){
		cout<<"Please enter valid input."<<endl;
		cin>>check;
	}
	return check;
}

int getGearshiftStatus (void){
	char gss;
	cin>>gss;
	while (gss!='P' && gss!='N' && gss!='D' && gss!='1' && gss!='2' && gss!='3' && gss!='R'){
		cout<<"Enter valid gear shift setting."<<endl;
		cin>>gss;
	}
	return gss;
}

int getSwitchStatus (void){
	int switchStatus;
	cin>>switchStatus;
	switchStatus=validate(switchStatus);
	return switchStatus;
}

int getHandleStatus (void){
	int handleStatus;
	cin>>handleStatus;
	handleStatus=validate(handleStatus);
	return handleStatus;
}