#pragma once
#include <iostream>
#include <string>
#include <string.h>
#include <sstream>
#include <conio.h>
#include <fstream>
#include <windows.h>
#include <regex>
#include <cstdlib>
#include <ctime>
#include <cctype>
#include <iomanip>
using namespace std;

#include "Menu.h"
#include "NAFS.h"
#include "LoginAndRegistration.h"
#include "Admins.h"
#include "Passengers.h"
#include "UsefulClasses.h"

// Converts the string into lower-case (Helps in validation)
string toLower(string str)
{
    for (int i = 0; i < str.length(); i++)
    {
        str[i] = tolower(str[i]);
    }
    return str;
}

// Inputs password but shows starric instead of it on the console
string Password()
{
    char ch;
    string password;
    ch = getch();
    while (ch != '\r')
    {
        if (ch == '\b')
        {
            if (!password.empty())
            {
                password.pop_back();
                cout << "\b \b";
            }
        }
        else
        {
            password.push_back(ch);
            cout << "*";
        }
        ch = getch();
    }
    cout << "\n";

    return password;
}

// For clearing the console screen if the user wills
void RefreshScreen()
{
    // For a brief pause of 2 seconds
    Sleep(2000);
    // For clearing console screen
    char screenRefresher = ' ';
    cout << "\nDo you want to refresh screen? ('y' or 'n') ";
    cin >> screenRefresher;
    while (screenRefresher != 'y' && screenRefresher != 'n') // input validation
    {
        cout << "Invalid input." << endl;
        cin >> screenRefresher;
    }
    if (screenRefresher == 'y')
    {
        system("cls");
    }
}

// For Password Input And Validation
string PasswordInputAndValidation()
{
    bool passwordMatch = false;
    while (!passwordMatch)
    {
        bool check = false;
        string password = "";
        string passwordDoubleCheck = "";
        while (!check)
        {
            cout << "Password: ";
            password = Password();
            // Password checks
            bool lengthCheck = false;
            bool upperCaseCheck = false;
            bool lowerCaseCheck = false;
            bool digitCheck = false;
            bool specialCharCheck = false;
            int length = password.length();
            if (length >= 8)
            {
                lengthCheck = true;
            }
            for (int i = 0; i < length; i++)
            {
                if (isupper(password[i]))
                {
                    upperCaseCheck = true;
                }
                else if (islower(password[i]))
                {
                    lowerCaseCheck = true;
                }
                else if (isdigit(password[i]))
                {
                    digitCheck = true;
                }
                else if (ispunct(password[i]))
                {
                    specialCharCheck = true;
                }
            }
            if (lengthCheck == true && upperCaseCheck == true && lowerCaseCheck == true && digitCheck == true && specialCharCheck == true)
            {
                check = true;
            }
            if (!check)
            {
                cout << "\nPassword must be 8 characters long and use of minimum one special character, uppercase, lowercase, and numeric digit is must." << endl;
            }
        }
        check = false;
        while (!check)
        {
            cout << "Re-enter Password: ";
            passwordDoubleCheck = Password();
            // Password checks
            bool lengthCheck = false;
            bool upperCaseCheck = false;
            bool lowerCaseCheck = false;
            bool digitCheck = false;
            bool specialCharCheck = false;
            int length = password.length();
            if (length >= 8)
            {
                lengthCheck = true;
            }
            for (int i = 0; i < length; i++)
            {
                if (isupper(password[i]))
                {
                    upperCaseCheck = true;
                }
                else if (islower(password[i]))
                {
                    lowerCaseCheck = true;
                }
                else if (isdigit(password[i]))
                {
                    digitCheck = true;
                }
                else if (ispunct(password[i]))
                {
                    specialCharCheck = true;
                }
            }
            if (lengthCheck == true && upperCaseCheck == true && lowerCaseCheck == true && digitCheck == true && specialCharCheck == true)
            {
                check = true;
            }
            if (!check)
            {
                cout << "\nPassword must be 8 characters long and use of minimum one special character, uppercase, lowercase, and numeric digit is must." << endl;
            }
        }
        if (password == passwordDoubleCheck)
        {
            return password;
        }
        else
        {
            cout << "\nPasswords do not match!" << endl;
        }
    }
}

// For Username Input And Validation
string UsernameInputAndValidation(string filename)
{
    string username;
    cout << "\nUsername: ";
    cin >> username;
    // Username is checked that it should not already exist in the file and then the credentials of the new user are stored in the file
    int usernameNotExists = 1;
    while (usernameNotExists == 1 || usernameNotExists == 2)
    {
        if (usernameNotExists == 2)
        {
            usernameNotExists = 1;
            cout << "\nUsername: ";
            cin >> username;
        }
        ifstream fin(filename);
        string text;
        while (getline(fin, text))
        {
            stringstream ss(text); // converting the line to stringstream for easier parsing
            string usernameInFile;
            ss >> usernameInFile;
            if (username == usernameInFile)
            {
                usernameNotExists = 0;
                break;
            }
        }
        if (usernameNotExists == 1) // If the username does not exist in file
        {
            usernameNotExists = 3; // the condition becomes false to exit the loop
        }
        else if (usernameNotExists == 0) // If the username exists in file
        {
            cout << "\nUsername already exists!" << endl;
            usernameNotExists = 2; // the condition becomes true to continue iterating the loop
        }
        fin.close();
    }
    return username;
}

// For Cnic Input And Validation
string CnicInputAndValidation(string filename)
{
    string cnic;
    cout << "\nCnic: ";
    cin >> cnic;
    // Cnic is checked that it should not already exist in the file and then the credentials of the new user are stored in the file
    int cnicNotExists = 1;
    while (cnicNotExists == 1 || cnicNotExists == 2)
    {
        if (cnicNotExists == 2)
        {
            cnicNotExists = 1;
            int length = 0;
            while (length != 13)
            {
                cout << "\nCnic: ";
                cin >> cnic;
                length = cnic.length();
                if (length != 13)
                {
                    cout << "Invalid Cnic! Cnic must be of 13 digits." << endl;
                }
            }
        }
        ifstream fin(filename);
        string text;
        while (getline(fin, text))
        {
            stringstream ss(text); // converting the line to stringstream for easier parsing
            string cnicInFile;
            ss >> cnicInFile >> cnicInFile >> cnicInFile;
            if (cnic == cnicInFile)
            {
                cnicNotExists = 0;
                break;
            }
        }
        if (cnicNotExists == 1) // If the cnic does not exist in file
        {
            cnicNotExists = 3; // the condition becomes false to exit the loop
        }
        else if (cnicNotExists == 0) // If the cnic exists in file
        {
            cout << "\nCnic already exists!" << endl;
            cnicNotExists = 2; // the condition becomes true to continue iterating the loop
        }
        fin.close();
    }
    return cnic;
}

// Verifying Financial Details
// Basically checks that if a passenger already has that account then the balance entered should be same
bool verifyFinancialDetails(string accountNumber, string balance)
{
    ifstream fin("Passenger.txt");
    string text;
    while (getline(fin, text))
    {
        stringstream ss(text); // converting the line to stringstream for easier parsing
        string accountNumberInFile;
        ss >> accountNumberInFile >> accountNumberInFile >> accountNumberInFile >> accountNumberInFile;
        if (accountNumberInFile == accountNumber)
        {
            stringstream ss(text); // converting the line to stringstream for easier parsing
            string balanceInFile;
            ss >> balanceInFile >> balanceInFile >> balanceInFile >> balanceInFile >> balanceInFile;
            if (balanceInFile == balance)
            {
                return true;
            }
            else
            {
                cout << "The amount of balance, you entered, for this account does not match the amount in the account." << endl;
                return false;
            }
        }
    }
    return true;
}

// Email Validation
bool isValidEmail(string email)
{
    // Regular expression for email validation
    regex pattern("(\\w+)(\\.|_)?(\\w*)@(\\w+)(\\.(\\w+))+");

    return regex_match(email, pattern);
}

// Contact Number Validation
bool isValidContactNumber(string contactNumber)
{
    // Regular expression for contact number validation
    regex pattern("\\d{10}");

    return regex_match(contactNumber, pattern);
}

// File handling to append the credentials of the new user to the file
void UpdateFileWithCredentials(string username, string password, string filename)
{
    ofstream fout(filename, ios::app);
    if (fout.is_open())
    {
        fout << username << " " << password << endl;
        fout.close();
    }
    else
    {
        cout << "Error: Unable to open file." << endl;
    }
}
void UpdateFileWithCredentials(string username, string password, string cnic, string accountNumber, string balance, string passport, string visa, string filename)
{
    ofstream fout(filename, ios::app);
    if (fout.is_open())
    {
        fout << username << " " << password << " " << cnic << " " << accountNumber << " " << balance << " " << passport << " " << visa << endl;
        fout.close();
    }
    else
    {
        cout << "Error: Unable to open file." << endl;
    }
}
