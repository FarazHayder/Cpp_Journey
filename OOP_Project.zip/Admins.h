#pragma once

class Admin
{
protected:
    string username;
    string password;

public:
    // Constructors
    Admin()
    {
        username = "";
        password = "";
    }
    Admin(string username, string password)
    {
        this->username = username;
        this->password = password;
    }
    Admin(Admin &admin)
    {
        this->username = admin.username;
        this->password = admin.password;
    }
    // Methods:-
    void setAdmin(string username, string password)
    {
        this->username = username;
        this->password = password;
    }
};