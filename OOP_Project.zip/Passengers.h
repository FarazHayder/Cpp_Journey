#pragma once

class Passenger
{
protected:
    string username;
    string password;
    string cnic;
    // cnic/name/contact info wgera bhi add kr lun ga

public:
    // Constructors
    Passenger()
    {
        username = "";
        password = "";
        cnic = "";
    }
    Passenger(string username, string password, string cnic)
    {
        this->username = username;
        this->password = password;
        this->cnic = cnic;
    }
    Passenger(Passenger &passenger)
    {
        this->username = passenger.username;
        this->password = passenger.password;
        this->cnic = passenger.cnic;
    }
    // Methods:-
    void setPassenger(string username, string password, string cnic)
    {
        this->username = username;
        this->password = password;
        this->cnic = cnic;
    }
};