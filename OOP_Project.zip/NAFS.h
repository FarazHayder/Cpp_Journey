#pragma once
#include "headerAndUsefulFunctions.h"
#include "Menu.h"
#include "Admins.h"
#include "Passengers.h"
#include "UsefulClasses.h"

// Forward Declarations:
void RefreshScreen();
string Password();
void MainMenuLink();
string PasswordInputAndValidation();
string UsernameInputAndValidation(string filename);
string CnicInputAndValidation(string filename);
bool verifyFinancialDetails(string accountNumber, string balance);
bool isValidEmail(string email);
bool isValidContactNumber(string contactNumber);
void UpdateFileWithCredentials(string username, string password, string filename);
void UpdateFileWithCredentials(string username, string password, string cnic, string accountNumber, string balance, string passport, string visa, string filename);
string toLower(string str);

class NAFS
{
protected:
    // int noOfAdmins;
    // int noOfPassengers;
    // Admin *adminsArr;
    // Passenger *passengersArr;
    City *cities;
    InquiryDetails inquiryDetails;
    string *cityNames;
    string *terminals;
    string *countries;
    string *travelTimesForCountries;

public:
    // Constructors
    NAFS(int noOfAdmins = 5, int noOfPassengers = 5)
    {
        // this->noOfAdmins = noOfAdmins;
        // adminsArr = new Admin[noOfAdmins];
        // Admins of NAFS system
        // adminsArr[0].setAdmin("Faraz", "Faraz12$");
        // adminsArr[1].setAdmin("Sheryar", "Sheryar12$");
        // adminsArr[2].setAdmin("Haroon", "Haroon12$");
        // adminsArr[3].setAdmin("Faheem", "Faheem12$");
        // adminsArr[4].setAdmin("Faiz", "Faiz12$");
        // this->noOfPassengers = noOfPassengers;
        // passengersArr = new Passenger[noOfPassengers];
        // Passengers of NAFS system
        // passengersArr[0].setPassenger("Rasheed", "Rasheed12$","1237895647531");
        // passengersArr[1].setPassenger("Shafique", "Shafique12$","1237895647535");
        // passengersArr[2].setPassenger("Zaryab", "Zaryab12$","1237895647532");
        // passengersArr[3].setPassenger("Arbab", "Arbab12$","1237895647533");
        // passengersArr[4].setPassenger("Tayyab", "Tayyab12$","1237895647534");
        this->inquiryDetails.setInquiryDetails("NAFS@nu.edu.pk", "0515298734", "NAFS, 3 A.K. Brohi Road, H-11/4 H 11/4 H-11, Islamabad, Islamabad Capital Territory");
        this->cities = new City[5];
        cityNames = new string[5]{"Islamabad", "Lahore", "Quetta", "Karachi", "Peshawar"};
        terminals = new string[2]{"North", "South"};
        countries = new string[25]{"United States", "Canada", "United Kingdom", "Germany", "France", "Italy", "Spain", "China", "Switzerland", "Norway", "Sweden", "Denmark", "Australia", "New Zealand", "Japan", "South Korea", "Singapore", "United Arab Emirates", "Bahrain", "Qatar", "Kuwait", "Saudi Arabia", "Oman", "Taiwan", "Hong Kong"};
        travelTimesForCountries = new string[25]{"20 00", "16 00", "09 00", "07 00", "08 00", "10 00", "11 00", "05 00", "09 00", "11 00", "10 00", "10 00", "12 00", "13 00", "06 00", "07 00", "06 00", "03 00", "03 00", "03 00", "03 00", "03 00", "03 00", "05 00", "05 00"};
        makeFlightSchedule();
    }
    NAFS(NAFS &admin)
    {
        // this->noOfAdmins = admin.noOfAdmins;
        // this->noOfPassengers = admin.noOfPassengers;
        // this->adminsArr = admin.adminsArr;
        // this->passengersArr = admin.passengersArr;
        this->inquiryDetails = admin.inquiryDetails;
    }
    // Methods:-
    void MainMenu()
    {
        char option; // We used char instead of int because if we use int and the user enters a char, the system does not respond with sanity
        bool check = true;
        int n = 0;
        do
        {
            if (n > 0)
            {
                cout << "\nInvalid input." << endl;
            }
            cout << "\n<============== Main Menu ==============>" << endl
                 << "\nPress '1' to continue to 'Admin Panel'" << endl
                 << "Press '2' to continue to 'Passenger Panel'" << endl
                 << "Press '3' to continue to 'Flight Schedule Board'" << endl
                 << "Press '4' to 'Exit'" << endl;
            cin >> option;
            n++;
            if (option == 49 || option == 50 || option == 51 || option == 52) // Since ASCII of 1,2,3 is 49, 50, 51
            {
                check = false;
                n = 0;
            }
        } while (check);

        switch (option)
        {
        case 49:
            // For clearing console screen
            system("cls");
            validateLoginForAdminPanel();
            break;

        case 50:
            // For clearing console screen
            system("cls");
            PassengerPanel();
            break;

        case 51:
            // For clearing console screen
            system("cls");
            displayFlightSchedule();
            break;

        case 52:
            exit(0);
            break;
        }
        MainMenu();
    }
    // Provides a link to the Main Menu
    void MainMenuLink()
    {
        char ch;
        cout << "\nPress 'Esc' to 'Cancel' or press 'Enter' to continue to 'Main Menu'" << endl;
        ch = getch();
        while (ch != '\x1B' && ch != '\r')
        {
            ch = getch();
        }
        if (ch == '\r')
        {
            // For clearing console screen
            system("cls");
            MainMenu();
        }
        // For clearing console screen
        system("cls");
    }
    void validateLoginForAdminPanel()
    {
        // Login to admin panel first for further access
        bool check = false;
        while (!check)
        {
            // For clearing console screen
            system("cls");
            check = LoginToAdminPanel();
        }
        if (check)
        {
            // For clearing console screen
            system("cls");
            AdminPanel();
        }
    }
    void restrictNumberOfPassengers()
    {
        string answer = "";
        cout << "\nSince, corona cases are rising! Do you want to restrict seats in aircrafts: (Yes or No)";
        cin >> answer;
        answer = toLower(answer);
        while (answer != "yes" && answer != "no")
        {
            cout << "\nInvalid input." << endl;
            cout << "\nSince, corona cases are rising! Do you want to restrict seats in aircrafts: (Yes or No)";
            cin >> answer;
            answer = toLower(answer);
        }
        if (answer == "yes")
        {
            for (int i = 0; i < 5; i++) // Since there are total 5 cities
            {
                for (int j = 0; j < 2; j++) // Since there are two airports in every city
                {
                    for (int k = 0; k < 5; k++) // Since there are at most 5 airplanes at an airport
                    {
                        cities[i].getAirports()[j].getAirplanes()[k].getSeating()[0].restrictSeats();
                    }
                }
            }
            cout << "Number of Passengers in the aircraft successfully restricted!" << endl;
        }
        else
        {
            cout << "Number of Passengers in the aircraft not restricted!" << endl;
        }
        // For a brief pause of 2 seconds
        Sleep(2000);
        // For clearing console screen
        system("cls");
    }
    void AdminPanel()
    {
        // Functionality of Admin
        char option; // We used char instead of int because if we use int and the user enters a char, the system does not respond with sanity
        bool check = true;
        int n = 0;
        do
        {
            if (n > 0)
            {
                cout << "\nInvalid input." << endl;
            }
            cout << "\n<============== Admin Panel ==============>" << endl
                 << "\nPress '1' to 'Add Admin'" << endl
                 << "Press '2' to 'Add New Routes'" << endl
                 << "Press '3' to 'Restrict Number of Passengers'" << endl
                 << "Press '4' to 'Update Airline Inquiry Details'" << endl
                 << "Press '5' to go to 'Main Menu'" << endl;
            cin >> option;
            n++;
            if (option == 49 || option == 50 || option == 51 || option == 52 || option == 53) // Since ASCII of 1,2,3 is 49, 50, 51
            {
                check = false;
                n = 0;
            }
        } while (check);

        switch (option)
        {
        case 49:
            // For clearing console screen
            system("cls");
            addAdmin();
            break;

        case 50:
            // For clearing console screen
            system("cls");
            addNewRoute();
            break;

        case 51:
            // For clearing console screen
            system("cls");
            restrictNumberOfPassengers();
            break;

        case 52:
            // For clearing console screen
            system("cls");
            updateAirineInquiryDetails();
            break;

        case 53:
            // For clearing console screen
            system("cls");
            MainMenuLink();
            break;
        }
        AdminPanel();
    }
    void bookingForLocalFlight(string username)
    {
        cout << "\n<=============== Booking Local Flight ===============>" << endl;
        string cityOfDeparture;
        bool check = true;
        int n = 0;
        int temp = 0;
        do
        {
            if (n > 0)
            {
                cout << "\nInvalid input." << endl;
            }
            cout << "\nChoose City of Departure: (\"Islamabad\", \"Lahore\", \"Quetta\", \"Karachi\", \"Peshawar\")" << endl;
            cin >> cityOfDeparture;
            n++;
            if (toLower(cityOfDeparture) == "islamabad" || toLower(cityOfDeparture) == "lahore" || toLower(cityOfDeparture) == "quetta" || toLower(cityOfDeparture) == "karachi" || toLower(cityOfDeparture) == "peshawar")
            {
                if (toLower(cityOfDeparture) == "islamabad")
                {
                    temp = 0;
                }
                else if (toLower(cityOfDeparture) == "lahore")
                {
                    temp = 1;
                }
                else if (toLower(cityOfDeparture) == "quetta")
                {
                    temp = 2;
                }
                else if (toLower(cityOfDeparture) == "karachi")
                {
                    temp = 3;
                }
                else if (toLower(cityOfDeparture) == "peshawar")
                {
                    temp = 4;
                }
                check = false;
                n = 0;
            }
        } while (check);
        string cityOfArrival;
        check = true;
        do
        {
            if (n > 0)
            {
                cout << "\nInvalid input." << endl;
            }
            cout << "\nChoose City of Arrival: (\"Islamabad\", \"Lahore\", \"Quetta\", \"Karachi\", \"Peshawar\")" << endl;
            cin >> cityOfArrival;
            n++;
            if (toLower(cityOfArrival) == toLower(cityOfDeparture))
            {
                cout << "\nCity of arrival and city of departure cannot be same!";
            }
            else if (toLower(cityOfArrival) == "islamabad" || toLower(cityOfArrival) == "lahore" || toLower(cityOfArrival) == "quetta" || toLower(cityOfArrival) == "karachi" || toLower(cityOfArrival) == "peshawar") // Since ASCII of 1,2,3 is 49, 50, 51
            {
                check = false;
                n = 0;
            }
        } while (check);
        string terminal = "";
        cout << "Select Terminal: (North or South)";
        cin >> terminal;
        terminal = toLower(terminal);
        while (terminal != "north" && terminal != "south")
        {
            cout << "Invalid input." << endl;
            cout << "Select Terminal: (North or South)";
            cin >> terminal;
            terminal = toLower(terminal);
        }
        int temp2 = 0;
        if (terminal == "north")
        {
            temp2 = 0;
        }
        else if (terminal == "south")
        {
            temp2 = 1;
        }
        cout << "How many seats you want?" << endl;
        int seats;
        cin >> seats;
        cout << "Type: (Business or Economy)";
        string seatType;
        cin >> seatType;
        seatType = toLower(seatType);
        while (seatType != "business" && seatType != "economy")
        {
            cout << "Invalid input." << endl;
            cout << "Type: (Business or Economy)";
            cin >> seatType;
            seatType = toLower(seatType);
        }
        cout << "Rs. 20,000 deducted from your account for a two hour flight." << endl;
        // Setting the new route
        cities[temp].getAirports()[temp2].getAirplanes()[0].addFlight();
        int noOfFlights = cities[temp].getAirports()[temp2].getAirplanes()[0].getNoOfFlights() - 1;
        cities[temp].getAirports()[temp2].getAirplanes()[0].getFlights()[noOfFlights].setFlightType("Local");
        cities[temp].getAirports()[temp2].getAirplanes()[0].getFlights()[noOfFlights].setPlaceOfDeparture(cityNames[temp]);
        cities[temp].getAirports()[temp2].getAirplanes()[0].getFlights()[noOfFlights].setPlaceOfArrival(cityOfArrival);
        if (seatType == "business")
        {
            cities[temp].getAirports()[temp2].getAirplanes()[0].getSeating()[0].setBusinessSeats(seats);
        }
        if (seatType == "economy")
        {
            cities[temp].getAirports()[temp2].getAirplanes()[0].getSeating()[0].setEconomySeats(seats);
        }

        cout << "Flight booked Successfully!" << endl;
        // For a brief pause of 2 seconds
        Sleep(2000);
        // For clearing console screen
        system("cls");
    }
    void bookingForInternationalFlight(string username)
    {
        cout << "\n<=============== Booking International Flight ===============>" << endl;
        ifstream fin("Passenger.txt");
        string text;
        while (getline(fin, text))
        {
            stringstream ss(text); // converting the line to stringstream for easier parsing
            string usernameInFile, passwordInFile, cnicInFile, accountNumberInFile, balanceInFile, passportInFile, visaInFile;
            ss >> usernameInFile >> passwordInFile >> cnicInFile >> accountNumberInFile >> balanceInFile >> passportInFile >> visaInFile;
            if (username == usernameInFile)
            {
                if (visaInFile == "no")
                {
                    cout << "\nSorry! You cannot book an international flight since you do not have a Visa!" << endl;
                    return;
                }
            }
        }
        string cityOfDeparture;
        bool check = true;
        int n = 0;
        int temp = 0;
        do
        {
            if (n > 0)
            {
                cout << "\nInvalid input." << endl;
            }
            cout << "\nChoose City of Departure: (\"Islamabad\", \"Lahore\", \"Quetta\", \"Karachi\", \"Peshawar\")" << endl;
            cin >> cityOfDeparture;
            n++;
            if (toLower(cityOfDeparture) == "islamabad" || toLower(cityOfDeparture) == "lahore" || toLower(cityOfDeparture) == "quetta" || toLower(cityOfDeparture) == "karachi" || toLower(cityOfDeparture) == "peshawar")
            {
                if (toLower(cityOfDeparture) == "islamabad")
                {
                    temp = 0;
                }
                else if (toLower(cityOfDeparture) == "lahore")
                {
                    temp = 1;
                }
                else if (toLower(cityOfDeparture) == "quetta")
                {
                    temp = 2;
                }
                else if (toLower(cityOfDeparture) == "karachi")
                {
                    temp = 3;
                }
                else if (toLower(cityOfDeparture) == "peshawar")
                {
                    temp = 4;
                }
                check = false;
                n = 0;
            }
        } while (check);
        string countryOfArrival = "";
        check = true;
        n = 0;
        do
        {
            if (n > 0)
            {
                cout << "\nInvalid input." << endl;
            }
            cout << "\nChoose Country of Arrival: (\"United States\", \"Canada\", \"United Kingdom\", \"Germany\", \"France\", \"Italy\", \"Spain\", \"China\", \"Switzerland\", \"Norway\", \"Sweden\", \"Denmark\", \"Australia\", \"New Zealand\", \"Japan\", \"South Korea\", \"Singapore\", \"United Arab Emirates\", \"Bahrain\", \"Qatar\", \"Kuwait\", \"Saudi Arabia\", \"Oman\", \"Taiwan\", \"Hong Kong\")" << endl;
            getline(cin, countryOfArrival);
            n++;
            if (toLower(countryOfArrival) == toLower("United States") || toLower(countryOfArrival) == toLower("Canada") || toLower(countryOfArrival) == toLower("United Kingdom") || toLower(countryOfArrival) == toLower("Germany") || toLower(countryOfArrival) == toLower("France") || toLower(countryOfArrival) == toLower("Italy") || toLower(countryOfArrival) == toLower("Spain") || toLower(countryOfArrival) == toLower("China") || toLower(countryOfArrival) == toLower("Switzerland") || toLower(countryOfArrival) == toLower("Norway") || toLower(countryOfArrival) == toLower("Sweden") || toLower(countryOfArrival) == toLower("Denmark") || toLower(countryOfArrival) == toLower("Australia") || toLower(countryOfArrival) == toLower("New Zealand") || toLower(countryOfArrival) == toLower("Japan") || toLower(countryOfArrival) == toLower("South Korea") || toLower(countryOfArrival) == toLower("Singapore") || toLower(countryOfArrival) == toLower("United Arab Emirates") || toLower(countryOfArrival) == toLower("Bahrain") || toLower(countryOfArrival) == toLower("Qatar") || toLower(countryOfArrival) == toLower("Kuwait") || toLower(countryOfArrival) == toLower("Saudi Arabia") || toLower(countryOfArrival) == toLower("Oman") || toLower(countryOfArrival) == toLower("Taiwan") || toLower(countryOfArrival) == toLower("Hong Kong"))
            {
                check = false;
                n = 0;
            }
        } while (check);
        string terminal = "";
        cout << "Select Terminal: (North or South)";
        cin >> terminal;
        terminal = toLower(terminal);
        while (terminal != "north" && terminal != "south")
        {
            cout << "Invalid input." << endl;
            cout << "Select Terminal: (North or South)";
            cin >> terminal;
            terminal = toLower(terminal);
        }
        int temp2 = 0;
        if (terminal == "north")
        {
            temp2 = 0;
        }
        else if (terminal == "south")
        {
            temp2 = 1;
        }
        cout << "How many seats you want?" << endl;
        int seats;
        cin >> seats;
        cout << "Type: (Business or Economy)";
        string seatType;
        cin >> seatType;
        seatType = toLower(seatType);
        while (seatType != "business" && seatType != "economy")
        {
            cout << "Invalid input." << endl;
            cout << "Type: (Business or Economy)";
            cin >> seatType;
            seatType = toLower(seatType);
        }
        cout << "Rs. 20,000 deducted from your account." << endl;
        // Booking
        cities[temp].getAirports()[temp2].getAirplanes()[0].addFlight();
        int noOfFlights = cities[temp].getAirports()[temp2].getAirplanes()[0].getNoOfFlights() - 1;
        cities[temp].getAirports()[temp2].getAirplanes()[0].getFlights()[noOfFlights].setFlightType("International");
        cities[temp].getAirports()[temp2].getAirplanes()[0].getFlights()[noOfFlights].setPlaceOfDeparture(cityNames[temp]);
        cities[temp].getAirports()[temp2].getAirplanes()[0].getFlights()[noOfFlights].setPlaceOfArrival(countryOfArrival);
        if (seatType == "business")
        {
            cities[temp].getAirports()[temp2].getAirplanes()[0].getSeating()[0].setBusinessSeats(seats);
        }
        if (seatType == "economy")
        {
            cities[temp].getAirports()[temp2].getAirplanes()[0].getSeating()[0].setEconomySeats(seats);
        }

        cout << "Flight Booked Successfully!" << endl;
        // For a brief pause of 2 seconds
        Sleep(2000);
        // For clearing console screen
        system("cls");
    }
    // Making a reservation
    void booking(string username)
    {
        char option; // We used char instead of int because if we use int and the user enters a char, the system does not respond with sanity
        bool check = true;
        int n = 0;
        do
        {
            if (n > 0)
            {
                cout << "\nInvalid input." << endl;
            }
            cout << "\n<======================= Booking =======================>" << endl
                 << "\nPress '1' to make a reservation for 'Local Flight'" << endl
                 << "Press '2' to make a reservation for 'International Flight'" << endl
                 << "Press '3' to go to 'Main Menu'" << endl
                 << "Press '4' to go back" << endl;
            cin >> option;
            n++;
            if (option == 49 || option == 50 || option == 51 || option == 52) // Since ASCII of 1,2,3 is 49, 50, 51
            {
                check = false;
                n = 0;
            }
        } while (check);

        switch (option)
        {
        case 49:
            // For clearing console screen
            system("cls");
            bookingForLocalFlight(username);
            break;

        case 50:
            // For clearing console screen
            system("cls");
            bookingForInternationalFlight(username);
            break;

        case 51:
            // For clearing console screen
            system("cls");
            MainMenuLink();
            break;

        case 52:
            // For clearing console screen
            system("cls");
            return;
        }
    }
    void mostVisitedCountry()
    {
        cout << "<======= Most Visited Country =======>" << endl;
        cout << "\nUnited States" << endl;
        cout << "Estimated Travelling Cost: Rs. 400,000" << endl; // Since for 1 hour of International Flight it is 20,000 and US is 20 hrs away
    }
    void home(string username)
    {
        // Functionality for Passenger
        char option; // We used char instead of int because if we use int and the user enters a char, the system does not respond with sanity
        bool check = true;
        int n = 0;
        do
        {
            if (n > 0)
            {
                cout << "\nInvalid input." << endl;
            }
            cout << "\n<============ Home ============>" << endl
                 << "\nPress '1' for viewing 'Flight Schedule'" << endl
                 << "Press '2' for 'Booking'" << endl
                 << "Press '3' for 'Most Visited Country'" << endl
                 << "Press '4' to go to 'Main Menu'" << endl
                 << "Press '5' to go back" << endl;
            cin >> option;
            n++;
            if (option == 49 || option == 50 || option == 51 || option == 52 || option == 53) // Since ASCII of 1,2,3 is 49, 50, 51
            {
                check = false;
                n = 0;
            }
        } while (check);

        bool login = false;
        bool registered = false;
        switch (option)
        {
        case 49:
            // For clearing console screen
            system("cls");
            displayFlightSchedule();
            break;

        case 50:
            // For clearing console screen
            system("cls");
            booking(username);
            break;

        case 51:
            // For clearing console screen
            system("cls");
            mostVisitedCountry();
            break;

        case 52:
            // For clearing console screen
            system("cls");
            MainMenuLink();
            break;

        case 53:
            // For clearing console screen
            system("cls");
            return;
        }
        home(username);
    }
    void PassengerPanel()
    {
        // Functionality for Passenger
        char option; // We used char instead of int because if we use int and the user enters a char, the system does not respond with sanity
        bool check = true;
        int n = 0;
        do
        {
            if (n > 0)
            {
                cout << "\nInvalid input." << endl;
            }
            cout << "\n<====== Passenger Panel ======>" << endl
                 << "\nPress '1' to 'Login'" << endl
                 << "Press '2' to 'Register'" << endl
                 << "Press '3' to go to 'Main Menu'" << endl;
            cin >> option;
            n++;
            if (option == 49 || option == 50 || option == 51) // Since ASCII of 1,2,3 is 49, 50, 51
            {
                check = false;
                n = 0;
            }
        } while (check);

        string username = "";
        bool registered = false;
        switch (option)
        {
        case 49:
            // For clearing console screen
            system("cls");
            username = LoginToPassengerPanel();
            home(username);

            break;

        case 50:
            // For clearing console screen
            system("cls");
            registered = registerPassenger();
            if (registered)
            {
                LoginToPassengerPanel();
            }
            break;

        case 51:
            // For clearing console screen
            system("cls");
            MainMenuLink();
            break;
        }
        PassengerPanel();
    }
    bool LoginToAdminPanel()
    {
        cout << "\n<========= Login To Admin Panel =========>" << endl;
        cout << "\nUsername: ";
        string username;
        cin >> username;
        cout << "Password: ";
        string password = Password();

        ifstream fin("Admins.txt");
        string text;
        bool check = false;
        bool wrongCredentials = true;
        while (getline(fin, text))
        {
            if (username == "Usernames" && password == "Passwords") // Since it's the first line in file
            {
                break;
            }
            else if (text == username + " " + password)
            {
                wrongCredentials = false;
                check = true;
            }
        }
        fin.close();
        if (wrongCredentials)
        {
            cout << "\nAccess Denied. Incorrect username or password!" << endl;
            // For a brief pause of 2 seconds
            Sleep(2000);
            // For clearing console screen
            system("cls");
            return check;
        }
        else
        {
            return check;
        }
    }
    string LoginToPassengerPanel()
    {
        cout << "\n<========= Login To Passenger Panel =========>" << endl;
        cout << "\nUsername: ";
        string username;
        cin >> username;
        cout << "Password: ";
        string password = Password();
        ifstream fin("Passengers.txt");
        string text;
        bool check = false;
        bool wrongCredentials = true;
        while (getline(fin, text))
        {
            stringstream ss(text); // converting the line to stringstream for easier parsing
            string usernameInFile, passwordInFile;
            ss >> usernameInFile >> passwordInFile;
            if (username == "Usernames" && password == "Passwords") // Since it's the first line in file
            {
                break;
            }
            else if (usernameInFile == username && passwordInFile == password)
            {
                wrongCredentials = false;
                check = true;
                break;
            }
        }
        fin.close();
        if (wrongCredentials)
        {
            cout << "\nAccess Denied. Incorrect username or password!" << endl;
            // For a brief pause of 2 seconds
            Sleep(2000);
            // For clearing console screen
            system("cls");
            MainMenuLink();
            LoginToPassengerPanel();
        }
        else
        {
            // For clearing console screen
            system("cls");
            return username;
        }
    }
    void addAdmin()
    {
        cout << "<============= Add Admin =============>" << endl;
        // Admin *newAdmins = new Admin[noOfAdmins + 1];
        // for (int i = 0; i < noOfAdmins; i++)
        // {
        //     newAdmins[i] = adminsArr[i];
        // }
        // delete[] adminsArr;
        // adminsArr = nullptr;
        // adminsArr = newAdmins;
        string username = "";
        string password = "";
        // Username input and validation
        username = UsernameInputAndValidation("Admins.txt");

        // Password input and validation
        password = PasswordInputAndValidation();

        // New Admin is added to the system
        // adminsArr[noOfAdmins].setAdmin(username, password);
        // noOfAdmins += 1;
        // For clearing console screen
        system("cls");
        cout << "\nAdmin has been added successfully!" << endl;
        // For a brief pause of 2 seconds
        Sleep(2000);
        // For clearing console screen
        system("cls");

        // File handling to append the credentials of the new admin to the file
        UpdateFileWithCredentials(username, password, "Admins.txt");
    }
    bool registerPassenger()
    {
        cout << "<============= Register =============>" << endl;
        // Passenger *newPassengers = new Passenger[noOfPassengers + 1];
        // for (int i = 0; i < noOfPassengers; i++)
        // {
        //     newPassengers[i] = passengersArr[i];
        // }
        // delete[] passengersArr;
        // passengersArr = nullptr;
        // passengersArr = newPassengers;
        string username = "";
        string password = "";
        string cnic = "";

        // Username input and validation
        username = UsernameInputAndValidation("Passengers.txt");

        // Password input and validation
        password = PasswordInputAndValidation();

        // CNIC input and validation
        cnic = CnicInputAndValidation("Passengers.txt");

        // New Passenger is added to the system
        // passengersArr[noOfPassengers].setPassenger(username, password,cnic);
        // noOfPassengers += 1;

        // Verifying Financial Details
        bool check = false;
        long accountNumberLong = 0;
        long balanceLong = 0;
        string accountNumber = "";
        string balance = "";
        string passport = "";
        string visa = "";
        while (!check)
        {
            cout << "Accout Number: ";
            cin >> accountNumberLong;
            while (accountNumberLong < 1) // input validation
            {
                cout << "Invalid input." << endl;
                cout << "Accout Number: ";
                cin >> accountNumberLong;
            }
            cout << "Balance: Rs.";
            cin >> balanceLong;
            while (balanceLong < 1) // input validation
            {
                cout << "Invalid input." << endl;
                cout << "Balance: ";
                cin >> balanceLong;
            }
            accountNumber = to_string(accountNumberLong);
            balance = to_string(balanceLong);
            check = verifyFinancialDetails(accountNumber, balance);
        }
        cout << "Passport: (Foreign or Local)";
        cin >> passport;
        passport = toLower(passport);
        while (passport != "foreign" && passport != "local")
        {
            cout << "Invalid input." << endl;
            cout << "Passport: (Foreign or Local)";
            cin >> passport;
            passport = toLower(passport);
        }
        cout << "Visa: (Yes or No)";
        cin >> visa;
        visa = toLower(visa);
        while (visa != "yes" && visa != "no")
        {
            cout << "Invalid input." << endl;
            cout << "Visa: (Yes or No)";
            cin >> visa;
            visa = toLower(visa);
        }
        // For clearing console screen
        system("cls");
        cout << "\nPassenger has been registered successfully!" << endl;

        // For a brief pause of 2 seconds
        Sleep(2000);
        // For clearing console screen
        system("cls");
        // File handling to append the credentials of the new passenger to the file
        UpdateFileWithCredentials(username, password, cnic, accountNumber, balance, passport, visa, "Passengers.txt");
        return true;
    }
    // Make flight schedule
    void makeFlightSchedule()
    {
        // Setting cities to "Islamabad", "Lahore", "Quetta", "Karachi", and "Peshawar"
        for (int i = 0; i < 5; i++) // Since there are total 5 cities
        {
            cities[i].setName(cityNames[i]);
        }
        // Setting airport location for each airport
        for (int i = 0; i < 5; i++) // Since there are total 5 cities
        {
            for (int j = 0; j < 2; j++)
            {
                if (j == 0)
                {
                    cities[i].getAirports()[j].setAirportLocation("North");
                }
                if (j == 1)
                {
                    cities[i].getAirports()[j].setAirportLocation("South");
                }
            }
        }
        // Setting flight type for each airplane
        for (int i = 0; i < 5; i++) // Since there are total 5 cities
        {
            for (int j = 0; j < 2; j++)
            {
                for (int k = 0; k < 5; k++)
                {
                    for (int l = 0; l < 3; l++)
                    {
                        if (l == 0)
                        {
                            cities[i].getAirports()[j].getAirplanes()[k].getFlights()[l].setFlightType("International");
                        }
                        if (l == 1)
                        {
                            cities[i].getAirports()[j].getAirplanes()[k].getFlights()[l].setFlightType("Local");
                        }
                        if (l == 2)
                        {
                            cities[i].getAirports()[j].getAirplanes()[k].getFlights()[l].setFlightType("Local");
                        }
                    }
                }
            }
        }

        int tellsCountry = 0;
        for (int i = 0; i < 5; i++) // Since there are total 5 cities
        {
            for (int j = 0; j < 2; j++) // Since there are two airports in every city
            {
                int tellsCity = 0;
                if (tellsCountry == 25)
                {
                    tellsCountry = 0;
                }
                for (int k = 0; k < 5; k++) // Since there are at most 5 airplanes at an airport
                {
                    for (int l = 0; l < 3; l++) // Since we have 1 international flight and 2 local flights  for each plane
                    {
                        cities[i].getAirports()[j].getAirplanes()[k].getFlights()[l].setPlaceOfDeparture(cities[i].getName());
                        if (k == 0)
                        {
                            if (l == 0)
                            {
                                cities[i].getAirports()[j].getAirplanes()[k].getFlights()[l].setPlaceOfArrival(countries[tellsCountry]);
                                cities[i].getAirports()[j].getAirplanes()[k].getFlights()[l].getTime()[0].setTimeOfDeparture("00 00");
                                cities[i].getAirports()[j].getAirplanes()[k].getFlights()[l].getTime()[0].setTimeOfArrival(travelTimesForCountries[tellsCountry]);
                            }
                            if (l == 1)
                            {
                                cities[i].getAirports()[j].getAirplanes()[k].getFlights()[l].setPlaceOfArrival(cities[tellsCity].getName());
                                cities[i].getAirports()[j].getAirplanes()[k].getFlights()[l].setTerminal(terminals[0]);
                                cities[i].getAirports()[j].getAirplanes()[k].getFlights()[l].getTime()[0].setTimeOfDeparture("02 08");
                                cities[i].getAirports()[j].getAirplanes()[k].getFlights()[l].getTime()[0].setTimeOfArrival("04 08");
                            }
                            if (l == 2)
                            {
                                cities[i].getAirports()[j].getAirplanes()[k].getFlights()[l].setPlaceOfArrival(cities[tellsCity].getName());
                                cities[i].getAirports()[j].getAirplanes()[k].getFlights()[l].setTerminal(terminals[1]);
                                cities[i].getAirports()[j].getAirplanes()[k].getFlights()[l].getTime()[0].setTimeOfDeparture("08 08");
                                cities[i].getAirports()[j].getAirplanes()[k].getFlights()[l].getTime()[0].setTimeOfArrival("10 08");
                                tellsCity++;
                                tellsCountry++;
                            }
                        }
                        else if (k == 1)
                        {
                            if (l == 0)
                            {
                                cities[i].getAirports()[j].getAirplanes()[k].getFlights()[l].setPlaceOfArrival(countries[tellsCountry]);
                                cities[i].getAirports()[j].getAirplanes()[k].getFlights()[l].getTime()[0].setTimeOfDeparture("00 00");
                                cities[i].getAirports()[j].getAirplanes()[k].getFlights()[l].getTime()[0].setTimeOfArrival(travelTimesForCountries[tellsCountry]);
                            }
                            if (l == 1)
                            {
                                cities[i].getAirports()[j].getAirplanes()[k].getFlights()[l].setPlaceOfArrival(cities[tellsCity].getName());
                                cities[i].getAirports()[j].getAirplanes()[k].getFlights()[l].setTerminal(terminals[0]);
                                cities[i].getAirports()[j].getAirplanes()[k].getFlights()[l].getTime()[0].setTimeOfDeparture("03 27");
                                cities[i].getAirports()[j].getAirplanes()[k].getFlights()[l].getTime()[0].setTimeOfArrival("05 27");
                            }
                            if (l == 2)
                            {
                                cities[i].getAirports()[j].getAirplanes()[k].getFlights()[l].setPlaceOfArrival(cities[tellsCity].getName());
                                cities[i].getAirports()[j].getAirplanes()[k].getFlights()[l].setTerminal(terminals[1]);
                                cities[i].getAirports()[j].getAirplanes()[k].getFlights()[l].getTime()[0].setTimeOfDeparture("09 27");
                                cities[i].getAirports()[j].getAirplanes()[k].getFlights()[l].getTime()[0].setTimeOfArrival("11 27");
                                tellsCity++;
                                tellsCountry++;
                            }
                        }
                        else if (k == 2)
                        {
                            if (l == 0)
                            {
                                cities[i].getAirports()[j].getAirplanes()[k].getFlights()[l].setPlaceOfArrival(countries[tellsCountry]);
                                cities[i].getAirports()[j].getAirplanes()[k].getFlights()[l].getTime()[0].setTimeOfDeparture("00 00");
                                cities[i].getAirports()[j].getAirplanes()[k].getFlights()[l].getTime()[0].setTimeOfArrival(travelTimesForCountries[tellsCountry]);
                            }
                            if (l == 1)
                            {
                                cities[i].getAirports()[j].getAirplanes()[k].getFlights()[l].setPlaceOfArrival(cities[tellsCity].getName());
                                cities[i].getAirports()[j].getAirplanes()[k].getFlights()[l].setTerminal(terminals[0]);
                                cities[i].getAirports()[j].getAirplanes()[k].getFlights()[l].getTime()[0].setTimeOfDeparture("05 15");
                                cities[i].getAirports()[j].getAirplanes()[k].getFlights()[l].getTime()[0].setTimeOfArrival("07 15");
                            }
                            if (l == 2)
                            {
                                cities[i].getAirports()[j].getAirplanes()[k].getFlights()[l].setPlaceOfArrival(cities[tellsCity].getName());
                                cities[i].getAirports()[j].getAirplanes()[k].getFlights()[l].setTerminal(terminals[1]);
                                cities[i].getAirports()[j].getAirplanes()[k].getFlights()[l].getTime()[0].setTimeOfDeparture("11 15");
                                cities[i].getAirports()[j].getAirplanes()[k].getFlights()[l].getTime()[0].setTimeOfArrival("13 15");
                                tellsCity++;
                                tellsCountry++;
                            }
                        }
                        else if (k == 3)
                        {
                            if (l == 0)
                            {
                                cities[i].getAirports()[j].getAirplanes()[k].getFlights()[l].setPlaceOfArrival(countries[tellsCountry]);
                                cities[i].getAirports()[j].getAirplanes()[k].getFlights()[l].getTime()[0].setTimeOfDeparture("00 00");
                                cities[i].getAirports()[j].getAirplanes()[k].getFlights()[l].getTime()[0].setTimeOfArrival(travelTimesForCountries[tellsCountry]);
                            }
                            if (l == 1)
                            {
                                cities[i].getAirports()[j].getAirplanes()[k].getFlights()[l].setPlaceOfArrival(cities[tellsCity].getName());
                                cities[i].getAirports()[j].getAirplanes()[k].getFlights()[l].setTerminal(terminals[0]);
                                cities[i].getAirports()[j].getAirplanes()[k].getFlights()[l].getTime()[0].setTimeOfDeparture("12 30");
                                cities[i].getAirports()[j].getAirplanes()[k].getFlights()[l].getTime()[0].setTimeOfArrival("14 30");
                            }
                            if (l == 2)
                            {
                                cities[i].getAirports()[j].getAirplanes()[k].getFlights()[l].setPlaceOfArrival(cities[tellsCity].getName());
                                cities[i].getAirports()[j].getAirplanes()[k].getFlights()[l].setTerminal(terminals[1]);
                                cities[i].getAirports()[j].getAirplanes()[k].getFlights()[l].getTime()[0].setTimeOfDeparture("18 30");
                                cities[i].getAirports()[j].getAirplanes()[k].getFlights()[l].getTime()[0].setTimeOfArrival("20 30");
                                tellsCity++;
                                tellsCountry++;
                            }
                        }
                        else if (k == 4)
                        {
                            if (l == 0)
                            {
                                cities[i].getAirports()[j].getAirplanes()[k].getFlights()[l].setPlaceOfArrival(countries[tellsCountry]);
                                cities[i].getAirports()[j].getAirplanes()[k].getFlights()[l].getTime()[0].setTimeOfDeparture("00 00");
                                cities[i].getAirports()[j].getAirplanes()[k].getFlights()[l].getTime()[0].setTimeOfArrival(travelTimesForCountries[tellsCountry]);
                            }
                            if (l == 1)
                            {
                                cities[i].getAirports()[j].getAirplanes()[k].getFlights()[l].setPlaceOfArrival(cities[tellsCity].getName());
                                cities[i].getAirports()[j].getAirplanes()[k].getFlights()[l].setTerminal(terminals[0]);
                                cities[i].getAirports()[j].getAirplanes()[k].getFlights()[l].getTime()[0].setTimeOfDeparture("14 35");
                                cities[i].getAirports()[j].getAirplanes()[k].getFlights()[l].getTime()[0].setTimeOfArrival("16 35");
                            }
                            if (l == 2)
                            {
                                cities[i].getAirports()[j].getAirplanes()[k].getFlights()[l].setPlaceOfArrival(cities[tellsCity].getName());
                                cities[i].getAirports()[j].getAirplanes()[k].getFlights()[l].setTerminal(terminals[1]);
                                cities[i].getAirports()[j].getAirplanes()[k].getFlights()[l].getTime()[0].setTimeOfDeparture("20 35");
                                cities[i].getAirports()[j].getAirplanes()[k].getFlights()[l].getTime()[0].setTimeOfArrival("22 35");
                                tellsCity++;
                                tellsCountry++;
                            }
                        }
                    }
                }
            }
        }
    }
    // Flight Schedule for local flights
    void localFlightSchedule()
    {
        cout << "\n<=============== Local Flight Schedule ===============>" << endl;
        string cityOfDeparture;
        bool check = true;
        int n = 0;
        int temp = 0;
        do
        {
            if (n > 0)
            {
                cout << "\nInvalid input." << endl;
            }
            cout << "\nChoose City of Departure: (\"Islamabad\", \"Lahore\", \"Quetta\", \"Karachi\", \"Peshawar\")" << endl;
            cin >> cityOfDeparture;
            n++;
            if (toLower(cityOfDeparture) == "islamabad" || toLower(cityOfDeparture) == "lahore" || toLower(cityOfDeparture) == "quetta" || toLower(cityOfDeparture) == "karachi" || toLower(cityOfDeparture) == "peshawar")
            {
                if (toLower(cityOfDeparture) == "islamabad")
                {
                    temp = 0;
                }
                else if (toLower(cityOfDeparture) == "lahore")
                {
                    temp = 1;
                }
                else if (toLower(cityOfDeparture) == "quetta")
                {
                    temp = 2;
                }
                else if (toLower(cityOfDeparture) == "karachi")
                {
                    temp = 3;
                }
                else if (toLower(cityOfDeparture) == "peshawar")
                {
                    temp = 4;
                }
                check = false;
                n = 0;
            }
        } while (check);
        string cityOfArrival;
        check = true;
        do
        {
            if (n > 0)
            {
                cout << "\nInvalid input." << endl;
            }
            cout << "\nChoose City of Arrival: (\"Islamabad\", \"Lahore\", \"Quetta\", \"Karachi\", \"Peshawar\")" << endl;
            cin >> cityOfArrival;
            n++;
            if (toLower(cityOfArrival) == toLower(cityOfDeparture))
            {
                cout << "\nCity of arrival and city of departure cannot be same!";
            }
            else if (toLower(cityOfArrival) == "islamabad" || toLower(cityOfArrival) == "lahore" || toLower(cityOfArrival) == "quetta" || toLower(cityOfArrival) == "karachi" || toLower(cityOfArrival) == "peshawar") // Since ASCII of 1,2,3 is 49, 50, 51
            {
                check = false;
                n = 0;
            }
        } while (check);
        // For a brief pause of 2 seconds
        Sleep(2000);
        // For clearing console screen
        system("cls");
        // Displaying the scheduled flights for the selected citites
        for (int i = temp; i < temp + 1; i++) // Since there is 1 sepecified city
        {
            for (int j = 0; j < 2; j++) // Since there are two airports in every city
            {
                cout << "\n<================ " << cities[i].getAirports()[j].getAirportLocation() << " " << cities[i].getName() << " Airport ================>" << endl;
                cout << "\nDEPARTURES" << endl;
                cout << "\n"
                     << setw(16) << "DESTINATION" << setw(22) << "TIME OF DEPARTURE" << setw(20) << "TIME OF ARRIVAL" << endl;
                for (int k = 0; k < 5; k++) // Since there are at most 5 airplanes at an airport
                {
                    for (int l = 1; l < 3; l++) // Since we have 1 international flight and 2 local flights  for each plane
                    {
                        if (toLower(cities[i].getAirports()[j].getAirportLocation()) == "north")
                        {
                            if (cities[i].getAirports()[j].getAirplanes()[k].getFlights()[l].getFlightType() == "Local")
                            {
                                if (toLower(cities[i].getAirports()[j].getAirplanes()[k].getFlights()[l].getPlaceOfArrival()) == toLower(cityOfArrival))
                                {
                                    // Destination:
                                    {
                                        string str = cities[i].getAirports()[j].getAirplanes()[k].getFlights()[l].getTerminal() + " " + cities[i].getAirports()[j].getAirplanes()[k].getFlights()[l].getPlaceOfArrival();
                                        cout << setw(18) << str;
                                    }
                                    // Time of departure:
                                    {
                                        cout << setw(12) << cities[i].getAirports()[j].getAirplanes()[k].getFlights()[l].getTime()[0].getTimeOfDeparture();
                                    }
                                    // Time of arrival:
                                    {
                                        cout << setw(20) << cities[i].getAirports()[j].getAirplanes()[k].getFlights()[l].getTime()[0].getTimeOfArrival();
                                    }
                                    cout << endl;
                                }
                            }
                        }
                        if (toLower(cities[i].getAirports()[j].getAirportLocation()) == "south")
                        {
                            if (cities[i].getAirports()[j].getAirplanes()[k].getFlights()[l].getFlightType() == "Local")
                            {
                                if (toLower(cities[i].getAirports()[j].getAirplanes()[k].getFlights()[l].getPlaceOfArrival()) == toLower(cityOfArrival))
                                {
                                    // Destination:
                                    {
                                        string str = cities[i].getAirports()[j].getAirplanes()[k].getFlights()[l].getTerminal() + " " + cities[i].getAirports()[j].getAirplanes()[k].getFlights()[l].getPlaceOfArrival();
                                        cout << setw(18) << str;
                                    }
                                    // Time of departure:
                                    {
                                        cout << setw(12) << cities[i].getAirports()[j].getAirplanes()[k].getFlights()[l].getTime()[0].getTimeOfDeparture();
                                    }
                                    // Time of arrival:
                                    {
                                        cout << setw(20) << cities[i].getAirports()[j].getAirplanes()[k].getFlights()[l].getTime()[0].getTimeOfArrival();
                                    }
                                    cout << endl;
                                }
                            }
                        }
                    }
                }
            }
        }
        RefreshScreen();
    }
    // Flight Schedule for international flights
    void internationalFlightSchedule()
    {
        cout << "\n<================ International Flight Schedule ================>" << endl;
        string countryOfArrival = "";
        bool check = true;
        int n = 0;
        do
        {
            if (n > 0)
            {
                cout << "\nInvalid input." << endl;
            }
            cout << "\nChoose Country of Arrival: (\"United States\", \"Canada\", \"United Kingdom\", \"Germany\", \"France\", \"Italy\", \"Spain\", \"China\", \"Switzerland\", \"Norway\", \"Sweden\", \"Denmark\", \"Australia\", \"New Zealand\", \"Japan\", \"South Korea\", \"Singapore\", \"United Arab Emirates\", \"Bahrain\", \"Qatar\", \"Kuwait\", \"Saudi Arabia\", \"Oman\", \"Taiwan\", \"Hong Kong\")" << endl;
            getline(cin, countryOfArrival);
            n++;
            if (toLower(countryOfArrival) == toLower("United States") || toLower(countryOfArrival) == toLower("Canada") || toLower(countryOfArrival) == toLower("United Kingdom") || toLower(countryOfArrival) == toLower("Germany") || toLower(countryOfArrival) == toLower("France") || toLower(countryOfArrival) == toLower("Italy") || toLower(countryOfArrival) == toLower("Spain") || toLower(countryOfArrival) == toLower("China") || toLower(countryOfArrival) == toLower("Switzerland") || toLower(countryOfArrival) == toLower("Norway") || toLower(countryOfArrival) == toLower("Sweden") || toLower(countryOfArrival) == toLower("Denmark") || toLower(countryOfArrival) == toLower("Australia") || toLower(countryOfArrival) == toLower("New Zealand") || toLower(countryOfArrival) == toLower("Japan") || toLower(countryOfArrival) == toLower("South Korea") || toLower(countryOfArrival) == toLower("Singapore") || toLower(countryOfArrival) == toLower("United Arab Emirates") || toLower(countryOfArrival) == toLower("Bahrain") || toLower(countryOfArrival) == toLower("Qatar") || toLower(countryOfArrival) == toLower("Kuwait") || toLower(countryOfArrival) == toLower("Saudi Arabia") || toLower(countryOfArrival) == toLower("Oman") || toLower(countryOfArrival) == toLower("Taiwan") || toLower(countryOfArrival) == toLower("Hong Kong"))
            {
                check = false;
                n = 0;
            }
        } while (check);
        // For a brief pause of 2 seconds
        Sleep(2000);
        // For clearing console screen
        system("cls");
        // Displaying the scheduled flights for the selected citites
        bool display = true;
        for (int i = 0; i < 5; i++) // Since there are 5 cities
        {
            for (int j = 0; j < 2; j++) // Since there are two airports in every city
            {
                if (j == 1)
                {
                    display = true;
                }
                for (int k = 0; k < 5; k++) // Since there are at most 5 airplanes at an airport
                {
                    for (int l = 0; l < 1; l++) // Since we have 1 international flight for each plane
                    {
                        if (toLower(cities[i].getAirports()[j].getAirportLocation()) == "north")
                        {
                            if (toLower(cities[i].getAirports()[j].getAirplanes()[k].getFlights()[l].getPlaceOfArrival()) == toLower(countryOfArrival))
                            {
                                if (display)
                                {
                                    cout << "\n<================ " << cities[i].getAirports()[j].getAirportLocation() << " " << cities[i].getName() << " Airport ================>" << endl;
                                    cout << "\nDEPARTURES" << endl;
                                    cout << "\n"
                                         << setw(14) << "DESTINATION" << setw(22) << "TIME OF DEPARTURE" << setw(20) << "TIME OF ARRIVAL" << endl;
                                    display = false;
                                }
                                // Destination:
                                {
                                    string str = cities[i].getAirports()[j].getAirplanes()[k].getFlights()[l].getTerminal() + " " + cities[i].getAirports()[j].getAirplanes()[k].getFlights()[l].getPlaceOfArrival();
                                    cout << setw(18) << str;
                                }
                                // Time of departure:
                                {
                                    cout << setw(12) << cities[i].getAirports()[j].getAirplanes()[k].getFlights()[l].getTime()[0].getTimeOfDeparture();
                                }
                                // Time of arrival:
                                {
                                    cout << setw(20) << cities[i].getAirports()[j].getAirplanes()[k].getFlights()[l].getTime()[0].getTimeOfArrival();
                                }
                                cout << endl;
                            }
                        }
                        if (toLower(cities[i].getAirports()[j].getAirportLocation()) == "south")
                        {
                            if (toLower(cities[i].getAirports()[j].getAirplanes()[k].getFlights()[l].getPlaceOfArrival()) == toLower(countryOfArrival))
                            {
                                if (display)
                                {
                                    cout << "\n<====== " << cities[i].getAirports()[j].getAirportLocation() << " " << cities[i].getName() << " Airport ======>" << endl;
                                    cout << "\nDEPARTURES" << endl;
                                    cout << "\n"
                                         << setw(14) << "DESTINATION" << setw(22) << "TIME OF DEPARTURE" << setw(20) << "TIME OF ARRIVAL" << endl;
                                    display = false;
                                }
                                // Destination:
                                {
                                    string str = cities[i].getAirports()[j].getAirplanes()[k].getFlights()[l].getTerminal() + " " + cities[i].getAirports()[j].getAirplanes()[k].getFlights()[l].getPlaceOfArrival();
                                    cout << setw(18) << str;
                                }
                                // Time of departure:
                                {
                                    cout << setw(12) << cities[i].getAirports()[j].getAirplanes()[k].getFlights()[l].getTime()[0].getTimeOfDeparture();
                                }
                                // Time of arrival:
                                {
                                    cout << setw(20) << cities[i].getAirports()[j].getAirplanes()[k].getFlights()[l].getTime()[0].getTimeOfArrival();
                                }
                                cout << endl;
                            }
                        }
                    }
                }
            }
        }
        RefreshScreen();
    }
    // Displaying flight schedule
    void displayFlightSchedule()
    {
        cout << "\n<================== Flight Schedule ==================>" << endl;
        char option; // We used char instead of int because if we use int and the user enters a char, the system does not respond with sanity
        bool check = true;
        int n = 0;
        do
        {
            if (n > 0)
            {
                cout << "\nInvalid input." << endl;
            }
            cout << "\nPress '1' to check scheduled 'Local Flights'" << endl
                 << "Press '2' to check scheduled 'International Flights'" << endl
                 << "Press '3' to go to 'Main Menu'" << endl;
            cin >> option;
            n++;
            if (option == 49 || option == 50 || option == 51) // Since ASCII of 1,2,3 is 49, 50, 51
            {
                check = false;
                n = 0;
            }
        } while (check);
        switch (option)
        {
        case 49:
            // For clearing console screen
            system("cls");
            localFlightSchedule();
            break;

        case 50:
            // For clearing console screen
            system("cls");
            internationalFlightSchedule();
            break;

        case 51:
            // For clearing console screen
            system("cls");
            MainMenuLink();
            break;
        }
        displayFlightSchedule();
    }
    void addNewRouteForLocalFlight()
    {
        cout << "\n<=============== Local Flight Scheduling ===============>" << endl;
        string cityOfDeparture;
        bool check = true;
        int n = 0;
        int temp = 0;
        do
        {
            if (n > 0)
            {
                cout << "\nInvalid input." << endl;
            }
            cout << "\nChoose City of Departure: (\"Islamabad\", \"Lahore\", \"Quetta\", \"Karachi\", \"Peshawar\")" << endl;
            cin >> cityOfDeparture;
            n++;
            if (toLower(cityOfDeparture) == "islamabad" || toLower(cityOfDeparture) == "lahore" || toLower(cityOfDeparture) == "quetta" || toLower(cityOfDeparture) == "karachi" || toLower(cityOfDeparture) == "peshawar")
            {
                if (toLower(cityOfDeparture) == "islamabad")
                {
                    temp = 0;
                }
                else if (toLower(cityOfDeparture) == "lahore")
                {
                    temp = 1;
                }
                else if (toLower(cityOfDeparture) == "quetta")
                {
                    temp = 2;
                }
                else if (toLower(cityOfDeparture) == "karachi")
                {
                    temp = 3;
                }
                else if (toLower(cityOfDeparture) == "peshawar")
                {
                    temp = 4;
                }
                check = false;
                n = 0;
            }
        } while (check);
        string cityOfArrival;
        check = true;
        do
        {
            if (n > 0)
            {
                cout << "\nInvalid input." << endl;
            }
            cout << "\nChoose City of Arrival: (\"Islamabad\", \"Lahore\", \"Quetta\", \"Karachi\", \"Peshawar\")" << endl;
            cin >> cityOfArrival;
            n++;
            if (toLower(cityOfArrival) == toLower(cityOfDeparture))
            {
                cout << "\nCity of arrival and city of departure cannot be same!";
            }
            else if (toLower(cityOfArrival) == "islamabad" || toLower(cityOfArrival) == "lahore" || toLower(cityOfArrival) == "quetta" || toLower(cityOfArrival) == "karachi" || toLower(cityOfArrival) == "peshawar") // Since ASCII of 1,2,3 is 49, 50, 51
            {
                check = false;
                n = 0;
            }
        } while (check);
        string terminal = "";
        cout << "Select Terminal: (North or South)";
        cin >> terminal;
        terminal = toLower(terminal);
        while (terminal != "north" && terminal != "south")
        {
            cout << "Invalid input." << endl;
            cout << "Select Terminal: (North or South)";
            cin >> terminal;
            terminal = toLower(terminal);
        }
        int temp2 = 0;
        if (terminal == "north")
        {
            temp2 = 0;
        }
        else if (terminal == "south")
        {
            temp2 = 1;
        }
        // Setting the new route
        cities[temp].getAirports()[temp2].getAirplanes()[0].addFlight();
        int noOfFlights = cities[temp].getAirports()[temp2].getAirplanes()[0].getNoOfFlights() - 1;
        cities[temp].getAirports()[temp2].getAirplanes()[0].getFlights()[noOfFlights].setFlightType("Local");
        cities[temp].getAirports()[temp2].getAirplanes()[0].getFlights()[noOfFlights].setPlaceOfDeparture(cityNames[temp]);
        cities[temp].getAirports()[temp2].getAirplanes()[0].getFlights()[noOfFlights].setPlaceOfArrival(cityOfArrival);
        cout << "Time of Departure: (24 hour format e.g. 14 00)";
        string timeOfDeparture;
        getline(cin, timeOfDeparture);
        cities[temp].getAirports()[temp2].getAirplanes()[0].getFlights()[noOfFlights].getTime()[0].setTimeOfDeparture(timeOfDeparture);
        cout << "Time of Arrival: (24 hour format e.g. 14 00)";
        string timeOfArrival;
        getline(cin, timeOfArrival);
        cities[temp].getAirports()[temp2].getAirplanes()[0].getFlights()[noOfFlights].getTime()[0].setTimeOfArrival(timeOfArrival);

        cout << "Route added Successfully!" << endl;
        // For a brief pause of 2 seconds
        Sleep(2000);
        // For clearing console screen
        system("cls");
    }
    void addNewRouteForInternationalFlight()
    {
        cout << "\n<================ International Flight Scheduling ================>" << endl;
        string cityOfDeparture;
        bool check = true;
        int n = 0;
        int temp = 0;
        do
        {
            if (n > 0)
            {
                cout << "\nInvalid input." << endl;
            }
            cout << "\nChoose City of Departure: (\"Islamabad\", \"Lahore\", \"Quetta\", \"Karachi\", \"Peshawar\")" << endl;
            cin >> cityOfDeparture;
            n++;
            if (toLower(cityOfDeparture) == "islamabad" || toLower(cityOfDeparture) == "lahore" || toLower(cityOfDeparture) == "quetta" || toLower(cityOfDeparture) == "karachi" || toLower(cityOfDeparture) == "peshawar")
            {
                if (toLower(cityOfDeparture) == "islamabad")
                {
                    temp = 0;
                }
                else if (toLower(cityOfDeparture) == "lahore")
                {
                    temp = 1;
                }
                else if (toLower(cityOfDeparture) == "quetta")
                {
                    temp = 2;
                }
                else if (toLower(cityOfDeparture) == "karachi")
                {
                    temp = 3;
                }
                else if (toLower(cityOfDeparture) == "peshawar")
                {
                    temp = 4;
                }
                check = false;
                n = 0;
            }
        } while (check);
        string countryOfArrival;
        check = true;
        do
        {
            if (n > 0)
            {
                cout << "\nInvalid input." << endl;
            }
            cout << "\nChoose Country of Arrival: (\"United States\", \"Canada\", \"United Kingdom\", \"Germany\", \"France\", \"Italy\", \"Spain\", \"China\", \"Switzerland\", \"Norway\", \"Sweden\", \"Denmark\", \"Australia\", \"New Zealand\", \"Japan\", \"South Korea\", \"Singapore\", \"United Arab Emirates\", \"Bahrain\", \"Qatar\", \"Kuwait\", \"Saudi Arabia\", \"Oman\", \"Taiwan\", \"Hong Kong\")" << endl;
            getline(cin, countryOfArrival);
            n++;
            if (toLower(countryOfArrival) == toLower("United States") || toLower(countryOfArrival) == toLower("Canada") || toLower(countryOfArrival) == toLower("United Kingdom") || toLower(countryOfArrival) == toLower("Germany") || toLower(countryOfArrival) == toLower("France") || toLower(countryOfArrival) == toLower("Italy") || toLower(countryOfArrival) == toLower("Spain") || toLower(countryOfArrival) == toLower("China") || toLower(countryOfArrival) == toLower("Switzerland") || toLower(countryOfArrival) == toLower("Norway") || toLower(countryOfArrival) == toLower("Sweden") || toLower(countryOfArrival) == toLower("Denmark") || toLower(countryOfArrival) == toLower("Australia") || toLower(countryOfArrival) == toLower("New Zealand") || toLower(countryOfArrival) == toLower("Japan") || toLower(countryOfArrival) == toLower("South Korea") || toLower(countryOfArrival) == toLower("Singapore") || toLower(countryOfArrival) == toLower("United Arab Emirates") || toLower(countryOfArrival) == toLower("Bahrain") || toLower(countryOfArrival) == toLower("Qatar") || toLower(countryOfArrival) == toLower("Kuwait") || toLower(countryOfArrival) == toLower("Saudi Arabia") || toLower(countryOfArrival) == toLower("Oman") || toLower(countryOfArrival) == toLower("Taiwan") || toLower(countryOfArrival) == toLower("Hong Kong"))
            {
                check = false;
                n = 0;
            }
        } while (check);
        string terminal = "";
        cout << "Select Terminal: (North or South)";
        cin >> terminal;
        terminal = toLower(terminal);
        while (terminal != "north" && terminal != "south")
        {
            cout << "Invalid input." << endl;
            cout << "Select Terminal: (North or South)";
            cin >> terminal;
            terminal = toLower(terminal);
        }
        int temp2 = 0;
        if (terminal == "north")
        {
            temp2 = 0;
        }
        else if (terminal == "south")
        {
            temp2 = 1;
        }
        // Setting the new route
        cities[temp].getAirports()[temp2].getAirplanes()[0].addFlight();
        int noOfFlights = cities[temp].getAirports()[temp2].getAirplanes()[0].getNoOfFlights() - 1;
        cities[temp].getAirports()[temp2].getAirplanes()[0].getFlights()[noOfFlights].setFlightType("International");
        cities[temp].getAirports()[temp2].getAirplanes()[0].getFlights()[noOfFlights].setPlaceOfDeparture(cityNames[temp]);
        cities[temp].getAirports()[temp2].getAirplanes()[0].getFlights()[noOfFlights].setPlaceOfArrival(countryOfArrival);
        cout << "Time of Departure: (24 hour format e.g. 14 00)";
        string timeOfDeparture;
        getline(cin, timeOfDeparture);
        cities[temp].getAirports()[temp2].getAirplanes()[0].getFlights()[noOfFlights].getTime()[0].setTimeOfDeparture(timeOfDeparture);
        cout << "Time of Arrival: (24 hour format e.g. 14 00)";
        string timeOfArrival;
        getline(cin, timeOfArrival);
        cities[temp].getAirports()[temp2].getAirplanes()[0].getFlights()[noOfFlights].getTime()[0].setTimeOfArrival(timeOfArrival);

        cout << "Route added Successfully!" << endl;
        // For a brief pause of 2 seconds
        Sleep(2000);
        // For clearing console screen
        system("cls");
    }
    void addNewRoute()
    {
        char option; // We used char instead of int because if we use int and the user enters a char, the system does not respond with sanity
        bool check = true;
        int n = 0;
        do
        {
            if (n > 0)
            {
                cout << "\nInvalid input." << endl;
            }
            cout << "\n<============== Add Route ==============>" << endl
                 << "\nPress '1' to add route for 'Local Flight'" << endl
                 << "Press '2' to add route for 'International Flight'" << endl
                 << "Press '3' to go to 'Main Menu'" << endl
                 << "Press '4' to go back" << endl;
            cin >> option;
            n++;
            if (option == 49 || option == 50 || option == 51 || option == 52) // Since ASCII of 1,2,3 is 49, 50, 51
            {
                check = false;
                n = 0;
            }
        } while (check);

        switch (option)
        {
        case 49:
            // For clearing console screen
            system("cls");
            addNewRouteForLocalFlight();
            break;

        case 50:
            // For clearing console screen
            system("cls");
            addNewRouteForInternationalFlight();
            break;

        case 51:
            // For clearing console screen
            system("cls");
            MainMenuLink();
            break;

        case 52:
            // For clearing console screen
            system("cls");
            return;
        }
    }
    void updateEmail()
    {
        string email;
        cout << "Enter new email address: ";
        cin >> email;
        bool check = false;
        check = isValidEmail(email);
        while (!check)
        {
            cout << "Invalid email" << endl;
            cout << "Enter new email address: ";
            cin >> email;
            check = isValidEmail(email);
        }
        inquiryDetails.setEmail(email);
        cout << "Email Address successfully updated!" << endl;
        // For a brief pause of 2 seconds
        Sleep(2000);
        // For clearing console screen
        system("cls");
    }
    void updateContactNumber()
    {
        string contactNumber;
        cout << "Enter new contactNumber address: ";
        cin >> contactNumber;
        bool check = false;
        check = isValidContactNumber(contactNumber);
        while (!check)
        {
            cout << "Invalid contact number" << endl;
            cout << "Enter new contact number: ";
            cin >> contactNumber;
            check = isValidContactNumber(contactNumber);
        }
        inquiryDetails.setContactNumber(contactNumber);
        cout << "Contact number successfully updated!" << endl;
        // For a brief pause of 2 seconds
        Sleep(2000);
        // For clearing console screen
        system("cls");
    }
    void updateAddressOfHeadOffice()
    {
        string addressOfHeadOffice;
        cout << "Enter new address: ";
        cin >> addressOfHeadOffice;
        inquiryDetails.setAddressOfHeadOffice(addressOfHeadOffice);
        cout << "Address of Head Office successfully updated!" << endl;
        // For a brief pause of 2 seconds
        Sleep(2000);
        // For clearing console screen
        system("cls");
    }
    void updateAirineInquiryDetails()
    {
        char option; // We used char instead of int because if we use int and the user enters a char, the system does not respond with sanity
        bool check = true;
        int n = 0;
        do
        {
            if (n > 0)
            {
                cout << "\nInvalid input." << endl;
            }
            cout << "\n<====== Update Airline Inquiry Details ======>" << endl
                 << "\nPress '1' to update 'Email'" << endl
                 << "Press '2' to update 'Contact Number'" << endl
                 << "Press '3' to update 'Address of Head Office'" << endl
                 << "Press '4' to go to 'Main Menu'" << endl
                 << "Press '5' to go back" << endl;
            cin >> option;
            n++;
            if (option == 49 || option == 50 || option == 51 || option == 52 || option == 53) // Since ASCII of 1,2,3 is 49, 50, 51
            {
                check = false;
                n = 0;
            }
        } while (check);

        switch (option)
        {
        case 49:
            // For clearing console screen
            system("cls");
            updateEmail();
            break;

        case 50:
            // For clearing console screen
            system("cls");
            updateContactNumber();
            break;

        case 51:
            // For clearing console screen
            system("cls");
            updateAddressOfHeadOffice();
            break;

        case 52:
            // For clearing console screen
            system("cls");
            MainMenuLink();
            break;

        case 53:
            // For clearing console screen
            system("cls");
            return;
        }
        updateAirineInquiryDetails();
    }
};