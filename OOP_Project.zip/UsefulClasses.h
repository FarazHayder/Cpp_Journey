#pragma once

class InquiryDetails
{
protected:
    string email;
    string contactNumber;
    string addressOfHeadOffice;

public:
    // Constructors
    InquiryDetails()
    {
        email = "";
        contactNumber = "";
        addressOfHeadOffice = "";
    }
    InquiryDetails(string email, string contactNumber, string addressOfHeadOffice)
    {
        this->email = email;
        this->contactNumber = contactNumber;
        this->addressOfHeadOffice = addressOfHeadOffice;
    }
    // Setters and getters
    void setInquiryDetails(string email, string contactNumber, string addressOfHeadOffice)
    {
        this->email = email;
        this->contactNumber = contactNumber;
        this->addressOfHeadOffice = addressOfHeadOffice;
    }
    void setEmail(string email)
    {
        this->email = email;
    }
    string getEmail()
    {
        return email;
    }
    void setContactNumber(string contactNumber)
    {
        this->contactNumber = contactNumber;
    }
    string getContactNumber()
    {
        return contactNumber;
    }
    void setAddressOfHeadOffice(string addressOfHeadOffice)
    {
        this->addressOfHeadOffice = addressOfHeadOffice;
    }
    string getAddressOfHeadOffice()
    {
        return addressOfHeadOffice;
    }
};

class Time
{
protected:
    string timeOfArrival;
    string timeOfDeparture;

public:
    //  Constructor
    Time(string timeOfArrival = "", string timeOfDeparture = "")
    {
        this->timeOfArrival = timeOfArrival;
        this->timeOfDeparture = timeOfDeparture;
    }

    // Setters and getters
    void setTimeOfArrival(string timeOfArrival)
    {
        this->timeOfArrival = timeOfArrival;
    }
    string getTimeOfArrival()
    {
        return timeOfArrival;
    }
    void setTimeOfDeparture(string timeOfDeparture)
    {
        this->timeOfDeparture = timeOfDeparture;
    }
    string getTimeOfDeparture()
    {
        return timeOfDeparture;
    }
};

class Seating
{
protected:
    int totalEconomySeats;
    int totalBusinessSeats;
    int availableEconomySeats;
    int availableBusinessSeats;

public:
    // Cconstructor
    Seating(int availableEconomySeats = 50, int availableBusinessSeats = 10, bool corona = false)
    {
        this->availableEconomySeats = availableEconomySeats;
        this->availableBusinessSeats = availableBusinessSeats;
        if (!corona)
        {
            totalEconomySeats = 50;
            totalBusinessSeats = 10;
        }
        else
        {
            totalEconomySeats = 25;
            totalBusinessSeats = 5;
        }
    }
    // Setters and getters
    void setEconomySeats(int availableEconomySeats)
    {
        this->availableEconomySeats = availableEconomySeats;
        while (!(availableEconomySeats > totalEconomySeats || availableEconomySeats < 0)) // input validation
        {
            cout << "Invalid input." << endl;
            cout << "Enter again: ";
            cin >> availableEconomySeats;
        }
    }
    int getEconomySeats() const
    {
        return availableEconomySeats;
    }
    void setBusinessSeats(int availableBusinessSeats)
    {
        this->availableBusinessSeats = availableBusinessSeats;
        while (!(availableBusinessSeats > totalBusinessSeats || availableBusinessSeats < 0)) // input validation
        {
            cout << "Invalid input." << endl;
            cout << "Enter again: ";
            cin >> availableBusinessSeats;
        }
    }
    int getBusinessSeats() const
    {
        return availableBusinessSeats;
    }
    // Methods
    void restrictSeats()
    {
        totalEconomySeats /= 2;
        totalBusinessSeats /= 2;
    }
};

// Important Classes
class Flight
{
protected:
    string flightType;
    string placeOfDeparture;
    string placeOfArrival;
    string terminal; // used in case of local flights (North of South)
    Time *time;

public:
    // Constructors
    Flight(string flightType = "", string placeOfDeparture = "", string placeOfArrival = "", string terminal = "", Time *time = new Time())
    {
        this->flightType = flightType;
        this->placeOfDeparture = placeOfDeparture;
        this->placeOfArrival = placeOfArrival;
        this->terminal = terminal;
        this->time = time;
    }
    // Setters and getters
    void setFlightType(string flightType)
    {
        this->flightType = flightType;
    }
    string getFlightType() const
    {
        return flightType;
    }
    void setPlaceOfDeparture(string placeOfDeparture)
    {
        this->placeOfDeparture = placeOfDeparture;
    }
    string getPlaceOfDeparture() const
    {
        return placeOfDeparture;
    }
    void setPlaceOfArrival(string placeOfArrival)
    {
        this->placeOfArrival = placeOfArrival;
    }
    string getPlaceOfArrival() const
    {
        return placeOfArrival;
    }
    void setTerminal(string terminal)
    {
        this->terminal = terminal;
    }
    string getTerminal() const
    {
        return terminal;
    }
    void setTime(Time *time)
    {
        this->time = time;
    }
    Time *getTime()
    {
        return time;
    }
};

class Airplane
{
protected:
    Seating *seating;
    bool corona;
    int noOfFlights;
    Flight *flights; // = new Flight[3]; flights[0]=International, flights[1]=Local, flights[2]=Local;

public:
    // Constructors
    Airplane(Seating *seating = new Seating(), bool corona = false, int noOfFlights = 3, Flight *flights = new Flight[3])
    {
        this->seating = seating;
        this->corona = corona;
        this->noOfFlights = noOfFlights;
        this->flights = flights;
    }
    // Setters and getters
    void setSeating(Seating *seating)
    {
        this->seating = seating;
    }
    Seating *getSeating()
    {
        return seating;
    }
    void setCorona(bool corona)
    {
        this->corona = corona;
    }
    bool getCorona() const
    {
        return corona;
    }
    void setNoOfFlights(bool noOfFlights)
    {
        this->noOfFlights = noOfFlights;
    }
    bool getNoOfFlights() const
    {
        return noOfFlights;
    }
    void setFlights(Flight *flights)
    {
        this->flights = flights;
    }
    Flight *getFlights()
    {
        return flights;
    }
    // Methods
    void addFlight()
    {
        Flight *newFlights = new Flight[noOfFlights + 1];
        for (int i = 0; i < noOfFlights; i++)
        {
            newFlights[i] = flights[i];
        }
        delete[] flights;
        flights = nullptr;
        flights = newFlights;
        noOfFlights += 1;
    }
};

class Airport
{
protected:
    string name;
    string airportLocation; // north or south
    Airplane *airplanes;

public:
    // Constructors
    Airport(string name = "", string airportLocation = "", Airplane *airplanes = new Airplane[5])
    {
        this->name = name;
        this->airportLocation = airportLocation;
        this->airplanes = airplanes;
    }
    // Setters and getters
    void setName(string name)
    {
        this->name = name;
    }
    string getName() const
    {
        return name;
    }
    void setAirportLocation(string airportLocation)
    {
        this->airportLocation = airportLocation;
    }
    string getAirportLocation() const
    {
        return airportLocation;
    }
    void setAirplanes(Airplane *airplanes)
    {
        this->airplanes = airplanes;
    }
    Airplane *getAirplanes()
    {
        return airplanes;
    }
};

class City
{
protected:
    string name;
    Airport *airports;

public:
    // Constructors
    City(string name = "", Airport *airports = new Airport[2])
    {
        this->name = name;
        this->airports = airports;
    }
    // Setters and getters
    void setName(string name)
    {
        this->name = name;
    }
    string getName() const
    {
        return name;
    }
    void setAirports(Airport *airports)
    {
        this->airports = airports;
    }
    Airport *getAirports()
    {
        return airports;
    }
};
