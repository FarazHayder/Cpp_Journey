#include "headerAndUsefulFunctions.h"

int main()
{
    // Seeding the random number generator with the current time
    srand(time(NULL));
    // To create the system object
    NAFS nafs;
    // To go to Main Menu
    nafs.MainMenu();

    return 0;
}