// AhmedAyyan_22i-2422_SE-G
#include "header.h"
using namespace std;

int main()
{
    Tree tree;

    // Insert nodes into the perfect binary tree
    tree.insertNode(new TreeNode("/", "/", ""));
    tree.insertNode(new TreeNode("PatientsData", "/PatientsData", "Directory"));
    tree.insertNode(new TreeNode("Logs", "/Logs", "Directory"));
    tree.insertNode(new TreeNode("PatientsHome", "/PatientsData PatientsHome", "Directory"));
    tree.insertNode(new TreeNode("PatientsList.txt", "/PatientsData PatientsList.txt", "File"));
    tree.insertNode(new TreeNode("LogsHome", "/Logs LogsHome", "Directory"));
    tree.insertNode(new TreeNode("LogReport.pdf", "/Logs LogReport.pdf", "File"));

    tree.addDirectory("PatientA", "/PatientsData PatientsHome");
    tree.addFile("ReportA.pdf", "/PatientsData PatientsHome");
    tree.addDirectory("PatientB", "/PatientsData PatientsHome");
    tree.addFile("ReportB.pdf", "/PatientsData PatientsHome");
    tree.addDirectory("Jan", "/Logs LogsHome");
    tree.addFile("JLog.txt", "/Logs LogsHome");
    tree.addDirectory("Feb", "/Logs LogsHome");
    tree.addFile("FLog.txt", "/Logs LogsHome");

    // tree.MainMenu();
    //  tree.addDirectory("PatientC", "/PatientsData PatientsHome");

    // tree.addFile("ReportC.pdf", "/PatientsData PatientsHome");

    // done
    //  Add a directory based on the specified conditions
    //  Menu:-
    //  1. Add a directory
    //   1.1 Where? 1) PatientData 2)Logs
    //  Implementation of 1) PatientData:
    //  string name = "PatientC";
    //  tree.addDirectory(name, "/PatientsData PatientsHome");
    //  Implementation of 2) Logs:
    //  name = "Mar";
    //  tree.addDirectory(name, "/Logs LogsHome");

    // done
    //  2. Add a file
    //   2.1 Where? 1) PatientData 2)Logs
    //  Implementation of 1) PatientData:
    //  name = "ReportB.pdf";
    //  tree.addFile(name, "/PatientsData PatientsHome");
    //  tree.addFile(name, "/PatientsData PatientsHome"); // Does not add duplicate files

    // done
    //  Now implementing the "Search" functionality
    //  name = "ReportB.pdf";
    //  tree.search(name);

    // done
    //  Display Tree before Changing Tree:
    // cout << "\nPerfect Binary Tree (Level-order): " << endl;

    tree.MainMenu();
    // tree.display();

    // done
    //  Now implementing the "Mergea" functionality
    //  string source = "PatientA";
    //  string destination = "PatientB";
    //  tree.merge(source, destination);

    // done
    //  Now implementing the "Delete" functionality
    //  Menu:-
    //   Delete a file:
    //  string fileName = "ReportA.pdf";
    //  tree.deleteFile(fileName);

    // done
    //   Delete a directory:
    //  string directoryName = "PatientA";
    //  tree.deleteDirectory(directoryName);

    // done
    //  Now implementing "Rename" functionality
    //  string oldName = "PatientA";
    //  string newName = "PatientD";
    //  tree.renameDirectory(oldName, newName);

    // done
    //  Now implementing "Copy" functionality
    //  string source = "ReportA.pdf";
    //  string destination = "PatientC";
    //  tree.copy(source, destination);

    // done
    //  Now implementing "Move" functionality
    //  string source = "ReportC.pdf";
    //  string destination = "PatientA";
    //  tree.move(source, destination);

    // Import and Export functionality
    // string fileName = "tree.txt";
    // tree.exportToFile(fileName);
    // cout << "\nThis is the display from file "<< fileName << ":" << endl;
    // tree.importAndDisplay(fileName);

    return 0;
}