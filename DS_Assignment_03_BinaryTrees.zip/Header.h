// AhmedAyyan_22i-2422_SE-G
#include <iostream>
#include <queue>
#include <sstream>
#include <fstream>
#include <conio.h>

using namespace std;

// Node structure for the binary tree
struct TreeNode
{
    string name;
    string path;
    string type;
    TreeNode *left;
    TreeNode *right;
    TreeNode *parent;

    TreeNode(string n, string p, string t)
        : name(n), path(p), type(t), left(nullptr), right(nullptr), parent(nullptr) {}
};

// Tree class
class Tree
{
private:
    TreeNode *root;
    TreeNode *tempDirectory; // Made for the changeDirectory function in Merge function, and for search funtion, and also helps in delete function

public:
    // Menu start
    void MainMenu()
    {
        // For clearing console screen
        system("cls");
        int option;
        cout << "\n<===================== Main Menu =====================>" << endl
             << "\nPress '1' to display 'Level Order Tree" << endl
             << "Press '2' to continue to 'Add Directory'" << endl
             << "Press '3' to continue to 'Add File'" << endl
             << "Press '4' to continue to 'Search" << endl
             << "Press '5' to continue to 'Delete'" << endl
             << "Press '6' to continue to 'Rename'" << endl
             << "Press '7' to continue to 'Copy/Move'" << endl
             << "Press '8' to continue to 'Merge'" << endl
             << "Press '9' to continue to 'Import/Export'" << endl
             << "Press '0' to 'Exit'" << endl;

        cin >> option;

        while (!(option == 1 || option == 2 || option == 3 || option == 4 || option == 5 || option == 6 || option == 7 || option == 8 || option == 9 || option == 0))
        {
            cin >> option;
        }
        string name;
        string oldName;
        string newName;
        string source;
        string destination;

        switch (option)
        {
        case 1:
            // Level order tree
            system("cls");
            display();
            Continue();
            break;

        case 2:
            // Add Directory
            system("cls");
            AddDirectoryMenu();
            break;

        case 3:
            // Add File
            system("cls");
            AddFileMenu();
            break;

        case 4:
            // Search
            system("cls");
            cout << "Enter Name  :  ";
            cin >> name;
            search(name);
            Continue();
            break;

        case 5:
            // Delete
            system("cls");
            DeleteMenu();
            break;

        case 6:
            // Rename
            system("cls");
            cout << "Enter Old Name  :  ";
            cin >> oldName;
            cout << "Enter New Name  :  ";
            cin >> newName;
            renameDirectory(oldName, newName);
            Continue();
            break;

        case 7:
            // Copy/Move
            system("cls");
            CopyMoveMenu();
            break;

        case 8:
            // Merging
            system("cls");
            cout << "Enter Source  :  ";
            cin >> source;
            cout << endl;
            cout << "Enter Destination  :  ";
            cin >> destination;
            merge(source, destination);
            Continue();
            break;

        case 9:
            // Import/Export
            system("cls");
            ImportExportMenu();
            break;

        case 0:
            // For clearing console screen
            system("cls");
            exit(0);
            break;
        }
        MainMenu();
    }

    void Continue()
    {
        cout << "\nPress any key to continue.." << endl;
        getch();
    }

    void AddDirectoryMenu()
    {
        // For clearing console screen
        system("cls");
        int option;
        cout << "\n<===================== AddDirectoryMenu =====================>" << endl
             << "\nPress '1' to add to 'Patient Data'" << endl
             << "Press '2' to add to 'Log'" << endl
             << "Press '3' to 'go back'" << endl;

        cin >> option;

        while (!(option == 1 || option == 2 || option == 3))
        {
            cin >> option;
        }

        string name; // Declare the variable once here
        switch (option)
        {
        case 1:
            // For clearing console screen
            system("cls");
            cout << "Enter name: ";
            cin >> name;
            addDirectory(name, "/PatientsData PatientsHome");
            Continue();
            break;

        case 2:
            // For clearing console screen
            system("cls");
            cout << "Enter name: ";
            cin >> name;
            addDirectory(name, "/Logs LogsHome");
            Continue();
            break;

        case 3:
            // For clearing console screen
            system("cls");
            return;
        }
        AddDirectoryMenu();
    }

    void AddFileMenu()
    {
        // For clearing console screen
        system("cls");
        int option;
        cout << "\n<===================== AddFileMenu =====================>" << endl
             << "\nPress '1' to add to 'Patient Data'" << endl
             << "Press '2' to add to 'Log'" << endl
             << "Press '3' to 'go back'" << endl;

        cin >> option;

        while (!(option == 1 || option == 2 || option == 3))
        {
            cin >> option;
        }

        string name; // Declare the variable once here
        switch (option)
        {
        case 1:
            // For clearing console screen
            system("cls");
            cout << "Enter name: ";
            cin >> name;
            addFile(name, "/PatientsData PatientsHome");
            Continue();
            break;

        case 2:
            // For clearing console screen
            system("cls");
            cout << "Enter name: ";
            cin >> name;
            addFile(name, "/Logs LogsHome");
            Continue();
            break;

        case 3:
            // For clearing console screen
            system("cls");
            return;
        }
        AddFileMenu();
    }

    void DeleteMenu()
    {
        // For clearing console screen
        system("cls");
        int option;
        cout << "\n<===================== DeleteMenu =====================>" << endl
             << "\nPress '1' to Delete a 'Directory'" << endl
             << "Press '2' to Delete to 'File'" << endl
             << "Press '3' to 'go back'" << endl;

        cin >> option;

        while (!(option == 1 || option == 2 || option == 3))
        {
            cin >> option;
        }

        string name; // Declare the variable once here
        switch (option)
        {
        case 1:
            // Search a directory
            system("cls");
            cout << "Enter Directory Name  :  ";
            cin >> name;
            deleteDirectory(name);
            Continue();
            break;

        case 2:
            // Search a file
            system("cls");
            cout << "Enter File Name  :  ";
            cin >> name;
            deleteFile(name);
            Continue();
            break;

        case 3:
            // For clearing console screen
            system("cls");
            return;
        }
        DeleteMenu();
    }

    void CopyMoveMenu()
    {
        // For clearing console screen
        system("cls");
        int option;
        cout << "\n<===================== Copy/Move =====================>" << endl
             << "\nPress '1' Copy" << endl
             << "Press '2' to Move" << endl
             << "Press '3' to 'go back'" << endl;

        cin >> option;

        while (!(option == 1 || option == 2 || option == 3))
        {
            cin >> option;
        }

        string source;
        string destination;
        switch (option)
        {
        case 1:
            // copy
            system("cls");
            cout << "Enter Source  :  ";
            cin >> source;
            cout << endl;
            cout << "Enter Destination  :  ";
            cin >> destination;
            copy(source, destination);
            Continue();
            break;

        case 2:
            // Move a file
            system("cls");
            cout << "Enter Source  :  ";
            cin >> source;
            cout << endl;
            cout << "Enter Destination  :  ";
            cin >> destination;
            move(source, destination);
            Continue();
            break;

        case 3:
            // For clearing console screen
            system("cls");
            return;
        }
        CopyMoveMenu();
    }

    void ImportExportMenu()
    {
        // For clearing console screen
        system("cls");
        int option;
        cout << "\n<===================== Import/Export =====================>" << endl
             << "\nPress '1' Import" << endl
             << "Press '2' to Export" << endl
             << "Press '3' to 'go back'" << endl;

        cin >> option;

        while (!(option == 1 || option == 2 || option == 3))
        {
            cin >> option;
        }

        string fileName;
        switch (option)
        {
        case 1:
            // import
            system("cls");
            cout << "Enter File Name: ";
            cin >> fileName;
            importAndDisplay(fileName);
            Continue();
            break;

        case 2:
            // export
            system("cls");
            cout << "Enter File Name: ";
            cin >> fileName;
            exportToFile(fileName);
            Continue();
            break;

        case 3:
            system("cls");
            return;
        }
        ImportExportMenu();
    }
    // menu finish

    Tree() : root(NULL), tempDirectory(NULL) {}

    // Function to insert a node in the perfect binary tree
    void insertNode(TreeNode *&root, TreeNode *newNode)
    {
        if (!root)
        {
            // If the tree is empty, make the new node the root
            root = newNode;
            return;
        }

        queue<TreeNode *> q;
        q.push(root);

        while (!q.empty())
        {
            TreeNode *current = q.front();
            q.pop();

            if (current->left == nullptr)
            {
                // If the left child is empty, insert the new node there
                current->left = newNode;
                newNode->parent = current;
                break; // Node inserted, exit the loop
            }
            else if (current->right == nullptr)
            {
                // If the right child is empty, insert the new node there
                current->right = newNode;
                newNode->parent = current;
                break; // Node inserted, exit the loop
            }
            else
            {
                // If both children are present, push them to the queue for further exploration
                q.push(current->left);
                q.push(current->right);
            }
        }
    }

    // Function to display the perfect binary tree in level-order
    void display(TreeNode *currentNode)
    {
        if (!currentNode)
            return;

        queue<TreeNode *> q;
        q.push(currentNode);

        while (!q.empty())
        {
            TreeNode *current = q.front();
            q.pop();

            calculatePath(current);
            cout << current->path << endl;

            if (current->left)
                q.push(current->left);
            if (current->right)
                q.push(current->right);
        }
    }

    // Function to insert a node in the perfect binary tree
    void insertNode(TreeNode *newNode)
    {
        insertNode(root, newNode);
    }

    // Function to display the perfect binary tree in level-order
    void display()
    {
        display(root);
    }

    // Function to calculate and assign the path of a node from the root
    void calculatePath(TreeNode *node)
    {
        if (!node)
            return;

        string path = node->name; // Start with the node's name

        TreeNode *current = node->parent;

        while (current)
        {
            if (current->name == "/")
            {
                path = current->name + path; // Add the parent's name to the path
                current = current->parent;   // Move to the parent node
                break;
            }
            path = current->name + " " + path; // Add the parent's name to the path
            current = current->parent;         // Move to the parent node
        }

        node->path = path;
    }
    // Funtion to check for duplicates
    bool checkDuplicates(TreeNode *currentNode, string name)
    {
        if (currentNode == NULL)
        {
            return false;
        }
        if (currentNode->name == name)
        {
            return true;
        }
        bool left = checkDuplicates(currentNode->left, name);
        bool right = checkDuplicates(currentNode->right, name);
        return left || right;
    }
    // Simple renaming function
    void renameDirectory(string oldName, string newName)
    {
        bool found = search(root, oldName);
        if (found)
        {
            tempDirectory->name = newName;
            cout << "\nDirectory Renamed!" << endl;
        }
        else
        {
            cout << "\nDirectory Not Found!" << endl;
        }
    }
    // Function to add a directory based on the specified conditions
    void addDirectory(string name, string path)
    {
        if (checkDuplicates(root, name))
        {
            cout << "\nCannot add duplicate. File already exists" << endl;
            return;
        }
        if (path == "/PatientsData PatientsHome")
        {
            TreeNode *newNode = new TreeNode(name, "", "Directory");
            TreeNode *currentNode = root;
            currentNode = currentNode->left->left;
            bool check = true;
            while (check)
            {
                if (currentNode->left == NULL)
                {
                    newNode->parent = currentNode;
                    insertDirectory(currentNode->left, newNode);
                    calculatePath(newNode);
                    check = false;
                }
                else
                {
                    currentNode = currentNode->left;
                }
            }
        }
        else if (path == "/Logs LogsHome")
        {
            TreeNode *newNode = new TreeNode(name, "", "Directory");
            TreeNode *currentNode = root;
            currentNode = currentNode->right->left;
            bool check = true;
            while (check)
            {
                if (currentNode->left == NULL)
                {
                    newNode->parent = currentNode;
                    insertDirectory(currentNode->left, newNode);
                    calculatePath(newNode);
                    check = false;
                }
                else
                {
                    currentNode = currentNode->left;
                }
            }
        }
        else
        {
            cout << "\nInvalid path" << endl;
        }
    }
    void insertDirectory(TreeNode *&destination, TreeNode *newNode)
    {
        destination = newNode;
    }
    void deleteDirectory(string name)
    {
        bool found = search(root, name);
        if (found)
        {
            TreeNode *currentNode = root;
            TreeNode *tempNode = root;
            changeDirectory(currentNode, name);
            currentNode = tempDirectory->parent;
            tempNode = tempDirectory;
            if (currentNode->left->right != NULL)
            {
                cout << "\nDirectory is not empty. Do you want to merge with another directory?(Y/N)" << endl;
                char choice;
                cin >> choice;
                while (choice != 'Y' && choice != 'y' && choice != 'N' && choice != 'n')
                {
                    cout << "Invalid choice. Enter again: ";
                    cin >> choice;
                }
                if (choice == 'Y' || choice == 'y')
                {
                    string source;
                    cout << "Enter the name of the directory you want to merge with: ";
                    cin >> source;
                    merge(name, source);
                    return;
                }
                else
                {
                    return;
                }
            }
            currentNode->left = currentNode->left->left;
            if (currentNode->left != NULL)
            {
                currentNode->left->parent = currentNode;
            }
            tempNode = NULL;
            delete tempNode;
            cout << "\nDirectory Deleted!" << endl;
        }
        else
        {
            cout << "\nDirectory Not Found!" << endl;
        }
    }
    // Function to add a file based on the specified conditions
    void addFile(string name, string path)
    {
        if (checkDuplicates(root, name))
        {
            cout << "\nCannot add duplicate. File already exists" << endl;
            return;
        }
        if (path == "/PatientsData PatientsHome")
        {
            TreeNode *newNode = new TreeNode(name, "", "File");
            TreeNode *currentNode = root;
            currentNode = currentNode->left->left->left;
            bool check = true;
            while (check)
            {
                if (currentNode->right == NULL)
                {
                    newNode->parent = currentNode;
                    insertFile(currentNode->right, newNode);
                    calculatePath(newNode);
                    check = false;
                }
                else
                {
                    if (currentNode->left == NULL)
                    {
                        // mkdir newDir
                        string name;
                        cout << "\nNo empty directory found! Enter the name of the new directory: ";
                        cin >> name;
                        TreeNode *newDir = new TreeNode(name, "", "Directory");
                        newDir->parent = currentNode;
                        insertDirectory(currentNode->left, newDir);
                        calculatePath(newDir);
                    }
                    currentNode = currentNode->left;
                }
            }
        }
        else if (path == "/Logs LogsHome")
        {
            TreeNode *newNode = new TreeNode(name, "", "File");
            TreeNode *currentNode = root;
            currentNode = currentNode->right->left->left;
            bool check = true;
            while (check)
            {
                if (currentNode->right == NULL)
                {
                    newNode->parent = currentNode;
                    insertFile(currentNode->right, newNode);
                    calculatePath(newNode);
                    check = false;
                }
                else
                {
                    if (currentNode->left == NULL)
                    {
                        string name;
                        cout << "\nNo empty directory found! Enter the name of the new directory: " << endl;
                        cin >> name;
                        TreeNode *newDir = new TreeNode(name, "", "Directory");
                        newDir->parent = currentNode;
                        insertDirectory(currentNode->left, newDir);
                        calculatePath(newDir);
                    }
                    currentNode = currentNode->left;
                }
            }
        }
        else
        {
            cout << "\nInvalid path" << endl;
        }
    }
    void insertFile(TreeNode *&destination, TreeNode *newNode)
    {
        destination = newNode;
    }
    void deleteFile(string name)
    {
        bool found = search(root, name);
        if (found)
        {
            TreeNode *currentNode = root;
            currentNode = tempDirectory->parent;
            currentNode->right = NULL;
            delete currentNode->right;
            tempDirectory = root;
            cout << "\nFile Deleted!" << endl;
        }
        else
        {
            cout << "\nFile Not Found!" << endl;
        }
    }
    void search(string name)
    {
        bool found = search(root, name);
        if (found)
        {
            cout << "\nFile Found: " << tempDirectory->path << endl;
        }
        else
        {
            cout << "\nFile Not Found!" << endl;
        }
    }
    bool search(TreeNode *&currentNode, string name)
    {
        if (currentNode == NULL)
        {
            return false;
        }
        if (currentNode->name == name)
        {
            tempDirectory = currentNode;
            return true;
        }
        bool left = search(currentNode->left, name);
        bool right = search(currentNode->right, name);
        return left || right;
    }

    // Function to merge two directories
    void merge(string source, string destination)
    {

        TreeNode *sourceNode = root;
        bool sourceFound = changeDirectory(sourceNode, source);
        sourceNode = tempDirectory;
        tempDirectory = root;
        TreeNode *destinationNode = root;
        bool destinationFound = changeDirectory(destinationNode, destination);
        destinationNode = tempDirectory;
        tempDirectory = root;

        if (!(sourceFound && destinationFound))
        {
            cout << "\nInvalid source or destination directory." << endl;
            return;
        }

        if (destinationNode->right != NULL)
        {
            cout << "Destination directory is full. Replace or Abort (R/A)" << endl;
            char choice;
            cin >> choice;
            while (choice != 'R' && choice != 'A' && choice != 'a' && choice != 'r')
            {
                cout << "Invalid choice. Enter again: ";
                cin >> choice;
            }
            if (choice == 'A' || choice == 'a')
            {
                return;
            }
        }
        destinationNode->right = sourceNode->right;
        if (sourceNode->right != NULL)
        {
            sourceNode->right->parent = destinationNode;
        }
        sourceNode->right = nullptr;
        sourceNode->parent->left = sourceNode->left;
        if (sourceNode->left != NULL)
        {
            sourceNode->left->parent = sourceNode->parent;
        }
        delete sourceNode;

        cout << "Do you want to rename " << destination << "? (Y/N)" << endl;
        char choice;
        cin >> choice;
        while (choice != 'Y' && choice != 'y' && choice != 'N' && choice != 'n')
        {
            cout << "Invalid choice. Enter again: ";
            cin >> choice;
        }
        if (choice == 'Y' || choice == 'y')
        {
            string newName;
            cout << "Enter new name: ";
            cin >> newName;
            destinationNode->name = newName;
        }
        cout << "\nMerged " << source << " into " << destination << endl;
    }
    // Copy function
    void copy(string source, string destination)
    {
        TreeNode *sourceNode = root;
        bool sourceFound = changeDirectory(sourceNode, source);
        sourceNode = tempDirectory;
        tempDirectory = root;
        TreeNode *destinationNode = root;
        bool destinationFound = changeDirectory(destinationNode, destination);
        destinationNode = tempDirectory;
        tempDirectory = root;

        if (!(sourceFound && destinationFound))
        {
            cout << "\nInvalid source or destination directory." << endl;
            return;
        }

        if (destinationNode->right != NULL)
        {
            cout << "\nDestination directory is full. File cannot be copied!" << endl;
            return;
        }
        TreeNode *newNode = new TreeNode(sourceNode->name, "", "File");
        destinationNode->right = newNode;
        newNode->parent = destinationNode;

        cout << "\nCopied " << source << " into " << destination << endl;
    }
    // Move function
    void move(string source, string destination)
    {
        TreeNode *sourceNode = root;
        bool sourceFound = changeDirectory(sourceNode, source);
        sourceNode = tempDirectory;
        tempDirectory = root;
        TreeNode *destinationNode = root;
        bool destinationFound = changeDirectory(destinationNode, destination);
        destinationNode = tempDirectory;
        tempDirectory = root;

        if (!(sourceFound && destinationFound))
        {
            cout << "\nInvalid source or destination directory." << endl;
            return;
        }

        if (destinationNode->right != NULL)
        {
            cout << "\nDestination directory is full. File cannot be moved!" << endl;
            return;
        }
        destinationNode->right = sourceNode;
        sourceNode->parent->right = NULL;
        TreeNode *sourceParent = sourceNode->parent;
        sourceNode->parent = destinationNode;

        if (sourceParent->left == NULL && sourceParent->right == NULL)
        {
            cout << "\nDirectory is empty. Delete directory?(Y/N)" << endl;
            char choice;
            cin >> choice;
            while (choice != 'Y' && choice != 'y' && choice != 'N' && choice != 'n')
            {
                cout << "\nInvalid choice. Enter again: ";
                cin >> choice;
            }
            if (choice == 'Y' || choice == 'y')
            {
                sourceParent->parent->left = NULL;
                delete sourceParent;
            }
        }

        cout << "\nMoved " << source << " into " << destination << endl;
    }
    bool changeDirectory(TreeNode *&currentNode, string name)
    {
        if (currentNode == NULL)
        {
            return false;
        }
        if (currentNode->name == name)
        {
            tempDirectory = currentNode;
            return true;
        }
        bool left = changeDirectory(currentNode->left, name);
        bool right = changeDirectory(currentNode->right, name);

        return left || right;
    }

    // Function to export paths to a file
    void exportToFile(string filename)
    {
        exportToFile(root, filename);
    }
    void exportToFile(TreeNode *currentNode, string filename)
    {
        ofstream outFile(filename);

        if (!outFile.is_open())
        {
            cout << "\nError: Unable to open file for export." << endl;
            return;
        }

        queue<TreeNode *> q;
        q.push(currentNode);

        while (!q.empty())
        {
            TreeNode *current = q.front();
            q.pop();

            outFile << current->path << endl;

            if (current->left)
                q.push(current->left);
            if (current->right)
                q.push(current->right);
        }

        outFile.close();

        cout << "\nExported tree paths to file: " << filename << endl;
    }

    // Function to import paths from a file and display them
    void importAndDisplay(string filename)
    {
        ifstream inFile(filename);

        if (!inFile.is_open())
        {
            cerr << "\nError: Unable to open file for import." << endl;
            return;
        }

        string line;
        while (getline(inFile, line))
        {
            cout << line << endl;
        }

        inFile.close();
    }
};