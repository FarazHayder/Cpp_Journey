// Faraz_Hayder_22i2687
#include "header.h"
//  Default Constructor
TreeNode::TreeNode()
{
    name = "";
    path = "";
    type = "";
}
// Parameterized Constructor
TreeNode::TreeNode(string name, string path, string type)
{
    this->name = name;
    this->path = path;
    this->type = type;
}
// Default Constructor
Tree::Tree()
{
    root = NULL;
    currDir = root;
}
// Parametrized Constructor
Tree::Tree(string name, string path, string type)
{
    root = new TreeNode(name, path, type);
    currDir = root;
}
// Command Line Interface
void Tree::CLI()
{
    string input = "";
    while (true)
    {
        cin.ignore(-1); // For ignoring the previous input
        cout << "C:" << currDir->path << "> ";
        getline(cin, input);

        if ((input.find("cd") != string::npos) || (input.find("CD") != string::npos))
        {
            changeCurrDir(input);
        }
        else if ((input.find("type nul >") != string::npos) || (input.find("type nul >") != string::npos) || (input.find("type nul>") != string::npos) || (input.find("type nul>") != string::npos) ||
                 (input.find("TYPE NUL >") != string::npos) || (input.find("TYPE NUL >") != string::npos) || (input.find("TYPE NUL>") != string::npos) || (input.find("TYPE NUL>") != string::npos) ||
                 (input.find("echo. >") != string::npos) || (input.find("echo. >") != string::npos) || (input.find("echo.>") != string::npos) || (input.find("echo.>") != string::npos) || (input.find("echo . >") != string::npos) || (input.find("echo . >") != string::npos) || (input.find("echo .>") != string::npos) || (input.find("echo .>") != string::npos) ||
                 (input.find("ECHO. >") != string::npos) || (input.find("ECHO. >") != string::npos) || (input.find("ECHO.>") != string::npos) || (input.find("ECHO.>") != string::npos) || (input.find("ECHO . >") != string::npos) || (input.find("ECHO . >") != string::npos) || (input.find("ECHO .>") != string::npos) || (input.find("ECHO .>") != string::npos))
        {
            makeFile(input);
        }
        else if ((input.find("mkdir ") != string::npos) ||
                 (input.find("MKDIR ") != string::npos))
        {
            string dirName = input.substr(6);
            string targetDir = currDir->path;
            makeDir(dirName, targetDir);
        }
        else if ((input.find("del ") != string::npos) ||
                 (input.find("DEL ") != string::npos))
        {
            deleteFile(input);
        }
        else if ((input.find("rmdir ") != string::npos) ||
                 (input.find("RMDIR ") != string::npos))
        {
            deleteDir(input);
        }
        else if ((input.find("ren ") != string::npos) ||
                 (input.find("REN ") != string::npos))
        {
            string oldName = input.substr(4, input.find_last_of(" ") - 4);
            string newName = input.substr(input.find_last_of(" ") + 1);
            rename(oldName, newName);
        }
        else if ((input.find("rename ") != string::npos) ||
                 (input.find("RENAME ") != string::npos))
        {
            string oldName = input.substr(7, input.find_last_of(" ") - 7);
            string newName = input.substr(input.find_last_of(" ") + 1);
            rename(oldName, newName);
        }
        else if (input.find("dir /s /b ") != string::npos)
        {
            string targetDir = input.substr(10);
            search(currDir, targetDir);
        }
        else if ((input.find("merge ") != string::npos) ||
                 (input.find("MERGE ") != string::npos))
        {
            string source = input.substr(6, input.find_last_of(" ") - 6);
            string destination = input.substr(input.find_last_of(" ") + 1);
            merge(source, destination);
        }
        else if ((input.find("move ") != string::npos) ||
                 (input.find("MOVE ") != string::npos))
        {
            string source = input.substr(5, input.find_last_of(" ") - 5);
            string destination = input.substr(input.find_last_of(" ") + 1);
            move(source, destination);
        }
        else if ((input.find("copy ") != string::npos) ||
                 (input.find("COPY ") != string::npos))
        {
            string source = input.substr(5, input.find_last_of(" ") - 5);
            string destination = input.substr(input.find_last_of(" ") + 1);
            copy(source, destination);
        }
        else if (input.find("save ") != string::npos)
        {
            string filename = input.substr(5);
            save(filename);
        }
        else if (input.find("load ") != string::npos)
        {
            string filename = input.substr(5);
            load(filename);
        }
        else if ((input.find("tree /F") != string::npos) || (input.find("tree /f") != string::npos) ||
                 (input.find("TREE /F") != string::npos) || (input.find("TREE /f") != string::npos))
        {
            displayTree(currDir, 0);
        }
        else if (input.find("dir /s /b") != string::npos) // Displays paths of each node in level-by-level order
        {
            levelOrderTraversal(currDir);
        }
        else if (input.find("help") != string::npos)
        {
            help();
        }
        else if (input.find("cls") != string::npos)
        {
            system("cls"); // For clearing console screen
        }
        else if (input.find("exit") != string::npos)
        {
            exit(0); // For exiting the program
        }
        else if (input == "")
        {
            continue;
        }
        else
        {
            input = input.substr(0, input.find_first_of(" "));
            cout << "'" << input << "' is not recognized as an internal or external command, operable program or batch file." << endl;
        }
        cout << endl;
    }
}

void Tree::help()
{
    cout << endl
         << "TYPE NUL >  Create an empty file\n"
         << "ECHO. >     Create an empty file\n"
         << "DEL         Delete file\n"
         << "DEL /P      Prompt for confirmation before deleting each file\n"
         << "MKDIR       Create a directory\n"
         << "RMDIR       Remove a directory\n"
         << "CD          Change the current directory\n"
         << "CD ..       Change the current directory to the parent folder\n"
         << "REN         Rename a file or directory\n"
         << "RENAME      Rename a file or directory\n"
         << "MOVE        Move files from one folder to another\n"
         << "COPY        Copy file to another location\n"
         << "MERGE       Merge Folders\n"
         << "TREE /F     Display a tree of a drive or path\n"
         << "DIR /S /B   Display the full path of files in all subdirectories\n"
         << "SAVE        Save the current tree structure to a file\n"
         << "LOAD        Load a file and display its content\n"
         << "CLS         Clear the screen\n"
         << "EXIT        Quit the CMD shell\n";
}
bool Tree::targetDestinationExists(TreeNode *currDirOrFile, string targetDirOrFile, string type)
{
    if (currDirOrFile == NULL)
    {
        return false;
    }
    if ((currDirOrFile->name == targetDirOrFile && currDirOrFile->type == type) || (currDirOrFile->path == "\\" + targetDirOrFile && currDirOrFile->type == type) || (currDirOrFile->path == targetDirOrFile && currDirOrFile->type == type))
    {
        return true;
    }

    for (int i = 0; i < currDirOrFile->children.size(); ++i)
    {
        TreeNode *child = currDirOrFile->children[i];
        if (targetDestinationExists(child, targetDirOrFile, type))
        {
            return true;
        }
    }
    return false;
}
bool Tree::targetDestinationExistsAtSameLevel(TreeNode *currDirOrFile, string targetDirOrFile, string type)
{
    for (int i = 0; i < currDirOrFile->children.size(); i++)
    {
        if ((currDirOrFile->children[i]->name == targetDirOrFile && currDirOrFile->children[i]->type == type) || (currDirOrFile->children[i]->path == "\\" + targetDirOrFile && currDirOrFile->children[i]->type == type) || (currDirOrFile->children[i]->path == targetDirOrFile && currDirOrFile->children[i]->type == type))
        {
            return true;
        }
    }
    return false;
}
bool Tree::changeFile(TreeNode *&currFile, string targetDir, bool sameLevel)
{
    if (sameLevel)
    {
        for (int i = 0; i < currFile->children.size(); i++)
        {
            if (currFile->children[i]->name == targetDir && currFile->children[i]->type == "file")
            {
                currFile = currFile->children[i];
                return true;
            }
        }
        return false;
    }
    if (currFile == NULL)
    {
        return false;
    }
    if ((currFile->name == targetDir && currFile->type == "file") || (currFile->path == "\\" + targetDir && currFile->type == "file") || (currFile->path == targetDir && currFile->type == "file"))
    {
        return true;
    }
    for (int i = 0; i < currFile->children.size(); ++i)
    {
        TreeNode *child = currFile->children[i];
        if (changeFile(child, targetDir, false))
        {
            currFile = child;
            return true;
        }
    }
    return false;
}
bool Tree::changeDir(TreeNode *&currDir, string targetDir, bool sameLevel)
{
    if (sameLevel)
    {
        for (int i = 0; i < currDir->children.size(); i++)
        {
            if (currDir->children[i]->name == targetDir && currDir->children[i]->type == "dir")
            {
                currDir = currDir->children[i];
                return true;
            }
        }
        return false;
    }
    if (currDir == NULL)
    {
        return false;
    }
    if ((currDir->name == targetDir && currDir->type == "dir") || (currDir->path == "\\" + targetDir && currDir->type == "dir") || (currDir->path == targetDir && currDir->type == "dir"))
    {
        return true;
    }
    for (int i = 0; i < currDir->children.size(); ++i)
    {
        TreeNode *child = currDir->children[i];
        if (changeDir(child, targetDir, false))
        {
            currDir = child;
            return true;
        }
    }
    return false;
}
bool Tree::checkDuplicates(TreeNode *currDir, string name, string type)
{
    for (int i = 0; i < currDir->children.size(); i++)
    {
        if ((currDir->children[i]->name == name && currDir->children[i]->type == type) || (currDir->children[i]->path == "\\" + name && currDir->children[i]->type == type) || (currDir->children[i]->path == name && currDir->children[i]->type == type))
        {
            cout << "A subdirectory or file " << name << " already exists." << endl;
            return true;
        }
    }
    return false;
}
//  Function to perform level-order traversal
void Tree::levelOrderTraversal(TreeNode *root)
{
    if (!root)
    {
        return;
    }

    queue<TreeNode *> q;
    q.push(root);

    while (!q.empty())
    {
        int levelSize = q.size();

        for (int i = 0; i < levelSize; ++i)
        {
            TreeNode *current = q.front();
            q.pop();

            cout << current->path << endl;

            for (TreeNode *child : current->children)
            {
                q.push(child);
            }
        }
        // cout << endl; // Skipping line before next level for better visualisation
    }
}
// Function to display the tree in directory structure
void Tree::displayTree(TreeNode *currentNode, int level)
{
    if (currentNode != NULL)
    {
        for (int i = 0; i < level; ++i)
        {
            cout << "     "; // 5 spaces for each level
        }

        if (level != 0)
        {
            cout << currentNode->name;
            if (currentNode->type == "dir")
            {
                cout << "<DIR>";
            }
            cout << '\n';
        }

        for (int i = 0; i < currentNode->children.size(); ++i)
        {
            displayTree(currentNode->children[i], level + 1);
        }
    }
}
void Tree::search(TreeNode *currentNode, string targetDir)
{
    if (currentNode != NULL)
    {
        if (currentNode->name == targetDir)
        {
            cout << currentNode->path << endl;
        }
        for (int i = 0; i < currentNode->children.size(); ++i)
        {
            search(currentNode->children[i], targetDir);
        }
    }
}
void Tree::writeTreeToFile(TreeNode *currentNode, ofstream &file, int level)
{
    if (currentNode != nullptr)
    {
        for (int i = 0; i < level; ++i)
        {
            file << "     ";
        }

        if (level != 0)
        {
            file << currentNode->name;
            if (currentNode->type == "dir")
            {
                file << "<DIR>";
            }
            file << '\n';
        }

        for (int i = 0; i < currentNode->children.size(); ++i)
        {
            writeTreeToFile(currentNode->children[i], file, level + 1);
        }
    }
}
void Tree::readTreeFromFileAndDisplay(ifstream &file)
{
    string line;
    while (getline(file, line))
    {
        cout << line << endl;
    }
}
void Tree::updatePath(TreeNode *currDir)
{
    if (currDir == NULL)
    {
        return;
    }
    if (currDir->path == root->path)
    {
        for (int i = 0; i < currDir->children.size(); i++)
        {
            currDir->children[i]->path = currDir->path + currDir->children[i]->name;
            updatePath(currDir->children[i]);
        }
    }
    else
    {
        for (int i = 0; i < currDir->children.size(); i++)
        {
            currDir->children[i]->path = currDir->path + "\\" + currDir->children[i]->name;
            updatePath(currDir->children[i]);
        }
    }
}
void Tree::insertNode(TreeNode *currNode, TreeNode *newNode)
{
    currNode->children.push_back(newNode);
    newNode->parent = currNode;
}
void Tree::deleteNode(TreeNode *currDirOrFile, string targetDirOrFile, string type)
{
    for (int i = 0; i < currDirOrFile->children.size(); i++)
    {
        if (currDirOrFile->children[i]->name == targetDirOrFile && currDirOrFile->children[i]->type == type)
        {
            currDirOrFile->children.erase(begin(currDirOrFile->children) + i);
            return;
        }
    }
}
void Tree::deleteNode(TreeNode *currDirOrFile)
{
    string toDeleteName = currDirOrFile->name;
    string toDeleteType = currDirOrFile->type;
    currDirOrFile = currDirOrFile->parent;
    for (int i = 0; i < currDirOrFile->children.size(); i++)
    {
        if (currDirOrFile->children[i]->name == toDeleteName && currDirOrFile->children[i]->type == toDeleteType)
        {
            currDirOrFile->children.erase(begin(currDirOrFile->children) + i);
            return;
        }
    }
}
void Tree::rename(string oldName, string newName)
{
    if (oldName.empty() || newName.empty())
    {
        cout << "The syntax of the command is incorrect." << endl;
    }
    else if (targetDestinationExistsAtSameLevel(currDir, oldName, "file") || targetDestinationExistsAtSameLevel(currDir, oldName, "dir"))
    {
        if (checkDuplicates(currDir, newName, "file") || checkDuplicates(currDir, newName, "dir"))
        {
            return;
        }
        for (int i = 0; i < currDir->children.size(); i++)
        {
            if (currDir->children[i]->name == oldName)
            {
                currDir->children[i]->name = newName;
                updatePath(currDir);
                return;
            }
        }
    }
    else
    {
        cout << "The system cannot find the file specified." << endl;
    }
}
void Tree::merge(string source, string destination)
{
    if (source.empty() || destination.empty())
    {
        cout << "The syntax of the command is incorrect." << endl;
    }
    bool sourceExists = false;
    bool destinationExists = false;
    bool sameLevelSource = false;
    bool sameLevelDestination = false;
    if (source.find("\\") != string::npos)
    {
        sourceExists = targetDestinationExists(currDir, source, "dir");
    }
    else
    {
        sourceExists = targetDestinationExistsAtSameLevel(currDir, source, "dir");
        sameLevelSource = true;
    }
    if (destination.find("\\") != string::npos)
    {
        destinationExists = targetDestinationExists(root, destination, "dir");
    }
    else
    {
        destinationExists = targetDestinationExistsAtSameLevel(currDir, destination, "dir");
        sameLevelDestination = true;
    }
    if (sourceExists && destinationExists)
    {
        TreeNode *sourceDir = currDir;
        TreeNode *destinationDir = currDir;
        changeDir(sourceDir, source, sameLevelSource);
        changeDir(destinationDir, destination, sameLevelDestination);
        for (int i = 0; i < sourceDir->children.size(); i++)
        {
            if (checkDuplicates(destinationDir, sourceDir->children[i]->name, sourceDir->children[i]->type))
            {
                cout << "Do you want to replace it or skip? (R/S)" << endl;
                char ch;
                do
                {
                    cin >> ch;
                    if (ch == 'R' || ch == 'r')
                    {
                        deleteNode(destinationDir, sourceDir->children[i]->name, sourceDir->children[i]->type);
                    }
                    else if (ch == 'S' || ch == 's')
                    {
                        deleteNode(sourceDir, sourceDir->children[i]->name, sourceDir->children[i]->type);
                    }
                } while (ch != 'R' && ch != 'r' && ch != 'S' && ch != 's');
            }
            insertNode(destinationDir, sourceDir->children[i]);
        }
        sourceDir->children.clear();
        deleteNode(sourceDir);
        cout << "Do you want to rename the directory? (Y/N)" << endl;
        char ch;
        do
        {
            cin >> ch;
            if (ch == 'Y' || ch == 'y')
            {
                cout << "Enter new name: ";
                string newName;
                cin >> newName;
                rename(destinationDir->name, newName);
            }
            else if (ch == 'N' || ch == 'n')
            {
                updatePath(destinationDir);
                return;
            }
        } while (ch != 'Y' && ch != 'y' && ch != 'N' && ch != 'n');
    }
    else
    {
        cout << "The system cannot find the file specified." << endl;
    }
}
void Tree::move(string source, string destination)
{
    if (source == destination)
    {
        cout << "The syntax of the command is incorrect." << endl;
        return;
    }
    bool sourceExists = false;
    bool destinationExists = false;
    bool sameLevelSource = false;
    bool sameLevelDestination = false;
    bool sourceExistsAsFile = false;
    bool destinationExistsAsFile = false;
    if (source.find("\\") != string::npos)
    {
        sourceExists = targetDestinationExists(currDir, source, "dir") || targetDestinationExists(currDir, source, "file");
        if (targetDestinationExists(currDir, source, "file"))
        {
            sourceExistsAsFile = true;
        }
    }
    else
    {
        sourceExists = targetDestinationExistsAtSameLevel(currDir, source, "dir") || targetDestinationExistsAtSameLevel(currDir, source, "file");
        sameLevelSource = true;
        if (targetDestinationExists(currDir, source, "file"))
        {
            sourceExistsAsFile = true;
        }
    }
    if (destination.find("\\") != string::npos)
    {
        destinationExists = targetDestinationExists(root, destination, "dir") || targetDestinationExists(root, destination, "file");
        if (targetDestinationExists(root, destination, "file"))
        {
            destinationExistsAsFile = true;
        }
    }
    else
    {
        destinationExists = targetDestinationExistsAtSameLevel(currDir, destination, "dir") || targetDestinationExistsAtSameLevel(currDir, destination, "file");
        sameLevelDestination = true;
        if (targetDestinationExists(root, destination, "file"))
        {
            destinationExistsAsFile = true;
        }
    }
    if (sourceExists && destinationExists)
    {
        TreeNode *sourceDir = currDir;
        TreeNode *destinationDir = currDir;
        if (sourceExistsAsFile)
        {
            changeFile(sourceDir, source, sameLevelSource);
        }
        else
        {
            changeDir(sourceDir, source, sameLevelSource);
        }
        string dirToMove = sourceDir->name;
        string dirToMoveType = sourceDir->type;
        sourceDir = sourceDir->parent;
        if (destinationExistsAsFile)
        {
            changeFile(destinationDir, destination, sameLevelDestination);
        }
        else
        {
            changeDir(destinationDir, destination, sameLevelDestination);
        }
        for (int i = 0; i < sourceDir->children.size(); i++)
        {
            if (sourceDir->children[i]->name == dirToMove && sourceDir->children[i]->type == dirToMoveType)
            {
                if (checkDuplicates(destinationDir, sourceDir->children[i]->name, sourceDir->children[i]->type))
                {
                    cout << "Do you want to replace it or skip? (R/S)" << endl;
                    char ch;
                    do
                    {
                        cin >> ch;
                        if (ch == 'R' || ch == 'r')
                        {
                            deleteNode(destinationDir, sourceDir->children[i]->name, sourceDir->children[i]->type);
                        }
                        else if (ch == 'S' || ch == 's')
                        {
                            return;
                        }
                    } while (ch != 'R' && ch != 'r' && ch != 'S' && ch != 's');
                }
                insertNode(destinationDir, sourceDir->children[i]);
                sourceDir->children[i] = NULL;
                sourceDir->children.erase(begin(sourceDir->children) + i);
                updatePath(destinationDir);
                return;
            }
        }
        cout << "The system cannot find the file specified." << endl;
    }
    else
    {
        cout << "The system cannot find the file specified." << endl;
    }
}
void Tree::copy(string source, string destination)
{
    if (source == destination)
    {
        cout << "The syntax of the command is incorrect." << endl;
        return;
    }
    bool sourceExists = false;
    bool destinationExists = false;
    bool sameLevelSource = false;
    bool sameLevelDestination = false;
    bool sourceExistsAsFile = false;
    bool destinationExistsAsFile = false;
    if (source.find("\\") != string::npos)
    {
        sourceExists = targetDestinationExists(currDir, source, "dir") || targetDestinationExists(currDir, source, "file");
        if (targetDestinationExists(currDir, source, "file"))
        {
            sourceExistsAsFile = true;
        }
    }
    else
    {
        sourceExists = targetDestinationExistsAtSameLevel(currDir, source, "dir") || targetDestinationExistsAtSameLevel(currDir, source, "file");
        sameLevelSource = true;
        if (targetDestinationExists(currDir, source, "file"))
        {
            sourceExistsAsFile = true;
        }
    }
    if (destination.find("\\") != string::npos)
    {
        destinationExists = targetDestinationExists(root, destination, "dir") || targetDestinationExists(root, destination, "file");
        if (targetDestinationExists(root, destination, "file"))
        {
            destinationExistsAsFile = true;
        }
    }
    else
    {
        destinationExists = targetDestinationExistsAtSameLevel(currDir, destination, "dir") || targetDestinationExistsAtSameLevel(currDir, destination, "file");
        sameLevelDestination = true;
        if (targetDestinationExists(root, destination, "file"))
        {
            destinationExistsAsFile = true;
        }
    }
    if (sourceExists && destinationExists)
    {
        TreeNode *sourceDir = currDir;
        TreeNode *destinationDir = currDir;
        if (sourceExistsAsFile)
        {
            changeFile(sourceDir, source, sameLevelSource);
        }
        else
        {
            changeDir(sourceDir, source, sameLevelSource);
        }
        string dirToMove = sourceDir->name;
        string dirToMoveType = sourceDir->type;
        sourceDir = sourceDir->parent;
        if (destinationExistsAsFile)
        {
            changeFile(destinationDir, destination, sameLevelDestination);
        }
        else
        {
            changeDir(destinationDir, destination, sameLevelDestination);
        }
        for (int i = 0; i < sourceDir->children.size(); i++)
        {
            if (sourceDir->children[i]->name == dirToMove && sourceDir->children[i]->type == dirToMoveType)
            {
                if (checkDuplicates(destinationDir, sourceDir->children[i]->name, sourceDir->children[i]->type))
                {
                    cout << "Do you want to replace it or skip? (R/S)" << endl;
                    char ch;
                    do
                    {
                        cin >> ch;
                        if (ch == 'R' || ch == 'r')
                        {
                            deleteNode(destinationDir, sourceDir->children[i]->name, sourceDir->children[i]->type);
                        }
                        else if (ch == 'S' || ch == 's')
                        {
                            return;
                        }
                    } while (ch != 'R' && ch != 'r' && ch != 'S' && ch != 's');
                }
                TreeNode *newNode;
                if (destinationDir->path == root->path)
                {
                    newNode = new TreeNode(sourceDir->children[i]->name, destinationDir->path + sourceDir->children[i]->name, sourceDir->children[i]->type);
                }
                else
                {
                    newNode = new TreeNode(sourceDir->children[i]->name, destinationDir->path + "\\" + sourceDir->children[i]->name, sourceDir->children[i]->type);
                }
                insertNode(destinationDir, newNode);
                for (int j = 0; j < sourceDir->children[i]->children.size(); j++)
                {
                    copy(sourceDir->children[i]->children[j]->path, newNode->path);
                }
                return;
            }
        }
        cout << "The system cannot find the file specified." << endl;
    }
    else
    {
        cout << "The system cannot find the file specified." << endl;
    }
}
void Tree::makeDir(string dirName, string targetDir)
{
    if (dirName.empty())
    {
        cout << "The syntax of the command is incorrect." << endl;
        return;
    }
    if (dirName.find("\\") != string::npos)
    {
        targetDir = currDir->path + dirName.substr(0, dirName.find_last_of("\\"));
        dirName = dirName.substr(dirName.find_last_of("\\") + 1);
    }
    if (targetDestinationExists(currDir, targetDir, "dir"))
    {
        TreeNode *tempDir = currDir;
        changeDir(currDir, targetDir, false);
        bool duplicates = checkDuplicates(currDir, dirName, "dir");

        if (!duplicates)
        {
            TreeNode *newDir;
            if (currDir->path == root->path)
            {
                newDir = new TreeNode(dirName, targetDir + dirName, "dir");
            }
            else
            {
                newDir = new TreeNode(dirName, targetDir + "\\" + dirName, "dir");
            }
            insertNode(currDir, newDir);
        }
        currDir = tempDir;
    }
    else
    {
        cout << "The system cannot find the path specified." << endl;
    }
}
void Tree::makeFile(string input)
{
    string fileName = input.substr(input.find(">") + 1);
    if (fileName.empty())
    {
        cout << "The syntax of the command is incorrect." << endl;
        return;
    }
    if (fileName.front() == ' ')
    {
        fileName = input.substr(input.find(">") + 2);
    }
    if (fileName.find("\\") != string::npos)
    {
        string target;
        target = fileName.substr(0, fileName.find_last_of("\\"));
        fileName = fileName.substr(fileName.find_last_of("\\") + 1);

        if (targetDestinationExists(currDir, target, "dir"))
        {
            TreeNode *tempDir = currDir;
            changeDir(tempDir, target, false);
            bool check = false;
            for (int i = 0; i < tempDir->children.size(); i++) // Using for loop to check if the file already exists, if it does then it will not create a new file.
            {
                if (tempDir->children[i]->name == fileName && tempDir->children[i]->type == "file")
                {
                    check = true;
                    return;
                }
            }
            if (!check)
            {
                TreeNode *newFile;
                newFile = new TreeNode(fileName, tempDir->path + "\\" + fileName, "file");
                insertNode(tempDir, newFile);
            }
        }
        else
        {
            cout << "The system cannot find the path specified." << endl;
        }
    }
    else
    {
        bool check = false;
        for (int i = 0; i < currDir->children.size(); i++) // Using for loop to check if the file already exists, if it does then it will not create a new file.
        {
            if (currDir->children[i]->name == fileName && currDir->children[i]->type == "file")
            {
                check = true;
                return;
            }
        }
        if (!check)
        {
            TreeNode *newFile;
            if (currDir->path == root->path)
            {
                newFile = new TreeNode(fileName, currDir->path + fileName, "file");
            }
            else
            {
                newFile = new TreeNode(fileName, currDir->path + "\\" + fileName, "file");
            }
            insertNode(currDir, newFile);
        }
    }
}
void Tree::changeCurrDir(string input)
{
    string temp = input.substr(2);
    if (temp.empty()) // Display path of current directory
    {
        cout << "C:" << currDir->path << endl;
    }
    else if ((input.find("cd ..") != string::npos) || (input.find("cd..") != string::npos) ||
             (input.find("CD ..") != string::npos) || (input.find("CD..") != string::npos)) // Go to parent directory
    {
        if (currDir->path == root->path)
        {
            return;
        }
        else
        {
            currDir = currDir->parent;
        }
    }
    else if ((input.find("cd ") != string::npos) ||
             (input.find("CD ") != string::npos)) // Go to child directory
    {
        string targetDir = input.substr(3);
        if (targetDir.find_first_not_of(" ") == string::npos)
        {
            cout << "C:" << currDir->path << endl;
        }
        else if (targetDir.find("\\") != string::npos)
        {
            if (targetDestinationExists(currDir, targetDir, "dir"))
            {
                changeDir(currDir, targetDir, false);
            }
            else
            {
                cout << "The system cannot find the path specified." << endl;
            }
        }
        else if (targetDestinationExistsAtSameLevel(currDir, targetDir, "dir"))
        {
            changeDir(currDir, targetDir, true);
            return;
        }
        else
        {
            cout << "The system cannot find the path specified." << endl;
        }
    }
    else // adding specifically for cd command because it enters in this "else if of CLI" if the command is cd. e.g. if it's cda it will still enter this "else if of CLI" because it contains cd.
    {
        input = input.substr(0, input.find_first_of(" "));
        cout << "'" << input << "'"
             << " is not recognized as an internal or external command, operable program or batch file." << endl;
    }
}
void Tree::deleteFile(string input)
{
    if ((input.find("del /p ") != string::npos) || (input.find("del /P ") != string::npos) || // Ask for confirmation before deleting
        (input.find("DEL /p ") != string::npos) || (input.find("DEL /p ") != string::npos))
    {
        string target = input.substr(7);
        if (targetDestinationExists(currDir, target, "file"))
        {
            char ch;
            do
            {
                cout << "Are you sure you want to delete " << target << "? (Y/N)" << endl;
                cin >> ch;
                if (ch == 'Y' || ch == 'y')
                {
                    TreeNode *fileToDel = currDir;
                    if (targetDestinationExistsAtSameLevel(currDir, target, "file"))
                    {
                        changeFile(fileToDel, target, true);
                    }
                    else
                    {
                        changeFile(fileToDel, target, false);
                    }
                    deleteNode(fileToDel);
                }
                else if (ch == 'N' || ch == 'n')
                {
                    return;
                }
            } while (ch != 'Y' && ch != 'y' && ch != 'N' && ch != 'n');
        }
        else
        {
            cout << "The system cannot find the file specified." << endl;
        }
    }
    else
    {
        // Delete without confirmation
        string target = input.substr(4);
        if (targetDestinationExists(currDir, target, "file"))
        {
            TreeNode *fileToDel = currDir;
            if (targetDestinationExistsAtSameLevel(currDir, target, "file"))
            {
                changeFile(fileToDel, target, true);
            }
            else
            {
                changeFile(fileToDel, target, false);
            }
            deleteNode(fileToDel);
        }
        else
        {
            cout << "The system cannot find the file specified." << endl;
        }
    }
}
void Tree::deleteDir(string input)
{
    string target = input.substr(6);
    if (targetDestinationExists(currDir, target, "dir"))
    {
        TreeNode *dirToDel = currDir;
        if (targetDestinationExistsAtSameLevel(currDir, target, "dir"))
        {
            changeDir(dirToDel, target, true);
        }
        else
        {
            changeDir(dirToDel, target, false);
        }
        if (dirToDel->children.empty())
        {
            deleteNode(dirToDel);
        }
        else
        {
            cout << "Directory is not empty! Do you want to merge current directory with another directory? (Y/N)" << endl;
            char ch;
            do
            {
                cin >> ch;
                if (ch == 'Y' || ch == 'y')
                {
                    cout << "Enter destination directory: ";
                    string destination = "";
                    cin >> destination;
                    merge(target, destination);
                }
                else if (ch == 'N' || ch == 'n')
                {
                    deleteNode(dirToDel);
                }
            } while (ch != 'Y' && ch != 'y' && ch != 'N' && ch != 'n');
        }
    }
    else
    {
        cout << "The system cannot find the file specified." << endl;
    }
}
void Tree::save(string filename)
{
    if (filename.empty())
    {
        cout << "The syntax of the command is incorrect." << endl;
    }
    else
    {
        ofstream file;
        file.open(filename);
        if (!file.is_open())
        {
            cout << "The system cannot find the file specified." << endl;
        }
        else
        {
            writeTreeToFile(root, file, 0);
            file.close();
        }
    }
}
void Tree::load(string filename)
{
    if (filename.empty())
    {
        cout << "The syntax of the command is incorrect." << endl;
    }
    else
    {
        ifstream file;
        file.open(filename);
        if (!file.is_open())
        {
            cout << "The system cannot find the file specified." << endl;
        }
        else
        {
            readTreeFromFileAndDisplay(file);
            file.close();
        }
    }
}
// Scrap Code:
//  void readTreeFromFile(TreeNode *&currentNode, ifstream &file, const string &currentPath = "")
//  {
//      // Read line by line from the file and reconstruct the tree
//      string line;
//      while (getline(file, line))
//      {
//          int level = line.find_first_not_of(" ");
//          level /= 5; // Assuming 5 spaces for each level
//          line = line.substr(level);

//         string name = line.substr(0, line.find_first_of("<"));
//         string type = "file";
//         if (line.find("<DIR>") != string::npos)
//         {
//             type = "dir";
//         }

//         string newPath = currentPath == "\\" ? name : currentPath + "\\" + name; // Update the path

//         TreeNode *newNode = new TreeNode(name, type, newPath); // Include the path attribute
//         readTreeFromFile(newNode, file, newPath);

//         currentNode->children.push_back(newNode);
//     }
// }