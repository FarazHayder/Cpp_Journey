// Faraz_Hayder_22i2687
#include "header.h"

int main()
{
    ProjectSchedPro projectSchedPro;       // Creating object of ProjectSchedPro
    projectSchedPro.ProjectSchedProMenu(); // Calling ProjectSchedProMenu method to show menu and start the program

    return 0;
}