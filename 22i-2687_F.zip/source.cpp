// Faraz_Hayder_22i2687
#include "methods.h"
int main()
{
    fileDirectoryTreeShell->CLI();
    return 0;
}