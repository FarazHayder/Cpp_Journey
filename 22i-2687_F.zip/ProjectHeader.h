// Faraz_Hayder_22i2687
#if !defined(ProjectHeader)
#define ProjectHeader

#include "header.h"

struct Skill
{
    int id;
    string name;
    double proficiency; // Ranges from zero(0)-one(1); where zero(0) is the lowest and one(1) is the highest
    // Methods
    Skill();
};
Skill::Skill()
{
    id = 0;
    name = "";
    proficiency = 0;
}

struct Resource
{
    int ID;
    bool status; // 1 = available, 0 = unavailable
    Skill skill;
    Resource *next;
    Resource *prev;
    // Methods
    Resource();
};
Resource::Resource()
{
    ID = 0;
    status = 0;
    next = NULL;
    prev = NULL;
}

struct Task
{
    int id;
    int duration;
    int ES;
    int LS;
    int EF;
    int LF;
    int slack;
    MyVector<int> dependency;
    string skill;
    Task *next;
    Task *prev;

    // Methods
    Task();
};
Task::Task()
{
    id = 0;
    duration = 0;
    ES = 0;
    LS = 0;
    EF = 0;
    LF = 0;
    slack = 0;
    dependency.addElement(-1);
    skill = "";
    next = NULL;
    prev = NULL;
}

struct Project
{
    string name;
    int id;
    int noOfTasks;
    int noOfResources;
    int duration;
    Task *start;
    Task *end;
    Resource *ResStart;
    Resource *ResEnd;
    bool isSetAttributes;
    bool isSetResources;

    // Methods
    Project();
    void MainMenu();
    void MainMenuLink();
    void addTask(int duration, MyVector<int> dependency, string skill);
    void setTaskDuration();
    void set_nth_TaskDuration(int id, int duration);
    void DisplayDurations();
    void printTaskDependencyList();
    void addResource(string name, double proficiency);
    bool setAttributes();
    void displayBasicSchedule();
    void printCriticalTasks();
};
Project::Project()
{
    id = 0;
    name = "";
    duration = 0;
    start = new Task;
    end = new Task;
    start->next = end;
    end->prev = start;
    ResStart = new Resource;
    ResEnd = new Resource;
    ResStart->next = ResEnd;
    ResEnd->prev = ResStart;
    isSetAttributes = false;
    isSetResources = false;
    noOfTasks = 0;
    noOfResources = 0;
}
void Project::MainMenu()
{
    // For clearing console screen
    system("cls");
    char option;
    cout << "\n<===================== Main Menu =====================>" << endl
         << "\nPress '1' to 'Add Task'" << endl
         << "Press '2' to 'Display Duration of Tasks'" << endl
         << "Press '3' to 'Display Basic Schedule'" << endl
         << "Press '4' to 'Print Task Dependency List'" << endl
         << "Press '5' to 'Modify Duration of All Tasks'" << endl
         << "Press '6' to 'Modify Duration of a Task'" << endl
         << "Press '7' to 'Display Critical Tasks'" << endl
         << "Press '8' to 'Add Resource'" << endl
         << "Press '9' to 'go back'" << endl;
    option = getch();

    while (!(option == '1' || option == '2' || option == '3' || option == '4' || option == '5' || option == '6' || option == '7' || option == '8' || option == '9'))
    {
        option = getch();
    }
    // For case '1':
    int duration = 0;
    char character = 'y';
    MyVector<int> dependency;
    string skill = "";
    bool check = false;
    // For case '6':
    int id = 0;
    // For case '8':
    string name = "";
    double proficiency = 0;

    switch (option)
    {
    case '1':
        // For clearing console screen
        system("cls");
        cout << "\nEnter the duration: ";
        cin >> duration;
        while (duration <= 0)
        {
            cout << "Enter a valid duration: ";
            cin >> duration;
        }
        while (character == 'y')
        {
            cout << "Is your task dependent on another tasks? (y/n)";
            character = getch();
            while (character != 'y' && character != 'n')
            {
                character = getch();
            }
            if (character == 'y')
            {
                cout << "\nEnter dependency: ";
                cin >> id;
                while (id <= 0)
                {
                    cout << "Enter a valid ID: ";
                    cin >> id;
                }
                dependency.addElement(id);
                check = true;
            }
            if (dependency.elements == 0)
            {
                dependency.addElement(-1);
            }
        }
        cout << "\nEnter the skill required for this task: ";
        cin >> skill;
        addTask(duration, dependency, skill);
        break;

    case '2':
        // For clearing console screen
        system("cls");
        DisplayDurations();
        break;

    case '3':
        // For clearing console screen
        system("cls");
        displayBasicSchedule();
        break;

    case '4':
        // For clearing console screen
        system("cls");
        printTaskDependencyList();
        break;

    case '5':
        // For clearing console screen
        system("cls");
        setTaskDuration();
        break;

    case '6':
        // For clearing console screen
        system("cls");
        cout << "Enter the ID of the task whose duration you want to modify: ";
        cin >> id;
        while (id <= 0)
        {
            cout << "Enter a valid ID: ";
            cin >> id;
        }
        cout << "Enter the duration of task " << id << ": ";
        cin >> duration;
        while (duration <= 0)
        {
            cout << "Enter a valid duration: ";
            cin >> duration;
        }
        set_nth_TaskDuration(id, duration);
        break;

    case '7':
        // For clearing console screen
        system("cls");
        printCriticalTasks();
        break;

    case '8':
        // For clearing console screen
        system("cls");
        cout << "Enter the name of the skill for the resource: ";
        cin >> name;
        cout << "Enter the proficiency of the resource: ";
        cin >> proficiency;
        // Since proficiency can only be between 0 and 1
        while (proficiency <= 0 || proficiency > 1)
        {
            cout << "The proficiency must be between '0' and '1'.\nEnter a valid proficiency: ";
            cin >> proficiency;
        }
        addResource(name, proficiency);
        break;

    case '9':
        return;
    }
    MainMenu();
}
// Provides a link to the Main Menu
void Project::MainMenuLink()
{
    char ch;
    cout << "\nPress 'Esc or Enter' to 'Go Back'" << endl;
    ch = getch();
    while (ch != '\x1B' && ch != '\r')
    {
        ch = getch();
    }
    if (ch == '\r')
    {
        // For clearing console screen
        system("cls");
        return;
    }
    // For clearing console screen
    system("cls");
}
void Project::DisplayDurations()
{
    if (start->next != end) // This means that the list is not empty.
    {
        Task *current = start->next;
        while (current != end)
        {
            cout << current->duration << " ";
            current = current->next;
        }
        cout << endl;
    }
    else // This means that the list is empty.
    {
        cout << "No tasks found!" << endl;
    }
    MainMenuLink();
}
void Project::addTask(int duration, MyVector<int> dependency, string skill)
{
    Task *newTask = new Task();
    newTask->duration = duration;
    if (dependency[0] == -1) // Setting early finish of first tasks
    {
        newTask->EF = newTask->ES + newTask->duration;
    }
    newTask->skill = skill;
    newTask->dependency = dependency;
    newTask->id = noOfTasks + 1;
    if (start->next == end) // For empty list
    {
        start->next = newTask;
        newTask->prev = start;
        newTask->next = end;
        end->prev = newTask;
    }
    else // When list is not empty
    {
        newTask->prev = end->prev;
        end->prev->next = newTask;
        newTask->next = end;
        end->prev = newTask;
    }
    noOfTasks++;
    isSetAttributes = false; // Since new task is added so we will have to set the attributes again.
}
void Project::addResource(string name, double proficiency)
{
    Resource *newResource = new Resource();
    newResource->ID = noOfResources + 1;
    newResource->status = 1;
    newResource->skill.id = noOfResources + 1;
    newResource->skill.name = name;
    newResource->skill.proficiency = proficiency;
    cout << "TEST" << endl;
    if (ResStart->next == ResEnd) // For empty list
    {
        ResStart->next = newResource;
        newResource->prev = ResStart;
        newResource->next = ResEnd;
        ResEnd->prev = newResource;
    }
    else // When list is not empty
    {
        newResource->prev = ResEnd->prev;
        ResEnd->prev->next = newResource;
        newResource->next = ResEnd;
        ResEnd->prev = newResource;
    }
    noOfResources++;
    isSetResources = false; // Since new resource is added so we will have to set the attributes again.
}
bool Project::setAttributes()
{
    // To check if at least one task ES is set to zero.
    Task *current = start->next;
    while (current != end)
    {
        if (current->dependency[0] == -1)
        {
            break;
        }
        current = current->next;
        if (current == end)
        {
            cout << "The start time of no task is set to zero!" << endl;
            return false;
        }
    }
    // Finding Total Dependencies
    MyVector<int> TotalDependencies;
    current = start->next;
    while (current != end)
    {
        if (current->dependency[0] != -1)
        {
            for (int i = 0; i < current->dependency.elements; i++)
            {
                TotalDependencies.addElement(current->dependency[i]);
            }
        }
        current = current->next;
    }
    TotalDependencies.removeDuplicates(); // Removing duplicates from TotalDependencies vector
    // Finding the biggest number in the TotalDependencies vector and comparing if it is equal to the number of tasks
    if (TotalDependencies.elements != 0) // This means that there are dependencies.
    {
        int biggest = TotalDependencies[0];
        for (int i = 0; i < TotalDependencies.elements; i++)
        {
            if (biggest < TotalDependencies[i])
            {
                biggest = TotalDependencies[i];
            }
        }
        if (biggest > noOfTasks) // This means that the dependencies are not set correctly. And we will show an error message. Because a dependency is set as such that the task on which the current task is dependent does not exist.
        {
            cout << "The dependencies are not set correctly!" << endl;
            return false;
        }
    }
    // To set early start and early finish
    for (int i = 0; i < TotalDependencies.elements; i++)
    {
        Task *current = start->next;
        while (current != end)
        {
            if (current->dependency[0] != -1) // This means that the task is not the first task.
            {
                for (int i = 0; i < current->dependency.elements; i++)
                {
                    Task *temp = start->next;
                    while (temp != end) // This loop is for finding the task on which the current task is dependent.
                    {
                        if (temp->id == current->dependency[i]) // This means that the task is found.
                        {
                            if (temp->EF > current->ES) // Setting the largest value as early start
                            {
                                current->ES = temp->EF;
                                current->EF = current->ES + current->duration;
                            }
                            break;
                        }
                        temp = temp->next;
                    }
                }
            }
            current = current->next;
        }
    }
    // Setting the end node
    for (int i = 0; i < TotalDependencies.elements; i++)
    {
        Task *current = start->next;
        while (current != end)
        {
            if (current->id != TotalDependencies[i]) // This means that the task is the last task.
            {
                if (end->ES < current->EF) // Setting the largest value as early start
                {
                    end->ES = current->EF;
                    end->EF = end->ES;
                    end->LS = end->ES;
                    end->LF = end->ES;
                }
            }
            current = current->next;
        }
    }
    // To set late start and late finish
    // First setting late finish and late start of the last task
    for (int i = 0; i < TotalDependencies.elements; i++)
    {
        Task *current = start->next;
        while (current != end)
        {
            if (current->id != TotalDependencies[i]) // This means that the task is the last task.
            {
                current->LF = end->LS;
                current->LS = current->LF - current->duration;
            }
            current = current->next;
        }
    }
    // Now setting late finish and late start of the rest of the tasks
    for (int i = 0; i < TotalDependencies.elements; i++)
    {
        Task *current = start->next;
        while (current != end)
        {
            for (int j = 0; j < current->dependency.elements; j++)
            {
                if (current->dependency[j] == TotalDependencies[i]) // This means that the task is not the last task.
                {
                    Task *temp = start->next;
                    while (temp != end)
                    {
                        if (temp->id == current->dependency[j])
                        {
                            if (current->LS < temp->LF) // Setting the smallest value as late finish
                            {
                                temp->LF = current->LS;
                                temp->LS = temp->LF - temp->duration;
                                break;
                            }
                        }
                        temp = temp->next;
                    }
                }
            }
            current = current->next;
        }
    }
    // To set slack
    current = start->next;
    while (current != end)
    {
        current->slack = current->LF - current->EF;
        current = current->next;
    }
    // Calculating the duration of the project
    current = start->next;
    while (current != end)
    {
        if (current->slack == 0) // This means that the task is critical.
        {
            duration += current->duration; // Adding the duration of the critical tasks
        }
        current = current->next;
    }
    return true;
}
void Project::setTaskDuration()
{
    if (start->next != end) // This means that the list is not empty.
    {
        Task *current = start->next;
        while (current != end)
        {
            cout << "Enter the duration of task " << current->id << ": ";
            cin >> current->duration;
            current = current->next;
        }
        isSetAttributes = false; // Since duration is changed so we will have to set the attributes again.
    }
    else // This means that the list is empty.
    {
        cout << "No tasks found!" << endl;
    }
    MainMenuLink();
}
void Project::set_nth_TaskDuration(int id, int duration)
{
    if (start->next != end) // This means that the list is not empty.
    {
        Task *current = start->next;
        while (current != end)
        {
            if (current->id == id)
            {
                current->duration = duration;
                isSetAttributes = false; // Since duration is changed so we will have to set the attributes again.
                break;
            }
            current = current->next;
            if (current == end) // This means that the task with the given id does not exist. So we will show an error message.
            {
                cout << "Task not found!" << endl;
            }
        }
    }
    else
    {
        cout << "No tasks found!" << endl;
    }
    MainMenuLink();
}
void Project::displayBasicSchedule()
{
    if (isSetAttributes == false) // This means that the attributes are not set.
    {
        isSetAttributes = setAttributes();
    }
    if (isSetAttributes == false) // This means that the attributes are still not set. So we will return to the main menu.
    {
        MainMenuLink();
        return;
    }
    if (start->next != end) // This means that the list is not empty.
    {
        Task *current = start->next;
        while (current != end)
        {
            cout << "ID"
                 << "    "
                 << "ES"
                 << "    "
                 << "EF"
                 << "    "
                 << "LS"
                 << "    "
                 << "LF"
                 << "    "
                 << "Slack"
                 << "    " << endl;
            cout << current->id << "     " << current->ES << "     " << current->EF << "     " << current->LS << "     " << current->LF << "     " << current->slack << endl;
            current = current->next;
        }
        cout << "\nTotal Duration of the Project: " << duration << endl;
    }
    else // This means that the list is empty.
    {
        cout << "No tasks found!" << endl;
    }
    MainMenuLink();
}
void Project::printTaskDependencyList()
{
    if (start->next != end) // This means that the list is not empty.
    {
        cout << "\nID    DEPENDENCIES" << endl;
        Task *current = start->next;
        while (current != end)
        {
            for (int i = 0; i < current->dependency.elements; i++)
            {
                if (i == 0 && current->dependency[i] == -1) // This means that the task is not dependent on any other task.
                {
                    cout << endl;
                    cout << current->id << "        "
                         << "None";
                }
                else if (i == 0) // This means that the task is dependent on another task.
                {
                    cout << endl;
                    cout << current->id << "        " << current->dependency[i];
                }
                else // This means that the task is dependent on more than one tasks.
                {
                    cout << ", " << current->dependency[i];
                }
            }
            current = current->next;
        }
    }
    else // This means that the list is empty.
    {
        cout << "No tasks found!" << endl;
    }
    MainMenuLink();
}
void Project::printCriticalTasks()
{
    if (isSetAttributes == false) // This means that the attributes are not set.
    {
        isSetAttributes = setAttributes();
    }
    if (isSetAttributes == false) // This means that the attributes are still not set. So we will return to the main menu.
    {
        MainMenuLink();
        return;
    }
    if (start->next != end) // This means that the list is not empty.
    {
        Task *current = start->next;
        while (current != end)
        {
            if (current->slack == 0) // This means that the task is critical.
            {
                cout << "ID"
                     << "    "
                     << "ES"
                     << "    "
                     << "EF"
                     << "    "
                     << "LS"
                     << "    "
                     << "LF"
                     << "    "
                     << "Duration"
                     << "    " << endl;
                cout << current->id << "     " << current->ES << "     " << current->EF << "     " << current->LS << "     " << current->LF << "     " << current->duration << endl;
            }
            current = current->next;
        }
        cout << endl;
    }
    else // This means that the list is empty.
    {
        cout << "No tasks found!" << endl;
    }
    MainMenuLink();
}
#endif // ProjectHeader