// Faraz_Hayder_22i2687
#if !defined(header)
#define header

#include <iostream>
#include <conio.h>
#include <windows.h>
using namespace std;

#include "MyVectorImplementation.h"
#include "ProjectHeader.h"

struct ProjectSchedPro
{
    MyVector<Project> projects;

    // Methods
    void ProjectSchedProMenu();
    void ProjectSchedProMenuLink();
    void addProject();
    void openProject();
};

void ProjectSchedPro::addProject()
{
    Project project;
    project.id = projects.elements + 1;
    cout << "Enter Project Name: ";
    string name;
    cin >> name;
    project.name = name;
    projects.addElement(project);
}

void ProjectSchedPro::openProject()
{
    cout << "Enter Project Name: ";
    string name;
    cin >> name;
    if (projects.elements == 0) // If no project exists
    {
        // For clearing console screen
        system("cls");
        cout << "Project not found!" << endl;
        ProjectSchedProMenuLink();
    }
    else
    {
        for (int i = 0; i < projects.elements; i++) // If project exists
        {
            if (projects[i].name == name) // If project exists with the given name then open it and break the loop
            {
                projects[i].MainMenu();
                break;
            }
            else if (i == projects.elements - 1) // If project does not exist with the given name then show error message
            {
                // For clearing console screen
                system("cls");
                cout << "Project not found!" << endl;
                ProjectSchedProMenuLink();
            }
        }
    }
}

void ProjectSchedPro::ProjectSchedProMenu()
{
    // For clearing console screen
    system("cls");
    char option;
    cout << "\n<===================== Project Scheduler Pro Menu =====================>" << endl
         << "\nPress '1' to 'Add Project'" << endl
         << "Press '2' to 'Open Project'" << endl
         << "Press '3' to 'Exit'" << endl;
    option = getch();

    while (!(option == '1' || option == '2' || option == '3'))
    {
        option = getch();
    }

    switch (option)
    {
    case '1':
        // For clearing console screen
        system("cls");
        addProject();
        break;

    case '2':
        // For clearing console screen
        system("cls");
        openProject();
        break;

    case '3':
        // For clearing console screen
        system("cls");
        exit(0);
        break;
    }
    ProjectSchedProMenu();
}
// Provides a link to the Main Menu
void ProjectSchedPro::ProjectSchedProMenuLink()
{
    char ch;
    cout << "\nPress 'Esc' to 'Go Back'" << endl;
    ch = getch();
    while (ch != '\x1B')
    {
        ch = getch();
    }
}

#endif // header
