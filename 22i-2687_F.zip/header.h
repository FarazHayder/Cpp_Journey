// Faraz_Hayder_22i2687
#include <iostream>
#include <vector>
#include <queue>
#include <string>
#include <conio.h>
#include <fstream>
using namespace std;

class TreeNode
{
public:
    string name;
    string path;
    string type;
    vector<TreeNode *> children;
    TreeNode *parent;
    // Methods:-
    TreeNode();
    TreeNode(string name, string path, string type);
};

class Tree
{
    TreeNode *root;
    TreeNode *currDir;
    // Methods:-
    void changeCurrDir(string input);
    void makeFile(string input);
    void makeDir(string dirName, string targetDir);
    void deleteFile(string input);
    void deleteDir(string input);
    void rename(string oldName, string newName);
    void search(TreeNode *currentNode, string targetDir);
    void merge(string source, string destination);
    void move(string source, string destination);
    void copy(string source, string destination);
    void save(string filename);
    void load(string filename);
    void displayTree(TreeNode *currentNode, int level);
    void levelOrderTraversal(TreeNode *root);
    void help();
    // Helper functions:-
    bool targetDestinationExists(TreeNode *currDirOrFile, string targetDirOrFile, string type);
    bool targetDestinationExistsAtSameLevel(TreeNode *currDirOrFile, string targetDirOrFile, string type);
    bool changeDir(TreeNode *&currDir, string targetDir, bool sameLevel);
    bool changeFile(TreeNode *&currDir, string targetDir, bool sameLevel);
    bool checkDuplicates(TreeNode *currDir, string name, string type);
    void writeTreeToFile(TreeNode *currentNode, ofstream &file, int level);
    void readTreeFromFileAndDisplay(ifstream &file);
    void updatePath(TreeNode *currDir);
    void deleteNode(TreeNode *currDirOrFile, string targetDirOrFile, string type);
    void deleteNode(TreeNode *currDirOrFile);
    void insertNode(TreeNode *currNode, TreeNode *newNode);

public:
    // Methods:-
    Tree();
    Tree(string name, string path, string type);
    void CLI();

} *fileDirectoryTreeShell = new Tree("\\", "\\", "dir");