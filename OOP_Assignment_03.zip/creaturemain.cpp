/*-------------------------Main----------------------------------*/
// FarazHayder_22I-2687_Assignment#3
#include <iostream>
using namespace std;

class Creature
{
protected:
     string name;
     int level;
     int health_points;
     int force;
     int position;

public:
     Creature()
     {
          this->name = "";
          this->level = 0;
          this->health_points = 0;
          this->force = 0;
          this->position = 0;
     }
     Creature(string name, int level, int health_points, int force, int position = 0)
     {
          while (name.empty())
          {
               cout << "Invalid Input! Please enter again: ";
               cin >> name;
          }
          while (level < 0)
          {
               cout << "Invalid Input! Please enter again: ";
               cin >> level;
          }
          while (health_points < 0)
          {
               cout << "Invalid Input! Please enter again: ";
               cin >> health_points;
          }
          while (force < 0)
          {
               cout << "Invalid Input! Please enter again: ";
               cin >> force;
          }
          while (position < 0)
          {
               cout << "Invalid Input! Please enter again: ";
               cin >> position;
          }
          this->name = name;
          this->level = level;
          this->health_points = health_points;
          this->force = force;
          this->position = position;
     }
     void setName(string name)
     {
          while (name.empty())
          {
               cout << "Invalid Input! Please enter again: ";
               cin >> name;
          }
          this->name = name;
     }
     string getName() const
     {
          return this->name;
     }
     void setLevel(int level)
     {
          while (level < 0)
          {
               cout << "Invalid Input! Please enter again: ";
               cin >> level;
          }
          this->level = level;
     }
     int getLevel() const
     {
          return this->level;
     }
     void setHealthPoints(int health_points)
     {
          while (health_points < 0)
          {
               cout << "Invalid Input! Please enter again: ";
               cin >> health_points;
          }
          this->health_points = health_points;
     }
     int getHealthPoints() const
     {
          return this->health_points;
     }
     void setForce(int force)
     {
          while (force < 0)
          {
               cout << "Invalid Input! Please enter again: ";
               cin >> force;
          }
          this->force = force;
     }
     int getForce() const
     {
          return this->force;
     }
     void setPosition(int position)
     {
          while (position < 0)
          {
               cout << "Invalid Input! Please enter again: ";
               cin >> position;
          }
          this->position = position;
     }
     int getPosition() const
     {
          return this->position;
     }
     bool alive()
     {
          if (this->health_points > 0)
          {
               return true;
          }
          return false;
     }
     int AttackPoints()
     {
          if (alive())
          {
               return this->level * this->force;
          }
          return 0;
     }
     void Move(int i)
     {
          this->position += i;
     }
     void GoodBye()
     {
          cout << "English: " << this->name << " is no more!" << endl;
     }
     void Weak(int i)
     {
          if (alive())
          {
               this->health_points -= i;
               if (!alive())
               {
                    this->health_points = 0;
                    GoodBye();
               }
               return;
          }
          this->health_points = 0;
          GoodBye();
     }
     void display()
     {
          cout << "Name: " << this->name << endl;
          cout << "Level: " << this->level << endl;
          cout << "Health Status: " << this->health_points << endl;
          cout << "Force: " << this->force << endl;
          cout << "Attacking Points: " << this->AttackPoints() << endl;
          cout << "Position: " << this->position << endl;
     }
};

class Dragon : public Creature
{
     int flame_range;

public:
     Dragon() : Creature()
     {
          this->flame_range = 0;
     }
     Dragon(string name, int level, int health_points, int force, int flame_range, int position = 0) : Creature(name, level, health_points, force, position)
     {
          while (flame_range < 0)
          {
               cout << "Invalid Input! Please enter again: ";
               cin >> flame_range;
          }
          this->flame_range = flame_range;
     }
     void setFlameRange(int i)
     {
          while (flame_range < 0)
          {
               cout << "Invalid Input! Please enter again: ";
               cin >> flame_range;
          }
          this->flame_range = i;
     }
     int getFlameRange()
     {
          return this->flame_range;
     }
     void Fly(int pos)
     {
          this->position = pos;
     }
     void BlowFlame(Creature &creature_obj)
     {
          int distance = 0;
          if (this->position > creature_obj.getPosition())
          {
               distance = this->position - creature_obj.getPosition();
          }
          else if (this->position < creature_obj.getPosition())
          {
               distance = creature_obj.getPosition() - this->position;
          }
          else if (this->position == creature_obj.getPosition())
          {
               distance = 0;
          }
          if (this->alive())
          {
               if (creature_obj.alive())
               {
                    if (this->flame_range >= distance)
                    {
                         creature_obj.Weak(AttackPoints());
                         this->Weak(distance);
                         if (this->alive() && !creature_obj.alive())
                         {
                              this->level++;
                              return;
                         }
                         if (!this->alive())
                         {
                              this->GoodBye();
                              return;
                         }
                         if (!creature_obj.alive())
                         {
                              creature_obj.GoodBye();
                              return;
                         }
                    }
                    else
                    {
                         cout << "The enemy is out of range!!!" << endl;
                         return;
                    }
               }
               else
               {
                    creature_obj.GoodBye();
                    return;
               }
          }
          else
          {
               this->GoodBye();
               return;
          }
     }
};

class Ichneumon : public Creature
{
     int length;
     int poison_dose;

public:
     Ichneumon() : Creature()
     {
          this->length = 0;
          this->poison_dose = 0;
     }
     Ichneumon(string name, int level, int health_points, int force, int length, int poison_dose, int position = 0) : Creature(name, level, health_points, force, position)
     {
          while (length < 0)
          {
               cout << "Invalid Input! Please enter again: ";
               cin >> length;
          }
          while (poison_dose < 0)
          {
               cout << "Invalid Input! Please enter again: ";
               cin >> poison_dose;
          }
          this->length = length;
          this->poison_dose = poison_dose;
     }
     void setLength(int i)
     {
          while (length < 0)
          {
               cout << "Invalid Input! Please enter again: ";
               cin >> length;
          }
          this->length = i;
     }
     int getLength()
     {
          return this->length;
     }
     void setPoisonDose(int i)
     {
          while (poison_dose < 0)
          {
               cout << "Invalid Input! Please enter again: ";
               cin >> poison_dose;
          }
          this->poison_dose = i;
     }
     int getPoisonDose()
     {
          return this->poison_dose;
     }
     void InjectPoison(Creature &creature_obj)
     {

          int distance = 0;
          if (this->position > creature_obj.getPosition())
          {
               distance = this->position - creature_obj.getPosition();
          }
          else if (this->position < creature_obj.getPosition())
          {
               distance = creature_obj.getPosition() - this->position;
          }
          else if (this->position == creature_obj.getPosition())
          {
               distance = 0;
          }
          if (this->alive())
          {
               if (creature_obj.alive())
               {
                    if (this->length >= distance)
                    {
                         creature_obj.Weak(AttackPoints() + poison_dose);
                         if (!creature_obj.alive())
                         {
                              this->level++;
                              return;
                         }
                    }
                    else
                    {
                         cout << "The enemy is out of range!!!" << endl;
                         return;
                    }
               }
               else
               {
                    creature_obj.GoodBye();
                    return;
               }
          }
          else
          {
               this->GoodBye();
               return;
          }
     }
};

void Fight(Dragon &dragon, Ichneumon &ichneumon)
{
     if (!dragon.alive() || !ichneumon.alive())
     {
          if (!dragon.alive())
          {
               dragon.GoodBye();
          }
          if (!ichneumon.alive())
          {
               ichneumon.GoodBye();
          }
          return;
     }
     else
     {
          ichneumon.InjectPoison(dragon);
          dragon.BlowFlame(ichneumon);
     }
}

int main()
{
     Dragon dragon("Dragon red", 2, 10, 3, 20);
     Ichneumon ichneumon("ichneumon evil", 2, 10, 1, 10, 1, 42);

     dragon.display();
     cout << "is preparing for fight with :" << endl;
     ichneumon.display();

     cout << endl;
     cout << "1st Fight :" << endl;
     cout << "    the creature-s are not within range, so can not Attacke."
          << endl;
     Fight(dragon, ichneumon);

     cout << "After the Fight :" << endl;
     dragon.display();
     ichneumon.display();

     cout << endl;
     cout << "Dragon has flown close to ichneumon :" << endl;
     dragon.Fly(ichneumon.getPosition() - 1);
     dragon.display();

     cout << endl;
     cout << "ichneumon moves :" << endl;
     ichneumon.Move(1);
     ichneumon.display();

     cout << endl;
     cout << "2nd Fight :" << endl;
     cout << ""
          << "+ ichneumon inflicts a 3-point attack on dragon\n"
             " [ level (2) * force (1) + poison (1) = 3 ] ;\n"
             "+ Dragon inflicts a 6-point attack on ichneumon\n"
             "[ level (2) * force (3) = 6 ] ;\n"
             "+ during his attack, dragon loses two additional points\n"
             "      [ corresponding to the distance between dragon and ichneumon : 43 - 41 = 2 ]."
          << endl;
     Fight(dragon, ichneumon);

     cout << "After the Fight :" << endl;
     dragon.display();
     ichneumon.display();

     cout << endl;
     cout << "Dragon moves by one step " << endl;
     dragon.Move(1);
     dragon.display();

     cout << endl;
     cout << "3rd Fight :" << endl;
     cout << "  + ichneumon inflicts a 3-point attack on dragon \n "
             "    [ level (2) * force (1) + poison (1) = 3 ] ; \n "
             "+ Dragon inflicts a 6-point attack on ichneumon \n "
             "      [ level (2) * force (3) = 6 ] ; \n"
             "+ during his attack, dragon lost 1 additional life point.\n"
             "[ corresponding to the distance between dragon and ichneumon : 43 - 42 = 1 ] ;\n"
             "+ ichneumon is defeated and the dragon rises to level 3"
          << endl;
     Fight(dragon, ichneumon);

     cout << "After the Fight :" << endl;
     dragon.display();
     ichneumon.display();

     cout << endl;
     cout << "4th Fight :" << endl;
     cout << "    when one creatures is defeated, nothing happpens" << endl;
     Fight(dragon, ichneumon);

     cout << "After the Fight :" << endl;
     dragon.display();
     ichneumon.display();

     return 0;
}
