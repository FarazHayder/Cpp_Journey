// FarazHayder_22I-2687_Assignment#3
#include <iostream>
using namespace std;

class Block
{
private:
    string shape;
    string color;

public:
    Block() {}
    Block(string shape, string color = "")
    {
        this->shape = shape;
        this->color = color;
    }
    void setShape(string shape)
    {
        this->shape = shape;
    }
    string getShape()
    {
        return shape;
    }
    void setColor(string color)
    {
        this->color = color;
    }
    string getColor()
    {
        return color;
    }
    ostream &display(ostream &out) const
    {
        if (color.empty())
        {
            out << "(" << shape << ")";
        }
        else
        {
            out << "(" << shape << ", " << color << ")";
        }
        return out;
    }
};

ostream &operator<<(ostream &os, Block &block)
{
    return block.display(os);
}

class Build
{
public:
    Block ***Content;
    int rows;
    int columns;
    int depth;

    Build(Block &block)
    {
        rows = 1;
        columns = 1;
        depth = 1;
        Content = new Block **[rows];
        for (int i = 0; i < rows; i++) // rows/height
        {
            Content[i] = new Block *[columns];
            for (int j = 0; j < columns; j++) // columns/width
            {
                Content[i][j] = new Block[depth]{block};
                for (int k = 0; k < depth; k++) // pages/depth
                {
                    Content[i][j][k] = block;
                }
            }
        }
    }
    ostream &display(ostream &out) const
    {
        if (Content == nullptr)
        {
            out << "";
        }
        else
        {
            for (int i = rows - 1; i >= 0; i--) // rows/width
            {
                out << "\nLayer " << i << " :" << endl;
                for (int j = 0; j < columns; j++) // columns/height
                {
                    for (int k = 0; k < depth; k++) // pages/depth
                    {
                        out << Content[i][j][k];
                    }
                    out << endl;
                }
                out << endl;
            }
        }
        return out;
    }
    Build &operator^=(Build &obj)
    {
        int tempRows = this->rows + obj.rows;
        int tempColumns = 0;
        int tempDepth = 0;
        if (this->columns > obj.columns)
        {
            tempColumns = this->columns;
        }
        else
        {
            tempColumns = obj.columns;
        }
        if (this->depth > obj.depth)
        {
            tempDepth = this->depth;
        }
        else
        {
            tempDepth = obj.depth;
        }
        Block ***newContent;
        newContent = new Block **[tempRows];
        int tempi = 0;
        int tempj = 0;
        int tempk = 0;
        for (int i = 0; i < tempRows; i++) // rows/height
        {
            newContent[i] = new Block *[tempColumns];
            for (int j = 0; j < tempColumns; j++) // columns/width
            {
                newContent[i][j] = new Block[tempDepth];
                for (int k = 0; k < tempDepth; k++) // pages/depth
                {
                    if (i < rows && j < columns && k < depth)
                    {
                        newContent[i][j][k] = this->Content[i][j][k];
                    }
                    else if (tempi < obj.rows && tempj < obj.columns && tempk < obj.depth)
                    {
                        newContent[i][j][k] = obj.Content[tempi][tempj][tempk];
                        tempk++;
                    }
                }
                if (tempk >= obj.depth)
                {
                    tempj++;
                    tempk = 0;
                }
            }
            if (tempj >= obj.columns)
            {
                tempi++;
                tempj = 0;
                tempk = 0;
            }
        }
        for (int i = 0; i < rows; i++)
        {
            for (int j = 0; j < columns; j++)
            {
                delete[] Content[i][j];
            }
            delete[] Content[i];
        }
        delete[] Content;
        Content = NULL;
        Content = newContent;
        this->rows = tempRows;
        this->columns = tempColumns;
        this->depth = tempDepth;
        return *this;
    }
    Build operator^(Build &obj)
    {
        Build temp(*this);
        temp ^= obj;
        return temp;
    }
    Build &operator-=(Build &obj)
    {
        int tempRows = this->rows;
        int tempColumns = this->columns + obj.columns;
        int tempDepth = 0;
        if (this->depth > obj.depth)
        {
            tempDepth = this->depth;
        }
        else
        {
            tempDepth = obj.depth;
        }
        if (obj.rows < this->rows)
        {
            return *this;
        }
        Block ***newContent;
        newContent = new Block **[tempRows];
        int tempi = 0;
        int tempj = 0;
        int tempk = 0;
        for (int i = 0; i < tempRows; i++) // rows/height
        {
            newContent[i] = new Block *[tempColumns];
            for (int j = 0; j < tempColumns; j++) // columns/width
            {
                newContent[i][j] = new Block[tempDepth];
                for (int k = 0; k < tempDepth; k++) // pages/depth
                {
                    if (i < rows && j < columns && k < depth)
                    {
                        newContent[i][j][k] = this->Content[i][j][k];
                    }
                    else if (tempi < obj.rows && tempj < obj.columns && tempk < obj.depth)
                    {
                        newContent[i][j][k] = obj.Content[tempi][tempj][tempk];
                        tempk++;
                    }
                }
                if (tempk >= obj.depth)
                {
                    tempj++;
                    tempk = 0;
                }
            }
            if (tempj >= obj.columns)
            {
                tempi++;
                tempj = 0;
                tempk = 0;
            }
        }
        for (int i = 0; i < rows; i++)
        {
            for (int j = 0; j < columns; j++)
            {
                delete[] Content[i][j];
            }
            delete[] Content[i];
        }
        delete[] Content;
        Content = NULL;
        Content = newContent;
        this->rows = tempRows;
        this->columns = tempColumns;
        this->depth = tempDepth;
        return *this;
    }
    Build operator-(Build &obj)
    {
        Build temp(*this);
        temp -= obj;
        return temp;
    }
    Build &operator+=(Build &obj)
    {
        int tempRows = this->rows;
        int tempColumns = this->columns;
        int tempDepth = this->depth + obj.depth;
        if (obj.rows < this->rows)
        {
            return *this;
        }
        if (obj.columns < this->columns)
        {
            return *this;
        }
        Block ***newContent;
        newContent = new Block **[tempRows];
        int tempi = 0;
        int tempj = 0;
        int tempk = 0;
        for (int i = 0; i < tempRows; i++) // rows/height
        {
            newContent[i] = new Block *[tempColumns];
            for (int j = 0; j < tempColumns; j++) // columns/width
            {
                newContent[i][j] = new Block[tempDepth];
                for (int k = 0; k < tempDepth; k++) // pages/depth
                {
                    if (i < rows && j < columns && k < depth)
                    {
                        newContent[i][j][k] = this->Content[i][j][k];
                    }
                    else if (tempi < obj.rows && tempj < obj.columns && tempk < obj.depth)
                    {
                        newContent[i][j][k] = obj.Content[tempi][tempj][tempk];
                        tempk++;
                    }
                }
                if (tempk >= obj.depth)
                {
                    tempj++;
                    tempk = 0;
                }
            }
            if (tempj >= obj.columns)
            {
                tempi++;
                tempj = 0;
                tempk = 0;
            }
        }
        for (int i = 0; i < rows; i++)
        {
            for (int j = 0; j < columns; j++)
            {
                delete[] Content[i][j];
            }
            delete[] Content[i];
        }
        delete[] Content;
        Content = NULL;
        Content = newContent;
        this->rows = tempRows;
        this->columns = tempColumns;
        this->depth = tempDepth;
        return *this;
    }
    Build operator+(Build &obj)
    {
        Build temp(*this);
        temp += obj;
        return temp;
    }
};
Build operator*(unsigned int n, Build &a)
{
    Build temp(a);
    for (int i = 0; i < n - 1; i++)
    {
        temp += a;
    }
    return temp;
}
Build operator/(unsigned int n, Build &a)
{
    Build temp(a);
    for (int i = 0; i < n - 1; i++)
    {
        temp ^= a;
    }
    return temp;
}
Build operator%(unsigned int n, Build &a)
{
    Build temp(a);
    for (int i = 0; i < n - 1; i++)
    {
        temp -= a;
    }
    return temp;
}

ostream &operator<<(ostream &os, Build &build)
{
    return build.display(os);
}

int main()
{

    Block block1("ObliquedL", "Red");
    cout << block1 << endl;

    Block block2("ObliquedR", "");
    cout << block2 << endl;

    Block block3("Simple", "Red");
    cout << block3 << endl;

    Block block4("Simple", "White");
    cout << block4 << endl;

    Build tower1(block4);
    Build tower2(block4);
    tower1 ^= tower2;

    Build tower3(block3);
    Build tower4(block3);
    // tower3 ^= tower4;
    // tower3 ^= tower4;
    tower3 = 3 / tower3;

    Build tower5(block4);
    // tower5 = tower1 ^ tower3;
    // tower5 = tower1 - tower3;
    tower5 = tower1 + tower3;
    cout << tower5 << endl;

    return 0;
}